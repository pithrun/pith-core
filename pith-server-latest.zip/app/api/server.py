"""FastAPI server exposing Pith MCP tools."""

import asyncio
import concurrent.futures
import copy
import csv
import hashlib
import json
import os
import re
import subprocess
import sys
import threading
import time
import uuid
from contextlib import nullcontext
from datetime import UTC, datetime, timedelta
from pathlib import Path

from app.core.fork_safety import should_suppress_optional_subprocess
from app.storage.session_bindings import WRITER_PROTOCOL_VERSION

_REPO_ROOT = Path(__file__).parent.parent.parent
_DEPLOY_METADATA_PATH = _REPO_ROOT / ".pith-deploy.json"


def _short_commit(value: str) -> str:
    cleaned = (value or "").strip()
    return cleaned[:7] if cleaned else "unknown"


def _read_deploy_metadata() -> dict:
    try:
        if not _DEPLOY_METADATA_PATH.exists():
            return {}
        payload = json.loads(_DEPLOY_METADATA_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


_DEPLOY_METADATA = _read_deploy_metadata()


def _deploy_metadata_value(*keys: str) -> str:
    for key in keys:
        value = os.environ.get(key)
        if value:
            return value
    for key in keys:
        value = _DEPLOY_METADATA.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return ""


# OPS-051: Capture git commit at startup for deployed-commit verification.
def _get_git_commit() -> str:
    deployed_commit = _deploy_metadata_value("PITH_DEPLOYED_SOURCE_COMMIT", "source_commit", "git_commit")
    if deployed_commit:
        return _short_commit(deployed_commit)
    return _short_commit(_read_git_head_commit())


def _get_git_branch() -> str:
    deployed_branch = _deploy_metadata_value("PITH_DEPLOYED_SOURCE_BRANCH", "source_branch", "git_branch")
    if deployed_branch:
        return deployed_branch
    return _read_git_head_ref()


def _get_git_dirty() -> bool | None:
    env_dirty = os.environ.get("PITH_DEPLOYED_SOURCE_DIRTY")
    if env_dirty is not None:
        return env_dirty.strip().lower() in {"1", "true", "yes", "on"}
    deployed_dirty = _DEPLOY_METADATA.get("source_dirty")
    if isinstance(deployed_dirty, bool):
        return deployed_dirty
    return None


def _get_git_commit_source() -> str:
    if _DEPLOY_METADATA or _deploy_metadata_value("PITH_DEPLOYED_SOURCE_COMMIT", "source_commit", "git_commit"):
        return "deploy_metadata"
    return "git_head_file"


def _resolve_git_dir(repo_root: Path = _REPO_ROOT) -> Path | None:
    """Resolve this worktree's git directory without spawning git."""
    git_path = repo_root / ".git"
    try:
        if git_path.is_dir():
            return git_path
        if git_path.is_file():
            content = git_path.read_text(encoding="utf-8", errors="replace").strip()
            if content.startswith("gitdir:"):
                raw_path = content.split(":", 1)[1].strip()
                path = Path(raw_path)
                return path if path.is_absolute() else (repo_root / path).resolve()
    except Exception:
        return None
    return None


def _resolve_common_git_dir(git_dir: Path) -> Path:
    """Resolve shared git metadata for linked worktrees."""
    try:
        common_dir = (git_dir / "commondir").read_text(encoding="utf-8", errors="replace").strip()
        if common_dir:
            path = Path(common_dir)
            return path if path.is_absolute() else (git_dir / path).resolve()
    except Exception:
        pass
    return git_dir


def _read_git_head_commit(repo_root: Path = _REPO_ROOT) -> str:
    """Read current HEAD cheaply for health checks.

    /health and /readyz are hot operational paths. Spawning git here can block
    indefinitely when the worktree/gitdir is contended, which makes deep health
    fail while /healthz remains healthy.
    """
    git_dir = _resolve_git_dir(repo_root)
    if git_dir is None:
        return "unknown"
    try:
        common_git_dir = _resolve_common_git_dir(git_dir)
        head = (git_dir / "HEAD").read_text(encoding="utf-8", errors="replace").strip()
        if not head:
            return "unknown"
        if not head.startswith("ref:"):
            return head
        ref_name = head.split(" ", 1)[1].strip()
        for ref_path in (git_dir / ref_name, common_git_dir / ref_name):
            if ref_path.exists():
                commit = ref_path.read_text(encoding="utf-8", errors="replace").strip()
                return commit if commit else "unknown"
        for packed_refs in (git_dir / "packed-refs", common_git_dir / "packed-refs"):
            if not packed_refs.exists():
                continue
            for line in packed_refs.read_text(encoding="utf-8", errors="replace").splitlines():
                if not line or line.startswith(("#", "^")):
                    continue
                try:
                    commit, packed_ref = line.split(" ", 1)
                except ValueError:
                    continue
                if packed_ref.strip() == ref_name:
                    return commit
    except Exception:
        return "unknown"
    return "unknown"


def _read_git_head_ref(repo_root: Path = _REPO_ROOT) -> str:
    git_dir = _resolve_git_dir(repo_root)
    if git_dir is None:
        return "unknown"
    try:
        head = (git_dir / "HEAD").read_text(encoding="utf-8", errors="replace").strip()
        if head.startswith("ref:"):
            ref_name = head.split(":", 1)[1].strip()
            return Path(ref_name).name or "unknown"
    except Exception:
        return "unknown"
    return "HEAD" if head else "unknown"


def _git_commits_match(startup_commit: str, current_head: str) -> bool | None:
    if startup_commit == "unknown" or current_head == "unknown":
        return None
    return (
        startup_commit == current_head
        or startup_commit.startswith(current_head)
        or current_head.startswith(startup_commit)
    )


_GIT_COMMIT = _get_git_commit()
_GIT_BRANCH = _get_git_branch()
_GIT_DIRTY = _get_git_dirty()
_GIT_COMMIT_SOURCE = _get_git_commit_source()
_GIT_MISMATCH_REASON = "runtime_git_commit_mismatch"
_CANONICAL_MISMATCH_REASON = "runtime_canonical_commit_mismatch"
_DEFAULT_CANONICAL_REPO_ROOT = Path(__file__).resolve().parents[2]
_CANONICAL_REPO_ROOT = Path(
    os.environ.get("PITH_CANONICAL_REPO_ROOT")
    or _DEPLOY_METADATA.get("source_repo")
    or str(_DEFAULT_CANONICAL_REPO_ROOT)
).expanduser()


def _git_commit_matches_head(startup_commit: str, current_head: str) -> bool | None:
    if startup_commit == "unknown" or current_head == "unknown":
        return None
    if startup_commit == current_head:
        return True
    if len(startup_commit) < len(current_head) and current_head.startswith(startup_commit):
        return True
    return len(current_head) < len(startup_commit) and startup_commit.startswith(current_head)


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, str(default)))
    except (TypeError, ValueError):
        logger.warning("Invalid integer env var %s=%r; using %s", name, os.environ.get(name), default)
        return default


def _startup_env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, str(default)))
    except (TypeError, ValueError):
        logger.warning("Invalid float env var %s=%r; using %s", name, os.environ.get(name), default)
        return default


_FAST_STATS_CACHE_TTL_S = float(os.environ.get("PITH_FAST_STATS_CACHE_TTL_S", "5"))
_FAST_STATS_COLD_BUDGET_S = float(os.environ.get("PITH_FAST_STATS_COLD_BUDGET_S", "0.5"))
_FAST_STATS_MAX_STALE_S = float(os.environ.get("PITH_FAST_STATS_MAX_STALE_S", "60"))
DIAGNOSTIC_AUTHORITATIVE_CAPTURE_BUDGET_DEFAULT_MS = _env_int(
    "PITH_DIAGNOSTIC_AUTHORITATIVE_CAPTURE_BUDGET_DEFAULT_MS", 2500
)
DIAGNOSTIC_CAPTURE_BUDGET_MAX_MS = _env_int("PITH_DIAGNOSTIC_CAPTURE_BUDGET_MAX_MS", 5000)
_FAST_STATS_CACHE_LOCK = threading.Lock()
_FAST_STATS_CACHE: tuple[float, dict] | None = None
_FAST_STATS_REFRESH_LOCK = threading.Lock()
_FAST_STATS_REFRESH_FUTURE: concurrent.futures.Future | None = None
_FAST_STATS_REFRESH_ERROR: str | None = None
_FAST_STATS_OBSERVABILITY: dict[str, int | float | str | None] = {
    "refresh_success_count": 0,
    "refresh_failure_count": 0,
    "stale_served_count": 0,
    "slot_acquire_timeout_count": 0,
    "last_refresh_duration_ms": None,
    "last_refresh_error": None,
    "last_success_monotonic": None,  # internal; surfaced as last_success_age_ms
}
_FAST_HEALTH_CACHE_TTL_S = float(os.environ.get("PITH_FAST_HEALTH_CACHE_TTL_S", "5"))
_FAST_HEALTH_COLD_BUDGET_S = float(os.environ.get("PITH_FAST_HEALTH_COLD_BUDGET_S", "0.5"))
_FAST_HEALTH_CACHE_LOCK = threading.Lock()
_FAST_HEALTH_CACHE: tuple[float, dict] | None = None
# EUNOMIA-125: fast_health now has its own background refresh worker (mirrors fast_stats)
# so a single one-shot pith_health call schedules an async refresh instead of refreshing
# inline-only and leaving the cache silently stale for hours.
_FAST_HEALTH_REFRESH_LOCK = threading.Lock()
_FAST_HEALTH_REFRESH_FUTURE: concurrent.futures.Future | None = None
_FAST_HEALTH_REFRESH_ERROR: str | None = None
_FAST_HEALTH_OBSERVABILITY: dict[str, int | float | str | None] = {
    "refresh_success_count": 0,
    "refresh_failure_count": 0,
    "stale_served_count": 0,
    "slot_acquire_timeout_count": 0,
    "last_refresh_duration_ms": None,
    "last_refresh_error": None,
    "last_success_monotonic": None,  # internal; surfaced as last_success_age_ms
}
_KNOWLEDGE_AREAS_CACHE_TTL_S = float(os.environ.get("PITH_KNOWLEDGE_AREAS_CACHE_TTL_S", "5"))
_KNOWLEDGE_AREAS_CACHE_LOCK = threading.Lock()
_KNOWLEDGE_AREAS_CACHE: tuple[float, dict] | None = None
# TOOLING-100: knowledge_areas fast-path joins the EUNOMIA-125 background-refresh lane
# (mirror of the stats/health lanes) instead of acquiring the single slot inline.
_KNOWLEDGE_AREAS_COLD_BUDGET_S = float(os.environ.get("PITH_KNOWLEDGE_AREAS_COLD_BUDGET_S", "0.5"))
_KNOWLEDGE_AREAS_REFRESH_LOCK = threading.Lock()
_KNOWLEDGE_AREAS_REFRESH_FUTURE: concurrent.futures.Future | None = None
_KNOWLEDGE_AREAS_REFRESH_ERROR: str | None = None
_FAST_KNOWLEDGE_AREAS_OBSERVABILITY: dict[str, int | float | str | None] = {
    "refresh_success_count": 0,
    "refresh_failure_count": 0,
    "stale_served_count": 0,
    "slot_acquire_timeout_count": 0,
    "last_refresh_duration_ms": None,
    "last_refresh_error": None,
    "last_success_monotonic": None,  # internal; surfaced as last_success_age_ms
}
# EUNOMIA-128 (saturation gate): the diagnostic-endpoint slot count stays 1 BY DEFAULT.
# The former "do NOT raise until fast-build compute reduction (deferred fix E) lands"
# rationale is RETIRED — it was contradicted by live measurement (rose, 1.65GB WAL DB /
# 35,378 concepts, 2026-06-16): every diagnostic build is already sub-second (stats ~99ms,
# health ~819ms cold-once/~70ms warm, knowledge_areas ~30ms, integrity probe ~762ms), so
# compute cost is not the gate. A 2-slot experiment measured slot=2 SAFE (heaviest read
# +33% sub-linear, still <1s, 1.51x throughput, no EUNOMIA-116 WAL lock contention).
# Raising is intentionally NOT taken here: the pool is unsaturated
# (slot_acquire_timeout_count == 0 across all lanes), so 1->2 would change production DB
# concurrency for a benefit not realized at current scale. The real gate to raise is
# SUSTAINED pool saturation — delta(slot_acquire_timeout_total) > 0 over consecutive
# windows — surfaced read-only as `diagnostic_slot_saturation` in the /health?detail=full
# warmer snapshot and watched by the dev.pith.monitor-diagnostic-slot-saturation launchd
# job. Re-run the 2-slot experiment at the then-current DB size before flipping.
_DIAGNOSTIC_ENDPOINT_SLOT_COUNT = max(1, _env_int("PITH_DIAGNOSTIC_ENDPOINT_SLOTS", 1))
_DIAGNOSTIC_ENDPOINT_SEMAPHORE = threading.Semaphore(_DIAGNOSTIC_ENDPOINT_SLOT_COUNT)
# 50ms timeout for SYNCHRONOUS / user-facing acquires — never block a user on a stale cache.
# TOOLING-100: no synchronous acquirer remains (stats/health/knowledge_areas all moved to the
# background-refresh executor). Retained — env-wired and reserved for any future inline acquire.
_DIAGNOSTIC_ENDPOINT_SLOT_TIMEOUT_S = float(os.environ.get("PITH_DIAGNOSTIC_ENDPOINT_SLOT_TIMEOUT_S", "0.05"))
# EUNOMIA-125: BACKGROUND refresh workers patiently wait for the single slot instead of
# bailing at 50ms (~45% of refreshes were failing, leaving caches silently stale for hours).
_DIAGNOSTIC_REFRESH_SLOT_TIMEOUT_S = float(os.environ.get("PITH_DIAGNOSTIC_REFRESH_SLOT_TIMEOUT_S", "5.0"))
# 2 worker threads so stats and health refresh lanes don't head-of-line-block each other.
# DB concurrency is still gated to 1 by _DIAGNOSTIC_ENDPOINT_SEMAPHORE (respects EUNOMIA-116).
_DIAGNOSTIC_REFRESH_EXECUTOR = concurrent.futures.ThreadPoolExecutor(
    max_workers=max(1, _env_int("PITH_DIAGNOSTIC_REFRESH_WORKERS", 2)),
    thread_name_prefix="pith-diagnostic-refresh",
)


def _env_bool(name: str, default: bool) -> bool:
    """Parse a boolean env var (mirror of _env_int). _env_bool did not exist before EUNOMIA-126."""
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def _health_status_fold_config() -> tuple[bool, str | None]:
    raw = os.environ.get("PITH_HEALTH_STATUS_FOLD_ENABLED")
    if raw is None:
        return True, None
    normalized = raw.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True, None
    if normalized in {"0", "false", "no", "off"}:
        return False, None
    logger.warning("Invalid PITH_HEALTH_STATUS_FOLD_ENABLED=%r; keeping status fold enabled", raw)
    return True, "health_status_fold_config_invalid"


_DIAGNOSTIC_WARMER_ALLOWED_MODES = ("all_lanes", "safe_sequential")
_DIAGNOSTIC_WARMER_ALLOWED_LANES = ("fast_stats", "fast_health", "knowledge_areas")


def _parse_diagnostic_warmer_config() -> tuple[str, tuple[str, ...], str | None]:
    mode = (os.environ.get("PITH_DIAGNOSTIC_WARMER_MODE") or "all_lanes").strip().lower()
    invalid: str | None = None
    if mode not in _DIAGNOSTIC_WARMER_ALLOWED_MODES:
        invalid = f"invalid_mode:{mode or '<empty>'}"

    lanes_raw = os.environ.get("PITH_DIAGNOSTIC_WARMER_LANES")
    if lanes_raw is None or lanes_raw.strip() == "":
        lanes = _DIAGNOSTIC_WARMER_ALLOWED_LANES
    else:
        lane_parts = tuple(part.strip() for part in lanes_raw.split(",") if part.strip())
        unknown = tuple(lane for lane in lane_parts if lane not in _DIAGNOSTIC_WARMER_ALLOWED_LANES)
        duplicates = tuple(lane for lane in lane_parts if lane_parts.count(lane) > 1)
        if not lane_parts:
            invalid = invalid or "empty_lanes"
            lanes = ()
        elif unknown:
            invalid = invalid or f"invalid_lanes:{','.join(unknown)}"
            lanes = ()
        elif duplicates:
            invalid = invalid or f"duplicate_lanes:{','.join(dict.fromkeys(duplicates))}"
            lanes = ()
        else:
            lanes = lane_parts

    return mode, lanes, invalid


# EUNOMIA-126: timer-driven warmer + starvation watchdog. One daemon thread keeps the
# diagnostic caches within TTL so a single cold pith_health/pith_stats call after idle
# reads fresh (partial=false). Reuses the EUNOMIA-125 single-slot refresh path — slot
# count stays 1 (raising it is EUNOMIA-128). Kill switch defaults OFF.
_DIAGNOSTIC_WARMER_ENABLED = _env_bool("PITH_DIAGNOSTIC_WARMER_ENABLED", False)
(
    _DIAGNOSTIC_WARMER_MODE,
    _DIAGNOSTIC_WARMER_CONFIGURED_LANES,
    _DIAGNOSTIC_WARMER_INVALID_CONFIG,
) = _parse_diagnostic_warmer_config()
# Interval (s). 0/unset => auto = 0.8 * min(TTL) so raising TTL auto-widens the interval.
_DIAGNOSTIC_WARMER_INTERVAL_S_RAW = float(os.environ.get("PITH_DIAGNOSTIC_WARMER_INTERVAL_S", "0") or 0)
# Watchdog: alert when a lane's last_success_age_ms exceeds N * max_stale_ms.
_DIAGNOSTIC_WATCHDOG_BREACH_MULT = max(1, _env_int("PITH_DIAGNOSTIC_WATCHDOG_BREACH_MULT", 3))
# Watchdog may enqueue a normal refresh on breach (never a slot reset). Default ON when warmer on.
_DIAGNOSTIC_WATCHDOG_ENQUEUE_REFRESH = _env_bool("PITH_DIAGNOSTIC_WATCHDOG_ENQUEUE_REFRESH", True)

_diagnostic_warmer_stop_event = threading.Event()
_diagnostic_warmer_thread: threading.Thread | None = None
_DIAGNOSTIC_WARMER_LOCK = threading.Lock()
_DIAGNOSTIC_WARMER_NEXT_INDEX = 0
_DIAGNOSTIC_WARMER_OBSERVABILITY: dict[str, int | float | str | bool | None] = {
    "enabled": _DIAGNOSTIC_WARMER_ENABLED,
    "mode": _DIAGNOSTIC_WARMER_MODE,
    "alive": False,
    "tick_count": 0,
    "warm_submitted_count": 0,
    "watchdog_breach_count": 0,
    "last_tick_monotonic": None,  # internal; surfaced as last_tick_age_ms
    "last_breach_lane": None,
    "last_submitted_lane": None,
    "interval_s": None,
    "invalid_config": _DIAGNOSTIC_WARMER_INVALID_CONFIG,
}

# EUNOMIA-127: contention-immune read-only concept-integrity probe.
# Orthogonal to _DIAGNOSTIC_ENDPOINT_SEMAPHORE: the probe NEVER blocking-acquires the
# diagnostic slot (so it cannot be starved by EUNOMIA-113/125), but bounds its own
# concurrency to avoid stacking heavy reads against the 1.65GB DB (EUNOMIA-116).
_INTEGRITY_PROBE_ENABLED = _env_bool("PITH_INTEGRITY_PROBE_ENABLED", True)
_INTEGRITY_PROBE_SEMAPHORE = threading.Semaphore(max(1, _env_int("PITH_INTEGRITY_PROBE_SLOTS", 1)))
_INTEGRITY_PROBE_SLOT_TIMEOUT_S = float(os.environ.get("PITH_INTEGRITY_PROBE_SLOT_TIMEOUT_S", "2.0"))
# A6: min inter-probe interval. Within the interval, serve the last cached result
# (served_cached=true) instead of re-scanning, so probe+refresh overlap stays rare.
_INTEGRITY_PROBE_MIN_INTERVAL_S = float(os.environ.get("PITH_INTEGRITY_PROBE_MIN_INTERVAL_S", "15"))

_INTEGRITY_PROBE_RESULT_LOCK = threading.Lock()
# (monotonic_ts, payload_dict) of the last successfully computed probe, or None.
_INTEGRITY_PROBE_LAST_RESULT: tuple[float, dict] | None = None

_INTEGRITY_PROBE_OBSERVABILITY: dict[str, int | float | str | bool | None] = {
    "enabled": _INTEGRITY_PROBE_ENABLED,
    "probe_duration_ms": None,  # last successful compute duration
    "probe_slot_acquire_timeout_count": 0,
    "probe_degraded_return_count": 0,
    "probe_refresh_overlap_count": 0,  # times the probe ran while a diagnostic refresh held the slot
    "served_cached_count": 0,
    "last_success_monotonic": None,  # internal; surfaced as last_success_age_ms
}
_INTEGRITY_PROBE_OBSERVABILITY_LOCK = threading.Lock()


def _record_integrity_probe_obs(key: str, *, inc: int = 0, set_value=None) -> None:
    with _INTEGRITY_PROBE_OBSERVABILITY_LOCK:
        if set_value is not None:
            _INTEGRITY_PROBE_OBSERVABILITY[key] = set_value
        if inc:
            _INTEGRITY_PROBE_OBSERVABILITY[key] = int(_INTEGRITY_PROBE_OBSERVABILITY[key] or 0) + inc


def _integrity_probe_observability_snapshot() -> dict:
    """Public snapshot of the probe observability dict.

    A1 (gauntlet2 binding): inline age derivation — do NOT reference the
    non-existent _observability_snapshot_locked_generic and do NOT mutate the
    existing _observability_snapshot_locked. Derive last_success_age_ms from the
    stored last_success_monotonic here.
    """
    with _INTEGRITY_PROBE_OBSERVABILITY_LOCK:
        snapshot = dict(_INTEGRITY_PROBE_OBSERVABILITY)
    last_success = snapshot.pop("last_success_monotonic", None)
    if last_success is not None:
        snapshot["last_success_age_ms"] = round((time.monotonic() - last_success) * 1000)
    else:
        snapshot["last_success_age_ms"] = None
    return snapshot


def _probe_version_chain_integrity(conn) -> dict:
    """Read-only version-chain integrity on the probe's mode=ro conn.

    Mirrors app/ops/diagnostics.py:check_version_chain_integrity() (def line 19)
    queries, but runs on the passed-in read-only connection and returns a dict
    (the diagnostics function takes no args, uses the RW owned conn, and returns
    list[str] — unsuitable for the read-only probe; EUNOMIA-127 spec §2.2/§5 Fix 4).
    """
    violations: list[str] = []
    mismatches = conn.execute("""
        SELECT c.id, c.version as concepts_version, cv.max_version
        FROM concepts c
        LEFT JOIN (
            SELECT id, MAX(version) as max_version
            FROM concept_versions
            GROUP BY id
        ) cv ON c.id = cv.id
        WHERE c.version != cv.max_version OR cv.max_version IS NULL
    """).fetchall()
    for row in mismatches:
        if row["max_version"] is None:
            violations.append(f"Orphaned concept {row['id']}: in concepts table but no version history")
        else:
            violations.append(
                f"Version mismatch {row['id']}: concepts={row['concepts_version']}, latest_history={row['max_version']}"
            )
    all_ids = conn.execute("SELECT DISTINCT id FROM concept_versions").fetchall()
    for id_row in all_ids:
        concept_id = id_row["id"]
        versions = conn.execute(
            "SELECT version FROM concept_versions WHERE id = ? ORDER BY version", (concept_id,)
        ).fetchall()
        version_nums = []
        for v in versions:
            try:
                version_nums.append(int(v["version"][1:]))
            except (ValueError, IndexError):
                violations.append(f"Malformed version {concept_id}: '{v['version']}' is not v<N> format")
        if version_nums:
            expected = list(range(1, max(version_nums) + 1))
            missing = set(expected) - set(version_nums)
            if missing:
                violations.append(
                    f"Version gap {concept_id}: missing {sorted(missing)} in chain {sorted(version_nums)}"
                )
    return {"violation_count": len(violations), "is_healthy": len(violations) == 0, "violations": violations[:50]}


def _run_concept_integrity_probe() -> dict:
    """Read-only, single-flight, min-interval-cached integrity probe.

    Never raises. On any failure path returns {"degraded": True, "reason": ...}.
    Acquires ONLY _INTEGRITY_PROBE_SEMAPHORE, NEVER (blocking) _DIAGNOSTIC_ENDPOINT_SEMAPHORE.
    """
    global _INTEGRITY_PROBE_LAST_RESULT

    from app.storage.connection import diagnostic_read_db
    from app.storage.stats import compute_concept_integrity

    if not _INTEGRITY_PROBE_ENABLED:
        _record_integrity_probe_obs("probe_degraded_return_count", inc=1)
        return {
            "source": "read_only_probe",
            "slot_contended": False,
            "computed_at": None,
            "duration_ms": None,
            "served_cached": False,
            "degraded": True,
            "reason": "disabled",
            "integrity": None,
            "version_chain_integrity": None,
        }

    # A6 min-interval: serve last cached result if within the interval.
    now = time.monotonic()
    with _INTEGRITY_PROBE_RESULT_LOCK:
        last = _INTEGRITY_PROBE_LAST_RESULT
    if last is not None and (now - last[0]) < _INTEGRITY_PROBE_MIN_INTERVAL_S:
        _record_integrity_probe_obs("served_cached_count", inc=1)
        cached = dict(last[1])
        cached["served_cached"] = True
        return cached

    acquired = _INTEGRITY_PROBE_SEMAPHORE.acquire(timeout=_INTEGRITY_PROBE_SLOT_TIMEOUT_S)
    if not acquired:
        _record_integrity_probe_obs("probe_slot_acquire_timeout_count", inc=1)
        _record_integrity_probe_obs("probe_degraded_return_count", inc=1)
        return {
            "source": "read_only_probe",
            "slot_contended": True,
            "computed_at": None,
            "duration_ms": None,
            "served_cached": False,
            "degraded": True,
            "reason": "slot_timeout",
            "integrity": None,
            "version_chain_integrity": None,
        }
    try:
        # Re-check the interval after acquiring (another thread may have just refreshed).
        now = time.monotonic()
        with _INTEGRITY_PROBE_RESULT_LOCK:
            last = _INTEGRITY_PROBE_LAST_RESULT
        if last is not None and (now - last[0]) < _INTEGRITY_PROBE_MIN_INTERVAL_S:
            _record_integrity_probe_obs("served_cached_count", inc=1)
            cached = dict(last[1])
            cached["served_cached"] = True
            return cached

        # A7 overlap counter: detect probe running while a diagnostic refresh holds the slot.
        # Non-blocking probe of the diagnostic slot's availability (does NOT acquire/hold it).
        if _DIAGNOSTIC_ENDPOINT_SEMAPHORE.acquire(blocking=False):
            _DIAGNOSTIC_ENDPOINT_SEMAPHORE.release()  # available -> no refresh in flight
        else:
            _record_integrity_probe_obs("probe_refresh_overlap_count", inc=1)

        started = time.perf_counter()
        with diagnostic_read_db("concept_integrity_probe") as conn:
            integrity = compute_concept_integrity(conn)
            version_chain = _probe_version_chain_integrity(conn)
        duration_ms = round((time.perf_counter() - started) * 1000)
        payload = {
            "source": "read_only_probe",
            "slot_contended": False,
            "computed_at": _utc_now_iso(),
            "duration_ms": duration_ms,
            "served_cached": False,
            "degraded": False,
            "integrity": integrity,
            "version_chain_integrity": version_chain,
        }
        with _INTEGRITY_PROBE_RESULT_LOCK:
            _INTEGRITY_PROBE_LAST_RESULT = (time.monotonic(), dict(payload))
        _record_integrity_probe_obs("probe_duration_ms", set_value=duration_ms)
        _record_integrity_probe_obs("last_success_monotonic", set_value=time.monotonic())
        return payload
    except Exception as e:
        _record_integrity_probe_obs("probe_degraded_return_count", inc=1)
        logger.warning("concept_integrity_probe failed: %s", e, exc_info=True)
        return {
            "source": "read_only_probe",
            "slot_contended": False,
            "computed_at": None,
            "duration_ms": None,
            "served_cached": False,
            "degraded": True,
            "reason": "error",
            "integrity": None,
            "version_chain_integrity": None,
        }
    finally:
        _INTEGRITY_PROBE_SEMAPHORE.release()


def _diagnostic_warmer_interval_s() -> float:
    """Resolve the warm interval. interval MUST be < min(TTL) so a reader's max cache age
    (~interval) stays within the fresh window. Auto = 0.8 * min(TTL) when unset/<=0."""
    min_ttl = min(_FAST_STATS_CACHE_TTL_S, _FAST_HEALTH_CACHE_TTL_S, _KNOWLEDGE_AREAS_CACHE_TTL_S)
    if _DIAGNOSTIC_WARMER_INTERVAL_S_RAW and _DIAGNOSTIC_WARMER_INTERVAL_S_RAW > 0:
        interval = _DIAGNOSTIC_WARMER_INTERVAL_S_RAW
    else:
        interval = 0.8 * min_ttl
    # Clamp: keep strictly under the fresh window (90% of min TTL ceiling) and >= 0.5s floor.
    ceiling = max(0.5, 0.9 * min_ttl)
    return max(0.5, min(interval, ceiling))


def _diagnostic_warmer_lanes() -> tuple[tuple[str, threading.Lock, object, float, object, object], ...]:
    all_lanes = {
        "fast_stats": (
            "fast_stats",
            _FAST_STATS_CACHE_LOCK,
            lambda: _FAST_STATS_CACHE,
            _FAST_STATS_CACHE_TTL_S,
            _ensure_fast_stats_refresh_started,
            _fast_stats_observability_snapshot,
        ),
        "fast_health": (
            "fast_health",
            _FAST_HEALTH_CACHE_LOCK,
            lambda: _FAST_HEALTH_CACHE,
            _FAST_HEALTH_CACHE_TTL_S,
            _ensure_fast_health_refresh_started,
            _fast_health_observability_snapshot,
        ),
        "knowledge_areas": (
            "knowledge_areas",
            _KNOWLEDGE_AREAS_CACHE_LOCK,
            lambda: _KNOWLEDGE_AREAS_CACHE,
            _KNOWLEDGE_AREAS_CACHE_TTL_S,
            _ensure_knowledge_areas_refresh_started,
            _knowledge_areas_observability_snapshot,
        ),
    }
    if _DIAGNOSTIC_WARMER_INVALID_CONFIG:
        return ()
    return tuple(all_lanes[name] for name in _DIAGNOSTIC_WARMER_CONFIGURED_LANES)


def _diagnostic_lane_future(name: str) -> concurrent.futures.Future | None:
    if name == "fast_stats":
        with _FAST_STATS_REFRESH_LOCK:
            return _FAST_STATS_REFRESH_FUTURE
    if name == "fast_health":
        with _FAST_HEALTH_REFRESH_LOCK:
            return _FAST_HEALTH_REFRESH_FUTURE
    if name == "knowledge_areas":
        with _KNOWLEDGE_AREAS_REFRESH_LOCK:
            return _KNOWLEDGE_AREAS_REFRESH_FUTURE
    return None


def _diagnostic_refresh_in_flight() -> bool:
    for lane in _DIAGNOSTIC_WARMER_ALLOWED_LANES:
        future = _diagnostic_lane_future(lane)
        if future is not None and not future.done():
            return True
    return False


def _diagnostic_warmer_lane_due(lane: tuple, now: float, interval_ms: float) -> bool:
    _name, lock, get_cache, ttl_s, _ensure_refresh, _obs_snapshot = lane
    ttl_ms = ttl_s * 1000
    jit_threshold_ms = max(0.0, ttl_ms - interval_ms)
    with lock:
        cache = get_cache()
        age_ms = None if cache is None else int((now - cache[0]) * 1000)
    return age_ms is None or age_ms >= jit_threshold_ms


def _submit_diagnostic_warmer_lane(name: str, ensure_refresh) -> None:
    previous_future = _diagnostic_lane_future(name)
    ensure_refresh()
    if previous_future is None or previous_future.done():
        with _DIAGNOSTIC_WARMER_LOCK:
            _DIAGNOSTIC_WARMER_OBSERVABILITY["warm_submitted_count"] = (
                int(_DIAGNOSTIC_WARMER_OBSERVABILITY["warm_submitted_count"] or 0) + 1
            )
            _DIAGNOSTIC_WARMER_OBSERVABILITY["last_submitted_lane"] = name


def _diagnostic_warmer_watchdog(lanes: tuple[tuple, ...], *, enqueue_refresh: bool) -> None:
    for name, _lock, _get_cache, _ttl_s, ensure_refresh, obs_snapshot in lanes:
        try:
            snap = obs_snapshot()
            age_success = snap.get("last_success_age_ms")
            max_stale_ms = _fast_stats_max_stale_ms()  # shared 60s SLO bound
            if age_success is not None and age_success > _DIAGNOSTIC_WATCHDOG_BREACH_MULT * max_stale_ms:
                logger.error(
                    "diagnostic_warmer watchdog breach lane=%s last_success_age_ms=%s "
                    "threshold_ms=%s slot_acquire_timeout_count=%s last_refresh_error=%s",
                    name,
                    age_success,
                    _DIAGNOSTIC_WATCHDOG_BREACH_MULT * max_stale_ms,
                    snap.get("slot_acquire_timeout_count"),
                    snap.get("last_refresh_error"),
                )
                with _DIAGNOSTIC_WARMER_LOCK:
                    _DIAGNOSTIC_WARMER_OBSERVABILITY["watchdog_breach_count"] = (
                        int(_DIAGNOSTIC_WARMER_OBSERVABILITY["watchdog_breach_count"] or 0) + 1
                    )
                    _DIAGNOSTIC_WARMER_OBSERVABILITY["last_breach_lane"] = name
                if enqueue_refresh:
                    ensure_refresh()  # normal refresh only — NEVER a semaphore reset (gauntlet1 A4)
        except Exception:
            logger.debug("diagnostic_warmer watchdog error lane=%s", name, exc_info=True)


def _warm_one_tick_all_lanes(lanes: tuple[tuple, ...]) -> None:
    interval_ms = _diagnostic_warmer_interval_s() * 1000
    now = time.monotonic()
    for name, lock, get_cache, ttl_s, ensure_refresh, obs_snapshot in lanes:
        try:
            if _diagnostic_warmer_lane_due(
                (name, lock, get_cache, ttl_s, ensure_refresh, obs_snapshot), now, interval_ms
            ):
                _submit_diagnostic_warmer_lane(name, ensure_refresh)
        except Exception:
            logger.debug("diagnostic_warmer tick error lane=%s", name, exc_info=True)
    _diagnostic_warmer_watchdog(lanes, enqueue_refresh=_DIAGNOSTIC_WATCHDOG_ENQUEUE_REFRESH)


def _warm_one_tick_safe_sequential(lanes: tuple[tuple, ...]) -> None:
    global _DIAGNOSTIC_WARMER_NEXT_INDEX
    if _diagnostic_refresh_in_flight():
        return
    interval_ms = _diagnostic_warmer_interval_s() * 1000
    now = time.monotonic()
    lane_count = len(lanes)
    if lane_count == 0:
        return
    with _DIAGNOSTIC_WARMER_LOCK:
        start_index = _DIAGNOSTIC_WARMER_NEXT_INDEX % lane_count
    for offset in range(lane_count):
        lane_index = (start_index + offset) % lane_count
        name, lock, get_cache, ttl_s, ensure_refresh, obs_snapshot = lanes[lane_index]
        try:
            if _diagnostic_warmer_lane_due(
                (name, lock, get_cache, ttl_s, ensure_refresh, obs_snapshot), now, interval_ms
            ):
                _submit_diagnostic_warmer_lane(name, ensure_refresh)
                with _DIAGNOSTIC_WARMER_LOCK:
                    _DIAGNOSTIC_WARMER_NEXT_INDEX = (lane_index + 1) % lane_count
                break
        except Exception:
            logger.debug("diagnostic_warmer tick error lane=%s", name, exc_info=True)
    _diagnostic_warmer_watchdog(lanes, enqueue_refresh=False)


def _warm_one_tick() -> None:
    """Warm diagnostic caches according to the configured mode.

    ``all_lanes`` preserves legacy behavior for explicit rollback testing.
    ``safe_sequential`` submits at most one eligible lane per tick and skips
    submission while any diagnostic refresh future is still in flight.
    """
    lanes = _diagnostic_warmer_lanes()
    if _DIAGNOSTIC_WARMER_INVALID_CONFIG:
        logger.error("diagnostic_warmer invalid config: %s", _DIAGNOSTIC_WARMER_INVALID_CONFIG)
        return
    if _DIAGNOSTIC_WARMER_MODE == "safe_sequential":
        _warm_one_tick_safe_sequential(lanes)
        return
    _warm_one_tick_all_lanes(lanes)


def _diagnostic_warmer_loop() -> None:
    interval = _diagnostic_warmer_interval_s()
    with _DIAGNOSTIC_WARMER_LOCK:
        _DIAGNOSTIC_WARMER_OBSERVABILITY["alive"] = True
        _DIAGNOSTIC_WARMER_OBSERVABILITY["interval_s"] = interval
    try:
        while not _diagnostic_warmer_stop_event.is_set():
            _warm_one_tick()
            with _DIAGNOSTIC_WARMER_LOCK:
                _DIAGNOSTIC_WARMER_OBSERVABILITY["tick_count"] = (
                    int(_DIAGNOSTIC_WARMER_OBSERVABILITY["tick_count"] or 0) + 1
                )
                _DIAGNOSTIC_WARMER_OBSERVABILITY["last_tick_monotonic"] = time.monotonic()
            _diagnostic_warmer_stop_event.wait(timeout=interval)  # interruptible sleep
    finally:
        with _DIAGNOSTIC_WARMER_LOCK:
            _DIAGNOSTIC_WARMER_OBSERVABILITY["alive"] = False


def start_diagnostic_warmer() -> None:
    """Start the warmer daemon thread if enabled. Idempotent."""
    global _diagnostic_warmer_thread
    if not _DIAGNOSTIC_WARMER_ENABLED:
        logger.info("diagnostic_warmer disabled (PITH_DIAGNOSTIC_WARMER_ENABLED off)")
        return
    if _DIAGNOSTIC_WARMER_INVALID_CONFIG:
        logger.error("diagnostic_warmer disabled by invalid config: %s", _DIAGNOSTIC_WARMER_INVALID_CONFIG)
        return
    with _DIAGNOSTIC_WARMER_LOCK:
        if _diagnostic_warmer_thread is not None and _diagnostic_warmer_thread.is_alive():
            return
        _diagnostic_warmer_stop_event.clear()
        _diagnostic_warmer_thread = threading.Thread(
            target=_diagnostic_warmer_loop, name="pith-diagnostic-warmer", daemon=True
        )
        _diagnostic_warmer_thread.start()
    logger.info(
        "diagnostic_warmer started mode=%s lanes=%s interval_s=%.2f breach_mult=%d",
        _DIAGNOSTIC_WARMER_MODE,
        ",".join(_DIAGNOSTIC_WARMER_CONFIGURED_LANES),
        _diagnostic_warmer_interval_s(),
        _DIAGNOSTIC_WATCHDOG_BREACH_MULT,
    )


def shutdown_diagnostic_warmer(wait: bool = True, timeout: float = 5.0) -> None:
    """Stop the warmer thread (kill switch / graceful shutdown)."""
    _diagnostic_warmer_stop_event.set()
    thread = _diagnostic_warmer_thread
    if wait and thread is not None and thread.is_alive():
        thread.join(timeout=timeout)


def _diagnostic_warmer_snapshot() -> dict:
    """Public health block. Surfaces warmer liveness + per-lane refresh_worker_last_success_age_ms.

    EUNOMIA-128: also surfaces a read-only ``diagnostic_slot_saturation`` summary — the
    configured slot count, the measured-safe ceiling (annotated with the DB scale it was
    validated at), and the cumulative slot-acquire-timeout total summed across the three
    background-refresh lanes. This is the signal the saturation monitor reads to decide
    whether raising PITH_DIAGNOSTIC_ENDPOINT_SLOTS is justified. Pure aggregation of
    existing per-lane counters: no SQL, no slot/semaphore behavior change.
    """
    with _DIAGNOSTIC_WARMER_LOCK:
        snap = dict(_DIAGNOSTIC_WARMER_OBSERVABILITY)
    last_tick = snap.pop("last_tick_monotonic", None)
    snap["last_tick_age_ms"] = None if last_tick is None else round((time.monotonic() - last_tick) * 1000)
    snap["mode"] = _DIAGNOSTIC_WARMER_MODE
    snap["configured_lanes"] = list(_DIAGNOSTIC_WARMER_CONFIGURED_LANES)
    snap["invalid_config"] = _DIAGNOSTIC_WARMER_INVALID_CONFIG
    fast_stats_obs = _fast_stats_observability_snapshot()
    fast_health_obs = _fast_health_observability_snapshot()
    knowledge_areas_obs = _knowledge_areas_observability_snapshot()
    snap["refresh_worker_last_success_age_ms"] = {
        "fast_stats": fast_stats_obs.get("last_success_age_ms"),
        "fast_health": fast_health_obs.get("last_success_age_ms"),
        "knowledge_areas": knowledge_areas_obs.get("last_success_age_ms"),
    }
    # EUNOMIA-128: read-only saturation summary. Sums the per-lane slot-acquire-timeout
    # counters. The integrity probe's distinct ``probe_slot_acquire_timeout_count`` is
    # intentionally EXCLUDED — it has its own single-flight slot (mode=ro). The counter is
    # monotonic and reset only on process restart, so ``saturated`` is a cumulative-since-
    # start signal; the live raise-trigger is the monitor's delta-over-window, not this bool.
    slot_acquire_timeout_total = (
        int(fast_stats_obs.get("slot_acquire_timeout_count") or 0)
        + int(fast_health_obs.get("slot_acquire_timeout_count") or 0)
        + int(knowledge_areas_obs.get("slot_acquire_timeout_count") or 0)
    )
    snap["diagnostic_slot_saturation"] = {
        "slot_count": _DIAGNOSTIC_ENDPOINT_SLOT_COUNT,
        # validated SAFE at 1.65GB WAL DB / 35,378 concepts (EUNOMIA-128, 2026-06-16);
        # re-run the 2-slot experiment before raising if the DB has grown materially.
        "validated_max_slots": 2,
        "validated_at_db_bytes": 1_650_000_000,
        "validated_at_concept_count": 35_378,
        "slot_acquire_timeout_total": slot_acquire_timeout_total,
        "saturated": slot_acquire_timeout_total > 0,
    }
    return snap


def _build_git_provenance() -> dict:
    """Compare imported runtime code against the current worktree HEAD."""
    runtime_git_head = _read_git_head_commit()
    code_identity_head = _GIT_COMMIT if _GIT_COMMIT_SOURCE == "deploy_metadata" else runtime_git_head
    matches_head = _git_commits_match(_GIT_COMMIT, code_identity_head)
    canonical_head = _read_canonical_head(code_identity_head)
    matches_canonical = _git_commits_match(code_identity_head, canonical_head)
    return {
        "git_commit": _GIT_COMMIT,
        "git_commit_source": _GIT_COMMIT_SOURCE,
        "git_branch": _GIT_BRANCH,
        "git_dirty": _GIT_DIRTY,
        "git_current_head": code_identity_head,
        "git_commit_matches_head": matches_head,
        "canonical_head": canonical_head,
        "runtime_head": code_identity_head,
        "runtime_git_head": runtime_git_head,
        "runtime_matches_canonical": matches_canonical,
        "canonical_repo_root": str(_CANONICAL_REPO_ROOT),
        "deploy_metadata_path": str(_DEPLOY_METADATA_PATH),
    }


def _read_canonical_head(runtime_head: str) -> str:
    if not _CANONICAL_REPO_ROOT.exists() or _CANONICAL_REPO_ROOT == _REPO_ROOT:
        return runtime_head
    try:
        return _read_git_head_commit(_CANONICAL_REPO_ROOT)
    except Exception:
        return runtime_head


from app.api.write_durability import (
    ManagedReplayAuthority,
    WriteReplayState,
    abandon_write_request,
    begin_write_request,
    commit_managed_write_requests_for_episode,
    commit_write_request,
    fail_write_request,
    get_write_request_status,
)
from app.core.brain_lock import BrainLockError, acquire_brain_lock, release_brain_lock
from app.core.datetime_utils import _ensure_aware, _utc_now, _utc_now_iso
from app.governance.runtime_install_guard import RuntimeInstallGuardError, ensure_safe_installed_runtime

# Load .env for dev API key persistence (e.g., ANTHROPIC_API_KEY for Tier 2 LLM).
# python-dotenv won't override existing env vars, so explicit exports still win.
try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass  # python-dotenv optional in production

# RETRIEVAL-057/INGEST-034: Re-compute feature flags that may have been cached
# before load_dotenv() ran (app/__init__.py import chain loads config.py early)
import app.core.config as _cfg

_cfg.EE_ENABLED = _cfg.os.environ.get("PITH_EVENT_EXTRACTION", "").lower() in ("1", "true", "yes")
_cfg.PROSPECTIVE_INDEXING_ENABLED = _cfg.os.environ.get("PITH_PROSPECTIVE_INDEXING", "0") == "1"
_cfg.SESSION_LEARN_SYNC_WAIT_SECONDS = float(
    os.environ.get("PITH_SESSION_LEARN_SYNC_WAIT_SECONDS", str(_cfg.SESSION_LEARN_SYNC_WAIT_SECONDS))
)
_cfg.SESSION_LEARN_PROCESSING_RETRY_AFTER_SECONDS = float(
    os.environ.get(
        "PITH_SESSION_LEARN_PROCESSING_RETRY_AFTER_SECONDS",
        str(_cfg.SESSION_LEARN_PROCESSING_RETRY_AFTER_SECONDS),
    )
)
_cfg.SESSION_LEARN_EXECUTOR_WORKERS = int(
    os.environ.get("PITH_SESSION_LEARN_EXECUTOR_WORKERS", str(_cfg.SESSION_LEARN_EXECUTOR_WORKERS))
)
_cfg.SESSION_LEARN_LIFECYCLE_JOBS_ENABLED = os.environ.get(
    "PITH_SESSION_LEARN_LIFECYCLE_JOBS_ENABLED",
    str(_cfg.SESSION_LEARN_LIFECYCLE_JOBS_ENABLED).lower(),
).lower() in ("1", "true", "yes")
_cfg.LIFECYCLE_JOBS_ENABLED = os.environ.get(
    "PITH_LIFECYCLE_JOBS_ENABLED",
    str(_cfg.LIFECYCLE_JOBS_ENABLED).lower(),
).lower() in ("1", "true", "yes")
_cfg.LIFECYCLE_JOBS_FALLBACK_DIRECT = os.environ.get(
    "PITH_LIFECYCLE_JOBS_FALLBACK_DIRECT",
    str(_cfg.LIFECYCLE_JOBS_FALLBACK_DIRECT).lower(),
).lower() in ("1", "true", "yes")
_cfg.LIFECYCLE_WORKERS = max(1, int(os.environ.get("PITH_LIFECYCLE_WORKERS", str(_cfg.LIFECYCLE_WORKERS))))
_cfg.LIFECYCLE_JOB_LEASE_SECONDS = int(
    os.environ.get("PITH_LIFECYCLE_JOB_LEASE_SECONDS", str(_cfg.LIFECYCLE_JOB_LEASE_SECONDS))
)
_cfg.LIFECYCLE_DRAIN_STUCK_SECONDS = int(
    os.environ.get("PITH_LIFECYCLE_DRAIN_STUCK_SECONDS", str(_cfg.LIFECYCLE_DRAIN_STUCK_SECONDS))
)
_cfg.LIFECYCLE_DRAIN_WALL_BUDGET_SECONDS = float(
    os.environ.get("PITH_LIFECYCLE_DRAIN_WALL_BUDGET_SECONDS", str(_cfg.LIFECYCLE_DRAIN_WALL_BUDGET_SECONDS))
)
_cfg.LIFECYCLE_JOB_MAX_ATTEMPTS = int(
    os.environ.get("PITH_LIFECYCLE_JOB_MAX_ATTEMPTS", str(_cfg.LIFECYCLE_JOB_MAX_ATTEMPTS))
)
_cfg.LIFECYCLE_JOB_MAX_DEFERRALS = int(
    os.environ.get("PITH_LIFECYCLE_JOB_MAX_DEFERRALS", str(_cfg.LIFECYCLE_JOB_MAX_DEFERRALS))
)
_cfg.LIFECYCLE_JOB_DEFER_MAX_AGE_SECONDS = float(
    os.environ.get(
        "PITH_LIFECYCLE_JOB_DEFER_MAX_AGE_SECONDS",
        str(_cfg.LIFECYCLE_JOB_DEFER_MAX_AGE_SECONDS),
    )
)
_cfg.LIFECYCLE_JOB_RETRY_SECONDS = int(
    os.environ.get("PITH_LIFECYCLE_JOB_RETRY_SECONDS", str(_cfg.LIFECYCLE_JOB_RETRY_SECONDS))
)
_cfg.LIFECYCLE_JOB_CLEANUP_DAYS = int(
    os.environ.get("PITH_LIFECYCLE_JOB_CLEANUP_DAYS", str(_cfg.LIFECYCLE_JOB_CLEANUP_DAYS))
)
_cfg.LIFECYCLE_SUPERVISOR_ENABLED = os.environ.get(
    "PITH_LIFECYCLE_SUPERVISOR_ENABLED",
    str(_cfg.LIFECYCLE_JOBS_ENABLED).lower(),
).lower() in ("1", "true", "yes")
_cfg.LIFECYCLE_SUPERVISOR_INTERVAL_SECONDS = float(
    os.environ.get(
        "PITH_LIFECYCLE_SUPERVISOR_INTERVAL_SECONDS",
        str(_cfg.LIFECYCLE_SUPERVISOR_INTERVAL_SECONDS),
    )
)
_cfg.LIFECYCLE_SUPERVISOR_BATCH_SIZE = int(
    os.environ.get("PITH_LIFECYCLE_SUPERVISOR_BATCH_SIZE", str(_cfg.LIFECYCLE_SUPERVISOR_BATCH_SIZE))
)
_cfg.LIFECYCLE_SUPERVISOR_MAX_WALL_SECONDS = float(
    os.environ.get(
        "PITH_LIFECYCLE_SUPERVISOR_MAX_WALL_SECONDS",
        str(_cfg.LIFECYCLE_SUPERVISOR_MAX_WALL_SECONDS),
    )
)
_cfg.LIFECYCLE_SUPERVISOR_STARVATION_SECONDS = float(
    os.environ.get(
        "PITH_LIFECYCLE_SUPERVISOR_STARVATION_SECONDS",
        str(_cfg.LIFECYCLE_SUPERVISOR_STARVATION_SECONDS),
    )
)
_cfg.REFLECTION_DURABLE_JOBS_ENABLED = os.environ.get(
    "PITH_REFLECTION_DURABLE_JOBS_ENABLED",
    str(_cfg.LIFECYCLE_JOBS_ENABLED).lower(),
).lower() in ("1", "true", "yes")
_cfg.REFLECTION_COMPLETION_MONITOR_ENABLED = os.environ.get(
    "PITH_REFLECTION_COMPLETION_MONITOR_ENABLED",
    str(_cfg.REFLECTION_DURABLE_JOBS_ENABLED).lower(),
).lower() in ("1", "true", "yes")


import logging
from collections.abc import Callable
from dataclasses import asdict, dataclass
from importlib import import_module
from typing import Any

from fastapi import BackgroundTasks, Depends, FastAPI, Header, HTTPException, Request, Response
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import (
    BaseModel as PydanticBaseModel,
)
from pydantic import (
    Field,
    StrictBool,
    StrictInt,
    ValidationError,
)

from app.cognitive.learning import create_concept, evolve_concept, validate_proposal
from app.core.foreground_contract import (
    FOREGROUND_CONTRACT_CIRCUIT_OPEN_METRIC,
    FOREGROUND_CONTRACT_DECISION_METRIC,
)
from app.core.logging_config import setup_logging
from app.core.models import (
    Association,
    AutoAssociateBatchRequest,
    AutoAssociateSingleRequest,
    ConceptEvolution,
    ConceptProposal,
    ConversationTurnRequest,
    SearchQuery,
    SearchResult,
    SessionBindingEnvelope,
    SessionEndRequest,
    SessionInfo,
    SessionLearnRequest,
    SessionLearnResponse,
)
from app.core.request_identity import new_conversation_turn_request_id
from app.storage import (
    _db,
    _db_immediate,
    _invalidate_associations_cache,
    add_association,
    count_associations,
    get_distribution_report,
    get_memory_projection_data,
    get_related_concepts,
    list_archived_concepts,
    list_concepts_full,
    list_sessions,
    load_concept,
    load_session,
    load_write_request_replay,
    restore_concept,
    run_storage_migration,
    save_concept,
    update_concept_data,
)
from app.storage.connection import read_snapshot_db, request_db_scope

# Initialize logging
setup_logging()
logger = logging.getLogger(__name__)


class _LazyImportProxy:
    """Defer heavyweight imports until first real use.

    This keeps module import time low enough for liveness startup work while
    preserving the existing call sites throughout the server module.
    """

    def __init__(self, loader: Callable[[], Any]):
        self._loader = loader
        self._value: Any | None = None

    def _load(self) -> Any:
        if self._value is None:
            self._value = self._loader()
        return self._value

    def __getattr__(self, name: str) -> Any:
        return getattr(self._load(), name)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self._load()(*args, **kwargs)


causal = _LazyImportProxy(lambda: import_module("app.retrieval.causal"))
question_queue = _LazyImportProxy(lambda: import_module("app.features.question_queue"))
temporal = _LazyImportProxy(lambda: import_module("app.retrieval.temporal"))
curiosity_engine = _LazyImportProxy(lambda: import_module("app.features.curiosity").curiosity_engine)
goal_directed = _LazyImportProxy(lambda: import_module("app.features.goal_directed").goal_directed)
predictive_activation = _LazyImportProxy(lambda: import_module("app.retrieval.predictive").predictive_activation)
reflection_engine = _LazyImportProxy(lambda: import_module("app.cognitive.reflection").reflection_engine)
retrieval_engine = _LazyImportProxy(lambda: import_module("app.retrieval").retrieval_engine)
conversation_processor = _LazyImportProxy(lambda: import_module("app.cognitive.retrospective").conversation_processor)
self_model_manager = _LazyImportProxy(lambda: import_module("app.session.self_model").self_model_manager)
session_manager = _LazyImportProxy(lambda: import_module("app.session").session_manager)


def auto_associate_batch(*args: Any, **kwargs: Any) -> Any:
    return import_module("app.cognitive.association").auto_associate_batch(*args, **kwargs)


def auto_associate_single(*args: Any, **kwargs: Any) -> Any:
    return import_module("app.cognitive.association").auto_associate_single(*args, **kwargs)


# MATURITY-001: Maturities blocked from external API results
_BLOCKED_MATURITIES = {"QUARANTINED", "DISCARDED"}

SERVER_VERSION = os.environ.get("PITH_VERSION", "1.0.12")

app = FastAPI(
    title="Pith Server",
    version=SERVER_VERSION,
    description="AI Learning Architecture with versioned conceptual memory",
)


def _redact_request_validation_errors(errors: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Remove managed capability input from FastAPI's otherwise-echoing 422 body."""

    def _redact(value: Any, *, capability_scope: bool = False) -> Any:
        if isinstance(value, dict):
            return {
                key: ("[redacted]" if str(key) == "capability" else _redact(item, capability_scope=capability_scope))
                for key, item in value.items()
            }
        if isinstance(value, list):
            return [_redact(item, capability_scope=capability_scope) for item in value]
        if isinstance(value, tuple):
            return tuple(_redact(item, capability_scope=capability_scope) for item in value)
        return "[redacted]" if capability_scope else value

    redacted: list[dict[str, Any]] = []
    for error in errors:
        item = dict(error)
        loc = tuple(item.get("loc") or ())
        capability_scope = "binding" in loc and "capability" in loc
        if "input" in item:
            item["input"] = _redact(item["input"], capability_scope=capability_scope)
        if "ctx" in item:
            item["ctx"] = _redact(item["ctx"], capability_scope=capability_scope)
        redacted.append(item)
    return redacted


@app.exception_handler(RequestValidationError)
async def _request_validation_exception_handler(
    _request: Request,
    exc: RequestValidationError,
) -> JSONResponse:
    return JSONResponse(
        status_code=422,
        content=jsonable_encoder({"detail": _redact_request_validation_errors(exc.errors())}),
    )


_PITH_ORIENT_CACHE_LOCK = threading.Lock()
_PITH_ORIENT_CACHE: dict[tuple[str], dict[str, Any]] = {}
_PITH_ORIENT_DEFAULT_CACHE_TTL_SECONDS = 15.0


def _pith_orient_cache_ttl_seconds() -> float:
    raw_value = os.environ.get("PITH_ORIENT_CACHE_TTL_SECONDS")
    if raw_value is None:
        return _PITH_ORIENT_DEFAULT_CACHE_TTL_SECONDS
    try:
        return max(0.0, float(raw_value))
    except ValueError:
        return _PITH_ORIENT_DEFAULT_CACHE_TTL_SECONDS


def _pith_orient_payload_hash(payload: dict[str, Any]) -> str:
    data = copy.deepcopy(payload)
    data.pop("generated_at", None)
    data.pop("orientation_hash", None)
    if data.get("workstreams") is None:
        data.pop("workstreams", None)
    return hashlib.sha256(json.dumps(data, sort_keys=True, default=str).encode()).hexdigest()


def _compute_pith_orient_base_payload(time_window: str) -> dict[str, Any]:
    concepts = session_manager._load_all_concepts()
    orientation = session_manager.orient(
        concepts=concepts,
        time_window=time_window,
        include_workstreams=False,
    )
    payload = orientation.model_dump()
    payload.pop("workstreams", None)
    return payload


def _pith_orient_base_payload(time_window: str, *, force_refresh: bool = False) -> dict[str, Any]:
    ttl_seconds = _pith_orient_cache_ttl_seconds()
    if ttl_seconds <= 0:
        return _compute_pith_orient_base_payload(time_window)

    cache_key = (time_window,)
    now = time.monotonic()
    if not force_refresh:
        with _PITH_ORIENT_CACHE_LOCK:
            cached = _PITH_ORIENT_CACHE.get(cache_key)
            if cached and float(cached["expires_at"]) > now:
                return copy.deepcopy(cached["payload"])

    payload = _compute_pith_orient_base_payload(time_window)
    with _PITH_ORIENT_CACHE_LOCK:
        _PITH_ORIENT_CACHE[cache_key] = {
            "expires_at": time.monotonic() + ttl_seconds,
            "payload": copy.deepcopy(payload),
        }
    return payload


def _pith_orient_payload_with_workstreams(
    base_payload: dict[str, Any],
    *,
    workstream_limit: int,
    origin_id: str | None,
    session_id: str | None,
) -> dict[str, Any]:
    payload = copy.deepcopy(base_payload)
    payload["workstreams"] = session_manager._compute_workstreams_status(
        origin_id=origin_id,
        session_id=session_id,
        limit=workstream_limit,
    )
    payload["orientation_hash"] = _pith_orient_payload_hash(payload)
    return payload


app.state.process_state = "starting"
app.state.write_state = "queued"
app.state.retrieval_state = "recovering"
app.state.maintenance_state = "disabled"
app.state.degraded_reason = None
app.state.last_successful_write_at = None
app.state.outbox_depth = 0
app.state.startup_warnings = []
app.state.startup_task = None

# OPS-074: Configurable host/port with sane defaults
PITH_HOST = os.environ.get("PITH_HOST", "127.0.0.1").strip() or "127.0.0.1"
# PERF-FORT-1: Concurrency limiter for heavyweight endpoints.
# Prevents threadpool starvation under concurrent MCP tool calls.
# Value 2 = at most 2 heavy requests process simultaneously;
# others queue (with timeout) rather than crash the server.
import threading as _threading_fort

HEAVY_SEMAPHORE_LIMIT = 2
HEAVY_ENDPOINT_TIMEOUT_S = 30
_HEAVY_ENDPOINT_SEMAPHORE = _threading_fort.Semaphore(HEAVY_SEMAPHORE_LIMIT)
HOOK_ADDITIONAL_CONTEXT_SEMAPHORE_LIMIT = max(
    1,
    _env_int("PITH_HOOK_ADDITIONAL_CONTEXT_SEMAPHORE_LIMIT", 1),
)
HOOK_ADDITIONAL_CONTEXT_TIMEOUT_S = max(
    0.0,
    min(_startup_env_float("PITH_HOOK_ADDITIONAL_CONTEXT_TIMEOUT_S", 0.25), 5.0),
)
_HOOK_ADDITIONAL_CONTEXT_SEMAPHORE = _threading_fort.Semaphore(HOOK_ADDITIONAL_CONTEXT_SEMAPHORE_LIMIT)
_SESSION_LEARN_SYNC_WAIT_SECONDS = max(0.0, min(_cfg.SESSION_LEARN_SYNC_WAIT_SECONDS, 15.0))
_SESSION_LEARN_PROCESSING_RETRY_AFTER_SECONDS = max(0.0, _cfg.SESSION_LEARN_PROCESSING_RETRY_AFTER_SECONDS)
_SESSION_LEARN_EXECUTOR_WORKERS = max(1, _cfg.SESSION_LEARN_EXECUTOR_WORKERS)
_SESSION_LEARN_LIFECYCLE_JOBS_ENABLED = bool(_cfg.SESSION_LEARN_LIFECYCLE_JOBS_ENABLED)
_SESSION_LEARN_LIFECYCLE_PRIORITY = int(os.environ.get("PITH_SESSION_LEARN_LIFECYCLE_PRIORITY", "60"))
_SESSION_LEARN_RECLAIMER_BATCH_SIZE = int(os.environ.get("PITH_SESSION_LEARN_RECLAIMER_BATCH_SIZE", "5"))
_SESSION_LEARN_RECLAIMER_MAX_ATTEMPTS = int(os.environ.get("PITH_SESSION_LEARN_RECLAIMER_MAX_ATTEMPTS", "3"))
_SESSION_LEARN_RECLAIMER_LEASE_SECONDS = int(os.environ.get("PITH_SESSION_LEARN_RECLAIMER_LEASE_SECONDS", "300"))
_SESSION_LEARN_RECLAIMER_RETRY_SECONDS = int(os.environ.get("PITH_SESSION_LEARN_RECLAIMER_RETRY_SECONDS", "60"))
_SESSION_LEARN_EXECUTOR: concurrent.futures.ThreadPoolExecutor | None = None
_SESSION_LEARN_EXECUTOR_LOCK = threading.Lock()
_SESSION_LEARN_RECLAIMER_LOCK = threading.Lock()
_SESSION_LEARN_RECLAIMER_FUTURE: concurrent.futures.Future | None = None
_WRITE_REPLAY_RECLAIMER_LOCK = threading.Lock()
_WRITE_REPLAY_RECLAIMER_FUTURES: dict[str, concurrent.futures.Future] = {}

# ARGUS-C3-F1: Fail-fast with clear message on invalid port
_raw_port = os.environ.get("PITH_PORT", "8000")
try:
    PITH_PORT = int(_raw_port)
except (ValueError, TypeError):
    print(f"FATAL: PITH_PORT must be an integer, got {_raw_port!r}", file=sys.stderr)
    sys.exit(1)
if not (1 <= PITH_PORT <= 65535):
    print(f"FATAL: PITH_PORT must be 1-65535, got {PITH_PORT}", file=sys.stderr)
    sys.exit(1)

# OPS-074: CORS origins derived from configured port — no hardcoded port numbers
_cors_origins = [
    f"http://localhost:{PITH_PORT}",
    f"http://127.0.0.1:{PITH_PORT}",
    "http://localhost:3000",  # Dev frontend
    "http://127.0.0.1:3000",  # Dev frontend
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Route Naming Normalization (ROUTE-COMPAT) ---
# Backward-compatible middleware: rewrites deprecated paths to canonical pith_ paths.
# Old callers (server.js, tests) keep working while we migrate incrementally.
from app.api.route_compat import install_route_compat_middleware

install_route_compat_middleware(app)

# --- API Key Authentication for Write Endpoints (OPS-072) ---


def _ensure_api_key() -> str:
    """Ensure an API key exists — read from env, or auto-generate and persist.

    Priority: PITH_API_KEY env > auto-generate.
    A3: If persistence to ~/.pith/.env fails, still sets os.environ (session-only)
    and logs a warning so operators know the key won't survive restart.
    """
    import secrets

    key = os.environ.get("PITH_API_KEY", "")
    if key:
        return key

    # Auto-generate a key for consumer installs that didn't set one
    key = secrets.token_hex(32)
    os.environ["PITH_API_KEY"] = key

    # Attempt to persist to ~/.pith/.env
    try:
        pith_dir = Path(os.path.expanduser("~/.pith"))
        pith_dir.mkdir(parents=True, exist_ok=True)
        env_file = pith_dir / ".env"

        # Read existing content, append PITH_API_KEY
        existing = env_file.read_text() if env_file.exists() else ""
        if "PITH_API_KEY" not in existing:
            with open(env_file, "a") as f:
                f.write(f"\nPITH_API_KEY={key}\n")
            # A3: Secure file permissions
            os.chmod(env_file, 0o600)
            logger.info(f"Auto-generated PITH_API_KEY persisted to {env_file}")
        else:
            # Read the persisted key from file (was written on a prior start)
            for _line in existing.splitlines():
                if _line.startswith("PITH_API_KEY="):
                    _persisted = _line.split("=", 1)[1].strip()
                    if _persisted:
                        os.environ["PITH_API_KEY"] = _persisted
                        logger.info(
                            "MONITOR-134: Loaded existing PITH_API_KEY from ~/.pith/.env (file fallback active — env var not set)"
                        )
                        try:
                            from app.core.metrics_facade import metrics as _auth_m

                            _auth_m.record("api_key_file_fallback", 1.0)
                        except Exception:
                            pass
                        return _persisted
            # Entry present but empty/malformed — fall through with generated key
            logger.info("PITH_API_KEY in ~/.pith/.env was empty — using generated key")
    except Exception as e:
        # A3: Partial persistence fallback — key works this session but won't survive restart
        logger.warning(
            f"Auto-generated PITH_API_KEY set in env but FAILED to persist to ~/.pith/.env: {e}. "
            f"Key is session-only — will be regenerated on next restart."
        )

    return key


API_KEY = _ensure_api_key()


async def verify_api_key(request: Request):
    """Verify API key on write endpoints. No dev-mode bypass (OPS-072)."""
    key = request.headers.get("X-API-Key", "")
    if key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")


@app.get("/auth/validate", dependencies=[Depends(verify_api_key)])
async def auth_validate():
    """Read-only protected route for local client auth diagnostics."""
    return {"ok": True, "auth": "validated"}


_LOCAL_OPERATOR_HOSTS = {"127.0.0.1", "::1", "localhost", "testclient"}


class AnswerPathPolicyUpdateRequest(PydanticBaseModel):
    """Strict runtime answer-path policy update payload."""

    observe_only: StrictBool
    enforcement_enabled: StrictBool
    ttl_seconds: StrictInt = Field(..., ge=1)
    enforce_modes: list[str] | None = None
    source: str = Field(default="runtime_api", min_length=1, max_length=40)


class AnswerPathPolicyResponse(PydanticBaseModel):
    """Runtime answer-path policy response payload."""

    observe_only: bool
    enforcement_enabled: bool
    source: str
    state: str
    generation: int
    enforce_modes: list[str] = Field(default_factory=list)
    expires_at: str | None = None
    runtime_active: bool
    max_ttl_seconds: int


class AnswerPathPolicyResetRequest(PydanticBaseModel):
    """Runtime answer-path policy reset payload."""

    source: str = Field(default="runtime_api", min_length=1, max_length=40)


def _is_local_request(request: Request) -> bool:
    """Return whether the request originated from the local operator surface."""
    direct_host = getattr(getattr(request, "client", None), "host", None)
    forwarded_for = request.headers.get("X-Forwarded-For", "")
    if forwarded_for:
        first_hop = forwarded_for.split(",", 1)[0].strip()
        if first_hop and first_hop not in _LOCAL_OPERATOR_HOSTS:
            return False
    return direct_host in _LOCAL_OPERATOR_HOSTS


def _require_local_operator(request: Request) -> None:
    """Require local operator access in addition to API-key authentication."""
    if not _is_local_request(request):
        raise HTTPException(
            status_code=403,
            detail="Runtime policy updates require local operator access",
        )


def _record_answer_path_policy_metric(name: str, labels: dict[str, str]) -> None:
    """Record low-cardinality answer-path policy metrics best-effort."""
    try:
        from app.ops.metrics import metrics as _policy_metrics

        _policy_metrics.record(name, 1.0, labels)
    except Exception:
        pass


def _answer_path_policy_response(snapshot) -> AnswerPathPolicyResponse:
    from app.session.answer_path_policy import get_answer_path_policy

    return AnswerPathPolicyResponse(
        **asdict(snapshot),
        max_ttl_seconds=get_answer_path_policy().max_ttl_seconds(),
    )


# MONITOR-076: Sanitize error responses — never leak internal paths or tracebacks.
# In production (PITH_DEBUG != "1"), return generic message; in dev, expose str(e).
_PITH_DEBUG = os.environ.get("PITH_DEBUG", "0") == "1"


# OPS-500-FIX: Retry helper for transient DB lock errors
import sqlite3 as _sqlite3_retry
import time as _time_retry


def _with_db_retry(fn, max_retries=2, backoff=0.5):
    """Execute fn with retry on transient DB lock errors."""
    last_err = None
    for attempt in range(max_retries):
        try:
            return fn()
        except (RuntimeError, _sqlite3_retry.OperationalError) as e:
            err_str = str(e).lower()
            if "deadlock" in err_str or "database is locked" in err_str or "lock" in err_str:
                last_err = e
                if attempt < max_retries - 1:
                    logger.warning(
                        "OPS-500-FIX: Transient DB error on attempt %d/%d, retrying in %.1fs: %s",
                        attempt + 1,
                        max_retries,
                        backoff,
                        e,
                    )
                    _time_retry.sleep(backoff)
                    backoff *= 2
                    continue
            raise
    raise last_err


def _safe_error(exc: Exception) -> str:
    """Return safe error detail: full message in debug mode, generic in production."""
    if _PITH_DEBUG:
        return str(exc)
    return "Internal server error"


def _record_successful_write() -> None:
    app.state.last_successful_write_at = _utc_now_iso()
    app.state.write_state = "accepting"


def _set_degraded_reason(reason: str | None) -> None:
    app.state.degraded_reason = reason
    if reason:
        app.state.retrieval_state = "degraded"


def _build_auth_status(request: Request | None = None) -> dict:
    import hmac

    caller_key = request.headers.get("X-API-Key", "") if request else ""
    key_configured = bool(API_KEY)
    caller_authenticated = key_configured and bool(caller_key) and hmac.compare_digest(caller_key, API_KEY)
    if caller_authenticated:
        write_path = "ok"
    elif not key_configured:
        write_path = "no_key_configured"
    elif not caller_key:
        write_path = "not_provided"
    else:
        write_path = "invalid_key"
    return {
        "key_configured": key_configured,
        "caller_authenticated": caller_authenticated,
        "write_path": write_path,
    }


def _build_ready_state() -> dict:
    process_state = getattr(app.state, "process_state", "starting")
    write_state = getattr(app.state, "write_state", "accepting")
    retrieval_state = getattr(app.state, "retrieval_state", "recovering")
    maintenance_state = getattr(app.state, "maintenance_state", "disabled")
    degraded_reason = getattr(app.state, "degraded_reason", None)
    warnings = list(getattr(app.state, "startup_warnings", []) or [])
    git_provenance = _build_git_provenance()
    commit_matches_head = git_provenance["git_commit_matches_head"]
    runtime_matches_canonical = git_provenance.get("runtime_matches_canonical")
    if commit_matches_head is False:
        if degraded_reason is None:
            degraded_reason = _GIT_MISMATCH_REASON
        warning = (
            f"{_GIT_MISMATCH_REASON}: startup={git_provenance['git_commit']} "
            f"current_head={git_provenance['git_current_head']}"
        )
        if warning not in warnings:
            warnings.append(warning)
    if runtime_matches_canonical is False:
        if degraded_reason is None:
            degraded_reason = _CANONICAL_MISMATCH_REASON
        warning = (
            f"{_CANONICAL_MISMATCH_REASON}: runtime_head={git_provenance['runtime_head']} "
            f"canonical_head={git_provenance['canonical_head']}"
        )
        if warning not in warnings:
            warnings.append(warning)
    mode = "ready"
    if process_state == "blocked" or write_state == "blocked":
        mode = "blocked"
    elif process_state != "running":
        mode = "recovering"
    elif (
        degraded_reason
        or retrieval_state in {"recovering", "degraded"}
        or commit_matches_head is False
        or runtime_matches_canonical is False
    ):
        mode = "degraded"
    try:
        retrieval_index = retrieval_engine.index.get_stats()
        retrieval_index["state"] = retrieval_state
    except Exception as exc:
        retrieval_index = {"state": "unknown", "error": _safe_error(exc)}
    try:
        semantic_full_search_state = retrieval_engine.semantic_full_search_state()
        semantic_warm_readiness = retrieval_engine.semantic_warm_readiness_snapshot()
    except Exception as exc:
        semantic_full_search_state = "unknown"
        semantic_warm_readiness = {"state": "unknown", "error": _safe_error(exc)}
    try:
        from app.retrieval.foreground_embedding import foreground_embedding_process

        foreground_embedding = {
            **foreground_embedding_process.snapshot(),
            "bounded_enabled": _env_flag("PITH_FOREGROUND_EMBEDDING_BOUNDED_ENABLED", False),
            "semantic_enabled": _env_flag("PITH_FOREGROUND_EMBEDDING_ENABLED", True),
            "timeout_ms": max(
                50.0,
                min(2000.0, _startup_env_float("PITH_FOREGROUND_EMBEDDING_SEARCH_TIMEOUT_MS", 600.0)),
            ),
        }
    except Exception as exc:
        foreground_embedding = {"state": "unknown", "error": _safe_error(exc)}
    return {
        "status": "healthy" if process_state in {"starting", "running"} else "stopping",
        "service": "pith",
        "timestamp": _utc_now_iso(),
        "version": SERVER_VERSION,
        **git_provenance,
        "mode": mode,
        "process_state": process_state,
        "write_state": write_state,
        "session_writer_protocol": WRITER_PROTOCOL_VERSION,
        "retrieval_state": retrieval_state,
        "semantic_full_search_state": semantic_full_search_state,
        "semantic_warm_readiness": semantic_warm_readiness,
        "foreground_embedding": foreground_embedding,
        "retrieval_index": retrieval_index,
        "maintenance_state": maintenance_state,
        "degraded_reason": degraded_reason,
        "last_successful_write_at": getattr(app.state, "last_successful_write_at", None),
        "outbox_depth": getattr(app.state, "outbox_depth", 0),
        "startup_warnings": warnings,
    }


def _apply_memory_durability_health(ready: dict, *, lifecycle_jobs: dict, session_learn_queue: dict) -> None:
    """Surface durable-memory debt in overall readiness without marking the process dead."""
    for name, metric in (
        ("lifecycle_jobs", lifecycle_jobs),
        ("session_learn_queue", session_learn_queue),
    ):
        status = metric.get("status")
        if status != "critical":
            continue
        if ready.get("mode") == "ready":
            ready["mode"] = "degraded"
        if not ready.get("degraded_reason"):
            ready["degraded_reason"] = f"memory_durability_{name}_{status}"
        return


def _derive_health_status(ready: dict) -> None:
    failure_states = {"critical", "unhealthy", "error", "failed", "blocked"}
    degraded_states = {"degraded", "warning", "recovering", "unavailable", "stale", "lagging"}
    normal_states = {"ok", "healthy", "ready", "running", "disabled", "available", "idle"}
    liveness_status = str(ready.get("status") or "unknown").lower()
    ready["liveness_status"] = liveness_status
    enabled, config_reason = _health_status_fold_config()
    if not enabled:
        ready["status_contract_version"] = 1
        ready["status"] = liveness_status
        ready["status_reasons"] = ["health_status_fold_disabled"]
        return

    ready["status_contract_version"] = 2
    reasons: list[str] = []
    aggregate = "healthy"
    mode = str(ready.get("mode") or "unknown").lower()
    if liveness_status != "healthy":
        aggregate = "unhealthy"
        reasons.append(f"liveness:{liveness_status}")
    if mode == "blocked":
        aggregate = "unhealthy"
        reasons.append("mode:blocked")
    elif mode != "ready":
        if aggregate != "unhealthy":
            aggregate = "degraded"
        reasons.append(f"mode:{mode}")

    metrics_payload = ready.get("metrics") if isinstance(ready.get("metrics"), dict) else {}
    components = ready.get("components") if isinstance(ready.get("components"), dict) else {}
    for name, raw_state in components.items():
        state = str(raw_state or "unknown").lower()
        if name == "maintenance_scheduler" and state == "external":
            external_state = str(components.get("maintenance_scheduler_external") or "unknown").lower()
            if external_state in {"healthy", "available"}:
                continue
        if state in normal_states:
            continue
        reason = f"component:{name}:{state}"
        if state in failure_states:
            aggregate = "unhealthy"
            reasons.append(reason)
        elif state in degraded_states:
            if aggregate != "unhealthy":
                aggregate = "degraded"
            reasons.append(reason)
        elif state == "unknown":
            payload = metrics_payload.get(name)
            expected_deferred = (
                isinstance(payload, dict)
                and payload.get("deferred") is True
                and payload.get("alert") is False
                and not payload.get("error")
            )
            if not expected_deferred:
                if aggregate != "unhealthy":
                    aggregate = "degraded"
                reasons.append(reason)
        else:
            if aggregate != "unhealthy":
                aggregate = "degraded"
            reasons.extend((reason, f"unrecognized_component_state:{name}:{state}"))

    if config_reason:
        reasons.append(config_reason)
    ready["status"] = aggregate
    ready["status_reasons"] = sorted(set(reasons))


def _external_maintenance_freshness_threshold_hours(scheduler_installed: bool) -> float:
    """Return stale threshold for the configured external maintenance scheduler."""
    return 36.0 if scheduler_installed else 12.0


def _build_external_maintenance_health() -> dict[str, Any]:
    """Summarize external maintenance health without assuming built-in scheduling."""
    import json as _json
    from datetime import datetime as _dt

    from app.core.profile import resolve_data_dir
    from app.ops.maintenance import empty_maintenance_outcome_health, normalize_maintenance_outcome_health

    heartbeat_path = Path(resolve_data_dir()) / "maintenance_heartbeat.json"
    full_heartbeat_path = heartbeat_path.with_name("maintenance_full_heartbeat.json")
    scheduler_dir = Path(os.environ.get("PITH_LAUNCH_AGENTS_DIR", Path.home() / "Library" / "LaunchAgents"))
    scheduler_path = scheduler_dir / "com.pith.maintenance.plist"
    scheduler_installed = scheduler_path.exists()

    base = {
        "scheduler_backend": "launchd",
        "scheduler_installed": scheduler_installed,
        "scheduler_path": str(scheduler_path),
        "heartbeat_path": str(heartbeat_path),
        "external_launchd_scheduler": {
            "backend": "launchd",
            "installed": scheduler_installed,
            "optional": True,
            "path": str(scheduler_path),
            "schedule": "daily 3:00 AM",
        },
    }

    if not heartbeat_path.exists() and not full_heartbeat_path.exists():
        scheduler_state = "scheduled" if scheduler_installed else "not_installed"
        message = (
            "External launchd maintenance is scheduled but no heartbeat exists yet."
            if scheduler_installed
            else "External launchd maintenance is not installed (optional)."
        )
        return {
            **base,
            "status": "never_run" if scheduler_installed else "not_installed",
            "scheduler_state": scheduler_state,
            "alert": False,
            "message": message,
            "outcome_health": empty_maintenance_outcome_health("heartbeat_missing"),
            "heartbeat": {
                "exists": False,
                "path": str(heartbeat_path),
                "source": None,
            },
            "external_launchd_scheduler": {
                **base["external_launchd_scheduler"],
                "state": scheduler_state,
            },
        }

    try:
        latest_run = {}
        if full_heartbeat_path.exists():
            data = _json.loads(full_heartbeat_path.read_text())
            # Diagnostic evidence cannot invalidate authoritative full-run proof.
            try:
                latest_run = _json.loads(heartbeat_path.read_text())
                if not isinstance(latest_run, dict):
                    latest_run = {}
            except (OSError, ValueError):
                pass
        else:
            data = _json.loads(heartbeat_path.read_text())
            latest_run = data
        outcome_health = normalize_maintenance_outcome_health(
            data.get("outcome_health"),
            missing_reason="legacy_heartbeat",
        )
        last_run_raw = data.get("last_run") or data.get("timestamp")
        if not last_run_raw:
            return {
                **base,
                **data,
                "status": "error",
                "scheduler_state": "error",
                "alert": True,
                "message": "maintenance heartbeat missing last_run/timestamp",
                "outcome_health": outcome_health,
            }
        last_run = _ensure_aware(_dt.fromisoformat(last_run_raw))
        hours_since = (_utc_now() - last_run).total_seconds() / 3600
        status = data.get("status", "unknown")
        source = data.get("source") or ("built_in" if data.get("scheduler") == "builtin" else "unknown")
        freshness_threshold_hours = _external_maintenance_freshness_threshold_hours(scheduler_installed)
        freshness_state = "stale" if hours_since > freshness_threshold_hours else "fresh"
        alert = (
            freshness_state == "stale"
            or status in {"error", "errors", "circuit_open"}
            or outcome_health.get("overall_state") == "critical"
        )
        full_run_missing = outcome_health.get("run_scope") != "full" or data.get("dry_run") is True
        if full_run_missing:
            alert = True
            outcome_health = empty_maintenance_outcome_health("full_run_evidence_missing", critical=True)
        return {
            **base,
            **data,
            "source": source,
            "hours_since_last_run": round(hours_since, 1),
            "freshness_threshold_hours": freshness_threshold_hours,
            "freshness_state": freshness_state,
            "scheduler_state": "degraded" if alert else "healthy",
            "alert": alert,
            "outcome_health": outcome_health,
            "full_run_evidence_missing": full_run_missing,
            "latest_run": {
                key: latest_run.get(key) for key in ("last_run", "source", "status", "dry_run", "outcome_health")
            },
            "health_evidence_path": str(full_heartbeat_path if full_heartbeat_path.exists() else heartbeat_path),
            "heartbeat": {
                "exists": True,
                "path": str(heartbeat_path),
                "source": source,
                "status": status,
                "last_run": last_run_raw,
                "hours_since_last_run": round(hours_since, 1),
                "freshness_threshold_hours": freshness_threshold_hours,
                "freshness_state": freshness_state,
            },
            "external_launchd_scheduler": {
                **base["external_launchd_scheduler"],
                "state": "installed" if scheduler_installed else "not_installed",
            },
        }
    except Exception as e:
        return {
            **base,
            "status": "error",
            "scheduler_state": "error",
            "alert": True,
            "message": _safe_error(e),
            "outcome_health": empty_maintenance_outcome_health("heartbeat_unreadable", critical=True),
            "heartbeat": {
                "exists": heartbeat_path.exists(),
                "path": str(heartbeat_path),
                "source": "unknown",
            },
            "external_launchd_scheduler": {
                **base["external_launchd_scheduler"],
                "state": "error",
            },
        }


def _build_maintenance_health() -> dict[str, Any]:
    """Build user-facing maintenance health with effective, built-in, and external sections."""
    external_health = _build_external_maintenance_health()
    built_in_state = getattr(app.state, "maintenance_state", "disabled")
    effective_state, maintenance_mode = _effective_maintenance_state(built_in_state, external_health)

    external_absence_only = (
        built_in_state != "disabled"
        and not external_health.get("scheduler_installed")
        and external_health.get("status") == "not_installed"
    )
    if external_absence_only:
        external_health["alert"] = False
        external_health["message"] = (
            "External launchd scheduler is not installed (optional; built-in maintenance is running)."
        )

    heartbeat = external_health.get("heartbeat", {})
    external_scheduler = external_health.get("external_launchd_scheduler", {})
    return {
        **external_health,
        "effective": {
            "state": effective_state,
            "mode": maintenance_mode,
            "alert": effective_state in {"degraded", "disabled"} and not external_absence_only,
        },
        "built_in_scheduler": {
            "state": built_in_state,
            "default": True,
        },
        "external_launchd_scheduler": {
            **external_scheduler,
            "optional": True,
        },
        "heartbeat": heartbeat,
    }


def _effective_maintenance_state(
    built_in_state: str,
    external_health: dict[str, Any],
) -> tuple[str, str]:
    """Collapse built-in and external states into an honest overall mode/state."""
    if built_in_state != "disabled":
        return built_in_state, "built_in"

    external_state = external_health.get("scheduler_state", "not_installed")
    if external_state in {"healthy", "scheduled"}:
        return "external", "external"
    if external_state in {"degraded", "error"}:
        return "degraded", "external"
    if external_state == "never_run":
        return "scheduled", "external"
    return "disabled", "none"


def _require_thread_reorg_ready(*, require_write: bool = False, require_retrieval_ready: bool = False) -> None:
    """Reject THREAD-004 requests when startup/recovery state makes them unsafe."""
    ready = _build_ready_state()
    if ready["process_state"] != "running":
        raise HTTPException(
            status_code=503,
            detail="THREAD-004 unavailable while server startup is still in progress",
            headers={"Retry-After": "10"},
        )
    if require_write and ready["write_state"] != "accepting":
        raise HTTPException(
            status_code=503,
            detail="THREAD-004 write path not ready yet",
            headers={"Retry-After": "10"},
        )
    if require_retrieval_ready and ready["retrieval_state"] == "recovering":
        raise HTTPException(
            status_code=503,
            detail="THREAD-004 mining unavailable while retrieval recovery is still in progress",
            headers={"Retry-After": "10"},
        )


def _require_retrieval_ready(endpoint_name: str) -> None:
    """Reject latency-sensitive reads while deferred retrieval startup is still warming."""
    ready = _build_ready_state()
    if ready["process_state"] != "running":
        raise HTTPException(
            status_code=503,
            detail=f"{endpoint_name} unavailable while server startup is still in progress",
            headers={"Retry-After": "10"},
        )
    if ready["retrieval_state"] == "recovering":
        raise HTTPException(
            status_code=503,
            detail=f"{endpoint_name} unavailable while retrieval initialization is still in progress",
            headers={"Retry-After": "10"},
        )


def _acquire_thread_reorg_slot() -> None:
    """Reuse the heavy-endpoint limiter for THREAD-004 operations."""
    acquired = _HEAVY_ENDPOINT_SEMAPHORE.acquire(timeout=HEAVY_ENDPOINT_TIMEOUT_S)
    if not acquired:
        raise HTTPException(
            status_code=503,
            detail="Server under heavy load — try again in a few seconds",
            headers={"Retry-After": "3"},
        )


def select_ambient_concepts(
    concept_id: str,
    query: str = "",
    exclude_ids: set = None,
    max_results: int = 2,
) -> list[dict[str, Any]]:
    """C2: Select up to 2 related concepts for ambient_context enrichment.

    Primary: Association graph neighbors sorted by strength. O(1) per concept.
    Fallback: TF-IDF similarity search if graph returns < max_results.
    Hard cap at max_results. Deduplicates against exclude_ids.
    """
    if exclude_ids is None:
        exclude_ids = set()
    exclude_ids.add(concept_id)

    results = []

    # Primary: association graph neighbors
    try:
        neighbors = get_related_concepts(concept_id, max_depth=1)
        for nid in neighbors:
            if nid in exclude_ids:
                continue
            neighbor = load_concept(nid, track_access=False)
            if neighbor:
                results.append(
                    {
                        "concept_id": nid,
                        "summary": (neighbor.summary[:150] + "...")
                        if len(neighbor.summary) > 150
                        else neighbor.summary,
                        "confidence": round(neighbor.confidence, 2),
                        "relation": "associated",
                    }
                )
                exclude_ids.add(nid)
            if len(results) >= max_results:
                break
    except Exception as e:
        logger.debug(f"C2: Association lookup failed for {concept_id}: {e}")

    # Fallback: TF-IDF similarity if < max_results from graph
    if len(results) < max_results and query:
        try:
            search_query = SearchQuery(query=query, max_results=max_results + 2)
            search_results = retrieval_engine.search(search_query)
            for sr in search_results:
                if sr.concept_id in exclude_ids:
                    continue
                results.append(
                    {
                        "concept_id": sr.concept_id,
                        "summary": (sr.summary[:150] + "...") if len(sr.summary) > 150 else sr.summary,
                        "confidence": round(sr.confidence, 2),
                        "relation": "semantically_similar",
                    }
                )
                exclude_ids.add(sr.concept_id)
                if len(results) >= max_results:
                    break
        except Exception as e:
            logger.debug(f"C2: TF-IDF fallback failed: {e}")

    return results[:max_results]


async def _deferred_index_repair(integrity: dict):
    """STABILITY-030: Run index repair in background after startup completes.

    Deferred from startup_event() so health endpoint is available immediately.
    Uses asyncio.to_thread() because repair_index_drift() is synchronous and
    CPU/IO-bound (disk saves every 10 ghost removals).
    """
    import asyncio

    try:
        logger.info(f"Background index repair starting — {integrity['ghosts']} ghosts, {integrity['orphans']} orphans")
        repair = await asyncio.to_thread(retrieval_engine.repair_index_drift, integrity=integrity)
        logger.info(f"Background index repair complete — {repair}")
    except asyncio.CancelledError:
        logger.warning("Background index repair cancelled (shutdown)")
    except Exception as e:
        logger.error(f"Background index repair failed: {e}", exc_info=True)


def _env_flag(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def _stage3b_required_context_prewarm_enabled() -> bool:
    raw = os.environ.get("PITH_STAGE3B_REQUIRED_CONTEXT_PREWARM")
    if raw is not None:
        return raw.strip().lower() in ("1", "true", "yes", "on")
    stage3b_mode = os.environ.get("PITH_STAGE3B_LATENCY_MODE", "shadow").strip().lower()
    return stage3b_mode in {"shadow", "enforce"}


async def _maybe_prewarm_required_context() -> None:
    """Populate required context before retrieval is marked ready."""
    from app.ops.metrics import metrics as _metrics

    if not _stage3b_required_context_prewarm_enabled():
        _metrics.record(
            "ct_stage3b_required_context_prewarm_total",
            1.0,
            {"result": "disabled", "state": "disabled"},
        )
        _metrics.flush()
        logger.info("Startup: Required context prewarm disabled")
        return

    started = time.perf_counter()
    try:
        from app.session.required_context_cache import prewarm_required_context

        stats = await asyncio.to_thread(prewarm_required_context)
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        result = "success" if stats.state != "shutdown" else "shutdown"
        _metrics.record("ct_stage3b_required_context_prewarm_ms", round(elapsed_ms, 2))
        _metrics.record(
            "ct_stage3b_required_context_prewarm_total",
            1.0,
            {"result": result, "state": stats.state},
        )
        _metrics.flush()
        logger.info(
            "Startup: Required context prewarmed state=%s refresh_ms=%.2f always_activate_ms=%.2f firmware_ms=%.2f directives_ms=%.2f",
            stats.state,
            stats.refresh_ms,
            stats.always_activate_ms,
            stats.firmware_ms,
            stats.directives_ms,
        )
    except Exception as e:
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        _metrics.record("ct_stage3b_required_context_prewarm_ms", round(elapsed_ms, 2))
        _metrics.record(
            "ct_stage3b_required_context_prewarm_total",
            1.0,
            {"result": "error", "state": type(e).__name__},
        )
        _metrics.flush()
        severity = "critical" if _env_flag("PITH_STAGE3B_REQUIRED_CONTEXT_PREWARM_REQUIRED", False) else "degraded"
        app.state.startup_warnings.append(
            {
                "component": "required_context_prewarm",
                "severity": severity,
                "message": f"Required context prewarm failed: {e}",
            }
        )
        if severity == "critical":
            _set_degraded_reason("required_context_prewarm_failed")
            raise
        logger.warning("Startup: Required context prewarm failed (degraded): %s", e, exc_info=True)


def _installer_disables_embeddings() -> bool:
    """Return true when the installer explicitly selected TF-IDF fallback."""
    candidate_homes: list[Path] = []
    if os.environ.get("PITH_HOME"):
        candidate_homes.append(Path(os.environ["PITH_HOME"]))
    candidate_homes.extend([_REPO_ROOT.parent, Path(os.path.expanduser("~/.pith"))])

    seen: set[Path] = set()
    capability_files: list[Path] = []
    for home in candidate_homes:
        try:
            resolved_home = home.expanduser().resolve()
        except Exception:
            resolved_home = home.expanduser()
        if resolved_home in seen:
            continue
        seen.add(resolved_home)
        capability_files.append(resolved_home / ".install_capabilities")

    try:
        for capabilities_path in capability_files:
            if not capabilities_path.exists():
                continue
            capabilities = capabilities_path.read_text(encoding="utf-8", errors="ignore").splitlines()
            for line in capabilities:
                key, _, value = line.partition("=")
                if key.strip().lower() == "embeddings":
                    return value.strip().lower() == "false"
    except Exception:
        return False
    return False


async def _warm_embeddings_for_startup() -> None:
    """Warm semantic embeddings without blocking retrieval readiness."""
    try:
        from app.storage.embedding import embedding_engine

        retrieval_engine.record_semantic_warm_readiness(
            state="running",
            source="startup",
            result="startup_warmup_started",
            query_path_warmed=False,
        )
        if not embedding_engine.is_available and _installer_disables_embeddings():
            logger.info("Startup: embedding warmup skipped; installer selected TF-IDF fallback")
            retrieval_engine.record_semantic_warm_readiness(
                state="skipped",
                source="startup",
                result="installer_tfidf_fallback",
                query_path_warmed=False,
            )
            return

        await asyncio.to_thread(embedding_engine.load_model)
        logger.info("Startup: embedding model pre-loaded (PERF-035)")
        await asyncio.to_thread(retrieval_engine._init_embeddings)
        retrieval_engine.record_semantic_warm_readiness(
            state="running",
            source="startup",
            result="index_initialized",
        )
        logger.info(
            "Startup: semantic embedding index warmed: %s concepts (PERF-076)",
            embedding_engine.index_size,
        )
        if embedding_engine.index_size > 0:
            await asyncio.to_thread(
                embedding_engine.search,
                "startup semantic retrieval warmup",
                1,
            )
            retrieval_engine.record_semantic_warm_readiness(
                state="ready",
                source="startup",
                result="success",
                query_path_warmed=True,
            )
            logger.info("Startup: semantic retrieval query path warmed (PERF-076)")
        else:
            retrieval_engine.record_semantic_warm_readiness(
                state="skipped",
                source="startup",
                result="empty_index",
                query_path_warmed=False,
            )
        if _env_flag("PITH_FOREGROUND_EMBEDDING_BOUNDED_ENABLED", False) and _env_flag(
            "PITH_FOREGROUND_EMBEDDING_ENABLED",
            True,
        ):
            from app.retrieval.foreground_embedding import foreground_embedding_process

            foreground_embedding_process.start_async()
            logger.info("Startup: bounded foreground embedding worker start scheduled")
    except asyncio.CancelledError:
        logger.info("Startup: semantic embedding warmup cancelled")
        retrieval_engine.record_semantic_warm_readiness(
            state="cancelled",
            source="startup",
            result="cancelled",
            query_path_warmed=False,
        )
        raise
    except Exception as e:
        retrieval_engine.record_semantic_warm_readiness(
            state="failed",
            source="startup",
            result="error",
            error=type(e).__name__,
            query_path_warmed=False,
        )
        logger.warning(f"Startup: embedding warmup failed (non-fatal): {e}")
        app.state.startup_warnings.append({"component": "embedding_warmup", "severity": "degraded", "message": str(e)})


async def _warm_reranker_for_startup() -> None:
    """Warm cross-encoder reranker without blocking retrieval readiness."""
    try:
        import importlib

        reranker = await asyncio.to_thread(importlib.import_module, "app.reranker")
        _reranker_warmup_ok = await asyncio.to_thread(reranker.warmup)
        if _reranker_warmup_ok:
            logger.info("Startup: reranker model pre-loaded (PERF-040)")
        else:
            logger.warning("Startup: reranker warmup failed; CE paths degraded")
            app.state.startup_warnings.append(
                {
                    "component": "reranker_warmup",
                    "severity": "degraded",
                    "message": "Reranker warmup failed; cross-encoder paths unavailable",
                }
            )
    except asyncio.CancelledError:
        logger.info("Startup: reranker warmup cancelled")
        raise
    except Exception as e:
        logger.warning(f"Startup: reranker warmup failed (non-fatal): {e}")
        app.state.startup_warnings.append({"component": "reranker_warmup", "severity": "degraded", "message": str(e)})


async def _run_deferred_startup_warmups(
    *,
    warm_embeddings: bool,
    warm_reranker: bool,
) -> None:
    """Let startup finish, then serialize optional ML warmups."""
    delay_s = float(os.environ.get("PITH_STARTUP_BACKGROUND_WARMUP_DELAY_S", "5"))
    if delay_s > 0:
        await asyncio.sleep(delay_s)
    if warm_embeddings:
        logger.info("Startup: semantic embedding warmup beginning in background")
        await _warm_embeddings_for_startup()
    if warm_reranker:
        logger.info("Startup: reranker warmup beginning in background")
        await _warm_reranker_for_startup()


def _run_conversation_turn_lifecycle_job(job: dict) -> dict:
    def _run_effect() -> dict:
        payload = job.get("payload") or {}
        request_payload = payload.get("learn_request") if isinstance(payload, dict) else None
        if not isinstance(request_payload, dict):
            raise ValueError("conversation_turn lifecycle job missing learn_request payload")
        learn_request = SessionLearnRequest(**request_payload)
        bound_session_payload = payload.get("bound_session")
        bound_session = SessionInfo(**bound_session_payload) if bound_session_payload else None
        result = session_manager._background_autolearn(
            learn_request,
            payload.get("extracted"),
            payload.get("request_message", ""),
            payload.get("prev_msg", ""),
            payload.get("prev_response", ""),
            bound_session,
            payload.get("raw_capture_ref"),
            payload.get("active_binding_snapshot"),
        )
        return {"status": "committed", "result": result}

    if job.get("binding_hash") is None:
        return _run_effect()

    from app.session.binding import BindingBusyError, run_managed_conversation_turn_effect
    from app.session.lifecycle_jobs_runtime import LifecycleJobDeferred

    try:
        return run_managed_conversation_turn_effect(job, run_effect=_run_effect)
    except BindingBusyError as exc:
        raise LifecycleJobDeferred("managed_episode_guard_busy", retry_after_seconds=1) from exc


def _submit_managed_conversation_turn_drain() -> None:
    """Nudge the durable runner after foreground registration has committed."""

    from app.session.lifecycle_jobs_runtime import submit_lifecycle_drain

    submit_lifecycle_drain(
        run_job=_run_conversation_turn_lifecycle_job,
        reason="managed_conversation_turn_autolearn",
        limit=5,
        source="conversation_turn",
    )


def _run_session_end_lifecycle_job(job: dict) -> dict:
    payload = job.get("payload") or {}
    request_payload = payload.get("end_request") if isinstance(payload, dict) else None
    if not isinstance(request_payload, dict):
        raise ValueError("session_end lifecycle job missing end_request payload")
    end_request = SessionEndRequest(**request_payload)

    if job.get("binding_hash") is None:
        return _run_session_end_replay_payload(request_payload)

    from app.session.binding import (
        BindingBusyError,
        ManagedCloseDeferred,
        run_managed_session_end_effect,
    )
    from app.session.lifecycle_jobs_runtime import LifecycleJobDeferred

    try:
        result = run_managed_session_end_effect(
            job,
            run_effect=lambda: _with_db_retry(lambda: session_manager.end_session(end_request)),
        )
    except (BindingBusyError, ManagedCloseDeferred) as exc:
        raise LifecycleJobDeferred(str(exc), retry_after_seconds=1) from exc

    authority = ManagedReplayAuthority(
        profile=str(job["profile"]),
        binding_hash=str(job["binding_hash"]),
        session_id=str(job["session_id"]),
    )
    response = _coerce_session_end_payload("", result)
    response.pop("request_id", None)
    response["_protocol"] = {
        "binding_mode": "managed",
        "binding_protocol_version": 1,
        "binding_generation": int(job["binding_generation"]),
        "lifecycle_phase": str(result.get("lifecycle_phase") or result.get("status") or "ended"),
    }
    commit_managed_write_requests_for_episode("session_end", authority, response)
    return response


def _submit_managed_session_end_drain() -> None:
    from app.session.lifecycle_jobs_runtime import submit_lifecycle_drain

    submit_lifecycle_drain(
        run_job=_run_session_end_lifecycle_job,
        reason="managed_session_end",
        limit=1,
        source="session_end",
    )


def _register_lifecycle_job_runners() -> None:
    from app.core.profile import get_active_profile
    from app.ops.reflection_runner import run_reflection_lifecycle_job
    from app.session.binding import sweep_due_managed_episodes
    from app.session.lifecycle_jobs_runtime import (
        register_lifecycle_job_runner,
        register_lifecycle_maintenance_callback,
    )

    register_lifecycle_job_runner("conversation_turn", _run_conversation_turn_lifecycle_job)
    register_lifecycle_job_runner("session_learn", _run_session_learn_lifecycle_job)
    register_lifecycle_job_runner("session_end", _run_session_end_lifecycle_job)
    register_lifecycle_job_runner("reflection_full", run_reflection_lifecycle_job)
    register_lifecycle_maintenance_callback(
        "managed_session_sweep",
        lambda *, max_wall_seconds: sweep_due_managed_episodes(
            profile=get_active_profile(),
            limit=50,
            max_wall_seconds=max_wall_seconds,
        ),
    )


def _start_lifecycle_supervisor_if_enabled() -> None:
    if os.environ.get("PITH_BENCHMARK_READONLY", "").lower() in ("1", "true"):
        app.state.lifecycle_supervisor_state = "disabled_readonly"
        return
    if not _cfg.LIFECYCLE_JOBS_ENABLED:
        app.state.lifecycle_supervisor_state = "disabled_lifecycle_jobs"
        return
    if not _cfg.LIFECYCLE_SUPERVISOR_ENABLED:
        app.state.lifecycle_supervisor_state = "disabled_flag"
        return
    try:
        from app.session.lifecycle_jobs_runtime import start_lifecycle_supervisor

        _register_lifecycle_job_runners()
        started = start_lifecycle_supervisor(
            interval_seconds=_cfg.LIFECYCLE_SUPERVISOR_INTERVAL_SECONDS,
            batch_size=_cfg.LIFECYCLE_SUPERVISOR_BATCH_SIZE,
            max_wall_seconds=_cfg.LIFECYCLE_SUPERVISOR_MAX_WALL_SECONDS,
            starvation_seconds=_cfg.LIFECYCLE_SUPERVISOR_STARVATION_SECONDS,
        )
        app.state.lifecycle_supervisor_state = "running" if started else "already_running"
        logger.info("Lifecycle supervisor state: %s", app.state.lifecycle_supervisor_state)
    except Exception as exc:
        app.state.lifecycle_supervisor_state = "degraded"
        app.state.startup_warnings.append(
            {
                "component": "lifecycle_supervisor",
                "severity": "degraded",
                "message": f"Lifecycle supervisor failed to start: {exc}",
            }
        )
        logger.warning("Lifecycle supervisor failed to start: %s", exc, exc_info=True)


def _start_autolearn_maintenance_supervisor_if_enabled() -> None:
    if os.environ.get("PITH_BENCHMARK_READONLY", "").lower() in ("1", "true"):
        app.state.autolearn_maintenance_supervisor_state = "disabled_readonly"
        return
    if not _cfg.get_autolearn_maintenance_enabled():
        app.state.autolearn_maintenance_supervisor_state = "disabled_autolearn_maintenance"
        return
    if not _cfg.get_autolearn_maintenance_supervisor_enabled():
        app.state.autolearn_maintenance_supervisor_state = "disabled_flag"
        return
    try:
        from app.session.autolearn_maintenance import start_autolearn_maintenance_supervisor

        started = start_autolearn_maintenance_supervisor(
            interval_seconds=_cfg.get_autolearn_maintenance_supervisor_interval_seconds(),
            batch_size=_cfg.get_autolearn_maintenance_supervisor_batch_size(),
            max_wall_seconds=_cfg.get_autolearn_maintenance_supervisor_max_wall_seconds(),
        )
        app.state.autolearn_maintenance_supervisor_state = "running" if started else "already_running"
        logger.info(
            "Autolearn maintenance supervisor state: %s",
            app.state.autolearn_maintenance_supervisor_state,
        )
    except Exception as exc:
        app.state.autolearn_maintenance_supervisor_state = "degraded"
        app.state.startup_warnings.append(
            {
                "component": "autolearn_maintenance_supervisor",
                "severity": "degraded",
                "message": f"Autolearn maintenance supervisor failed to start: {exc}",
            }
        )
        logger.warning("Autolearn maintenance supervisor failed to start: %s", exc, exc_info=True)


async def _complete_startup_initialization():
    """Finish non-critical startup work after the API is live.

    Stage 3 requires liveness to come up before retrieval warmup completes.
    Keep the write path gated via readyz.write_state until storage init finishes,
    then let retrieval/index work continue in the background.
    """
    try:
        _defer_embedding_warmup = False
        _defer_reranker_warmup = False
        # Minimal write-path dependency: storage backend + schema availability.
        try:
            from app.storage.backend import get_backend

            await asyncio.to_thread(get_backend)
            app.state.write_state = "accepting"
            _schedule_all_write_replay_reclaimers("startup")
            _start_lifecycle_supervisor_if_enabled()
            _start_autolearn_maintenance_supervisor_if_enabled()
        except Exception as e:
            app.state.process_state = "blocked"
            app.state.write_state = "blocked"
            _set_degraded_reason("storage_backend_init_failed")
            logger.error(f"CRITICAL: Storage backend init failed during deferred startup: {e}", exc_info=True)
            app.state.startup_warnings.append(
                {
                    "component": "storage_backend",
                    "severity": "critical",
                    "message": f"Storage backend init failed: {e}",
                }
            )
            return

        # SYSTEMIC_FIXES_SPEC v1.1 Fix 4: Environment validation
        _in_venv = sys.prefix != sys.base_prefix
        if not _in_venv:
            logger.warning("STARTUP WARNING: Running outside a virtual environment (sys.prefix == sys.base_prefix)")
        try:
            if _env_flag("PITH_STARTUP_BLOCK_ON_EMBEDDING_WARMUP", False):
                import importlib

                await asyncio.to_thread(importlib.import_module, "sentence_transformers")

                logger.info(
                    f"Startup: sentence_transformers available (Python {sys.version_info.major}.{sys.version_info.minor})"
                )
                app.state.embeddings_available = True
                await _warm_embeddings_for_startup()
            else:
                app.state.embeddings_available = True
                _defer_embedding_warmup = True

            _reranker_enabled = os.environ.get("PITH_RERANKER", "").lower() in ("true", "1")
            if _reranker_enabled:
                if _env_flag("PITH_STARTUP_BLOCK_ON_RERANKER_WARMUP", False):
                    await _warm_reranker_for_startup()
                else:
                    _defer_reranker_warmup = True

        except ImportError:
            logger.warning("Startup: sentence_transformers not available — TF-IDF fallback active")
            app.state.embeddings_available = False
            _set_degraded_reason("tfidf_fallback_active")

        _pith_profile = os.environ.get("PITH_PROFILE")
        if _pith_profile and not API_KEY:
            logger.warning(f"STARTUP WARNING: PITH_PROFILE={_pith_profile} but PITH_API_KEY not set")

        # Run schema migration 002 (temporal/causal) — idempotent
        try:
            import importlib

            mod = importlib.import_module("migrations.002_temporal_causal")
            await asyncio.to_thread(mod.run_migration)
            logger.info("Startup: Schema migration 002 (temporal/causal) complete")
        except ImportError:
            logger.debug("Startup: Migration 002 not found, skipping")
        except Exception as e:
            logger.warning(f"Startup: Migration 002 failed (non-fatal): {e}")

        if not API_KEY:
            logger.warning("PITH_API_KEY not set — write endpoints unprotected")

        # Run schema migration 003 (domains/directives) — idempotent
        try:
            import importlib

            mod003 = importlib.import_module("migrations.003_domains_directives")
            await asyncio.to_thread(mod003.run_migration)
            logger.info("Startup: Schema migration 003 (domains_directives) complete")
        except ImportError:
            logger.debug("Startup: Migration 003 not found, skipping")
        except Exception as e:
            logger.warning(f"Startup: Migration 003 failed (non-fatal): {e}")

        # P0-7: Seed firmware before anything else (idempotent)
        _benchmark_mode = os.environ.get("PITH_BENCHMARK_MODE", "").lower() in ("true", "1")
        try:
            if _benchmark_mode:
                logger.info("Firmware seed: SKIPPED (PITH_BENCHMARK_MODE=true)")
                result = {"action": "skipped", "version": "benchmark"}
            else:
                from app.ops.seed_firmware import seed_firmware

                result = await asyncio.to_thread(seed_firmware)
            logger.info(f"Firmware seed: {result.get('action')} (v{result.get('version')})")
        except Exception as e:
            logger.error(f"CRITICAL: Firmware seed failed: {e}", exc_info=True)
            app.state.startup_warnings.append(
                {
                    "component": "firmware_seed",
                    "severity": "critical",
                    "message": f"Firmware seed failed: {e}",
                }
            )

        try:
            from app.ops.seed_domains import seed_domains

            result = await asyncio.to_thread(seed_domains)
            logger.info(f"Domain seed: {result.get('action')} (v{result.get('version', 'n/a')})")
        except Exception as e:
            logger.warning(f"Startup: Domain seed failed (degraded): {e}", exc_info=True)
            app.state.startup_warnings.append(
                {
                    "component": "domain_seed",
                    "severity": "degraded",
                    "message": f"Domain seed failed: {e}",
                }
            )

        await _maybe_prewarm_required_context()

        try:
            if retrieval_engine.index.document_count > 0:
                logger.info(f"Index loaded from disk: {retrieval_engine.index.document_count} concepts already indexed")
            else:
                await asyncio.to_thread(retrieval_engine.build_index)
                concept_count = retrieval_engine.index.document_count
                logger.info(f"Index built successfully: {concept_count} concepts indexed")
        except Exception as e:
            logger.error(f"CRITICAL: Failed to build index on startup: {e}", exc_info=True)
            _set_degraded_reason("index_build_failed")
            app.state.startup_warnings.append(
                {
                    "component": "index_build",
                    "severity": "critical",
                    "message": f"Index build failed: {e}",
                }
            )

        try:
            integrity = await asyncio.to_thread(retrieval_engine.verify_index_integrity)
            if not integrity["is_healthy"]:
                logger.warning(
                    f"Startup: Index drift detected — {integrity['ghosts']} ghosts, {integrity['orphans']} orphans. Deferring repair to background..."
                )
                app.state.index_repair_task = asyncio.create_task(_deferred_index_repair(integrity))
            else:
                logger.info("Startup: Index integrity check passed")
        except Exception as e:
            logger.warning(f"Startup: Index integrity check failed (non-fatal): {e}")

        try:
            from app.ops.metrics import metrics as _metrics_instance

            await asyncio.to_thread(_metrics_instance.startup_health_check)
        except Exception as e:
            logger.warning(f"Startup: Metrics health check failed (non-fatal): {e}")

        try:
            run_storage_migration("migrations.005_content_updated_at")
            logger.info("Startup: Migration 005 (content_updated_at) complete")
        except ImportError:
            logger.debug("Startup: Migration 005 not found, skipping")
        except Exception as e:
            logger.warning(f"Startup: Migration 005 failed (non-fatal): {e}")

        try:
            run_storage_migration("migrations.006_junk_type_cleanup")
            logger.info("Startup: Migration 006 (junk type cleanup) complete")
        except ImportError:
            logger.debug("Startup: Migration 006 not found, skipping")
        except Exception as e:
            logger.warning(f"Startup: Migration 006 failed (non-fatal): {e}")

        try:
            run_storage_migration("migrations.013_original_date")
            logger.info("Startup: Migration 013 (original_date) complete")
        except ImportError:
            logger.debug("Startup: Migration 013 not found, skipping")
        except Exception as e:
            logger.warning(f"Startup: Migration 013 failed (non-fatal): {e}")

        _benchmark_readonly_startup = os.environ.get("PITH_BENCHMARK_READONLY", "").lower() in ("true", "1")
        _scheduler_disabled = os.environ.get("PITH_DISABLE_BUILTIN_SCHEDULER", "0").lower() in ("1", "true", "yes")
        if _benchmark_readonly_startup or _scheduler_disabled:
            app.state.maintenance_state = "disabled"
            logger.info(
                "Startup: Maintenance scheduler SKIPPED (%s)",
                "PITH_BENCHMARK_READONLY" if _benchmark_readonly_startup else "PITH_DISABLE_BUILTIN_SCHEDULER",
            )
        else:
            try:
                from app.ops.maintenance_scheduler import start_maintenance_scheduler

                _sched_task = await start_maintenance_scheduler()
                if _sched_task is not None:
                    app.state.maintenance_scheduler = _sched_task
                    app.state.maintenance_state = "running"
                    logger.info("Startup: Built-in maintenance scheduler started")
                else:
                    app.state.maintenance_state = "disabled"
                    logger.info("Startup: Built-in maintenance scheduler disabled")
            except Exception as e:
                app.state.maintenance_state = "degraded"
                _set_degraded_reason(app.state.degraded_reason or "maintenance_scheduler_failed")
                logger.warning(f"Startup: Maintenance scheduler failed (degraded): {e}")
                app.state.startup_warnings.append(
                    {
                        "component": "maintenance_scheduler",
                        "severity": "degraded",
                        "message": f"Scheduler failed: {e}",
                    }
                )

        # RETRIEVAL-125 Phase C: steady-state TF-IDF/embedding refresh drain
        # (gated OFF by default via PITH_TFIDF_REFRESH_DRAIN).
        try:
            from app.ops.host_pressure import build_host_pressure_snapshot
            from app.retrieval.refresh_drain import start_refresh_drain

            _drain_task = await start_refresh_drain(
                pressure_provider=lambda: build_host_pressure_snapshot(use_cache=True),
            )
            if _drain_task is not None:
                app.state.refresh_drain_task = _drain_task
                logger.info("Startup: TF-IDF refresh drain started")
        except Exception as e:
            logger.warning(f"Startup: TF-IDF refresh drain failed to start (non-fatal): {e}")

        # MAINT-097: durable membership/index reconciliation is an invariant,
        # independent of optional maintenance and refresh feature flags.
        try:
            from app.retrieval.lifecycle_index_drain import (
                disable_lifecycle_index_drain,
                start_lifecycle_index_drain,
            )

            if _benchmark_readonly_startup:
                disable_lifecycle_index_drain("benchmark_readonly")
                logger.info("Startup: Lifecycle index outbox drain skipped in benchmark-readonly mode")
            else:
                app.state.lifecycle_index_outbox_task = await start_lifecycle_index_drain()
                logger.info("Startup: Lifecycle index outbox drain started")
        except Exception as e:
            _set_degraded_reason(app.state.degraded_reason or "lifecycle_index_outbox_failed")
            logger.error(f"Startup: Lifecycle index outbox drain failed to start: {e}", exc_info=True)
            app.state.startup_warnings.append(
                {
                    "component": "lifecycle_index_outbox",
                    "severity": "critical",
                    "message": f"Lifecycle index outbox drain failed: {e}",
                }
            )

        if getattr(app.state, "retrieval_state", "recovering") != "degraded":
            app.state.retrieval_state = "ready"
        if app.state.write_state != "blocked":
            app.state.write_state = "accepting"
        if _defer_embedding_warmup or _defer_reranker_warmup:
            app.state.ml_warmup_task = asyncio.create_task(
                _run_deferred_startup_warmups(
                    warm_embeddings=_defer_embedding_warmup,
                    warm_reranker=_defer_reranker_warmup,
                )
            )
            if _defer_embedding_warmup:
                logger.info("Startup: semantic embedding warmup scheduled after readiness (PERF-076)")
            if _defer_reranker_warmup:
                logger.info("Startup: reranker warmup scheduled after readiness (PERF-040)")
    except asyncio.CancelledError:
        logger.info("Startup: Deferred initialization cancelled")
        raise
    except Exception as e:
        _set_degraded_reason(app.state.degraded_reason or "deferred_startup_failed")
        logger.error(f"Deferred startup failed: {e}", exc_info=True)
        app.state.startup_warnings.append(
            {
                "component": "deferred_startup",
                "severity": "critical",
                "message": f"Deferred startup failed: {e}",
            }
        )


@app.on_event("startup")
async def startup_event():
    """Initialize components on startup."""
    logger.info("Pith Server starting up...")
    logger.info("Server version: %s", SERVER_VERSION)
    app.state.process_state = "starting"
    app.state.write_state = "queued"
    app.state.retrieval_state = "recovering"
    app.state.maintenance_state = "disabled"
    app.state.lifecycle_supervisor_state = "disabled"
    app.state.degraded_reason = None

    try:
        ensure_safe_installed_runtime(invocation_path=os.getcwd())
    except RuntimeInstallGuardError as exc:
        logger.critical(f"STARTUP BLOCKED: {exc}")
        raise RuntimeError(str(exc)) from exc

    try:
        ensure_safe_installed_runtime(invocation_path=os.getcwd())
    except RuntimeInstallGuardError as exc:
        logger.critical(f"STARTUP BLOCKED: {exc}")
        raise RuntimeError(str(exc)) from exc

    # STABILITY-021: Track degraded startup state
    app.state.startup_warnings = []

    try:
        ensure_safe_installed_runtime(invocation_path=os.getcwd())
    except RuntimeInstallGuardError as exc:
        app.state.process_state = "blocked"
        app.state.write_state = "blocked"
        _set_degraded_reason("runtime_install_guard_blocked")
        logger.critical(f"STARTUP BLOCKED: {exc}")
        raise RuntimeError(str(exc)) from exc

    # PROFILE_FIX_SPEC Fix 3: Explicit profile/data dir logging on startup
    from app.core.profile import get_active_profile, resolve_data_dir

    _active_profile = get_active_profile()
    _data_dir = resolve_data_dir()
    logger.info(f"STARTUP: Profile={_active_profile}, DataDir={_data_dir}")

    # STABILITY-044 Fix 2b: Early exit if disabled flag is set.
    # Prevents KeepAlive respawns from doing expensive startup work
    # when the circuit breaker has fired.
    _pith_home = os.environ.get("PITH_HOME", os.path.expanduser("~/.pith"))
    _disabled_path = os.path.join(_pith_home, "server.disabled")
    if os.path.exists(_disabled_path):
        _reason = "unknown"
        try:
            with open(_disabled_path) as _df:
                _reason = _df.read().strip()[:200]
        except OSError:
            pass
        logger.warning(
            "STABILITY-044: server.disabled flag present (%s). Exiting early. Remove flag and restart to recover.",
            _reason,
        )
        raise RuntimeError(f"server.disabled: {_reason}")

    # BRAIN_LOCK_SPEC: Exclusive data directory lock — prevents rogue servers
    try:
        acquire_brain_lock(data_dir=str(_data_dir), port=PITH_PORT, pid=os.getpid())
    except BrainLockError as exc:
        logger.critical(f"STARTUP BLOCKED: {exc}")
        raise RuntimeError(str(exc)) from exc

    app.state.process_state = "running"
    import time as _startup_time

    app.state._start_monotonic = _startup_time.monotonic()  # STABILITY-037: uptime tracking
    _register_signal_handlers()
    app.state.startup_task = asyncio.create_task(_complete_startup_initialization())
    logger.info("Startup: Deferred initialization scheduled")
    start_diagnostic_warmer()  # EUNOMIA-126: no-op when PITH_DIAGNOSTIC_WARMER_ENABLED is off


@app.on_event("shutdown")
async def shutdown_event():
    """Graceful shutdown — stop scheduler, wait for background tasks, log."""
    app.state.process_state = "stopping"

    # STABILITY-037 Fix 3a: Signal backend shutdown flag FIRST
    try:
        from app.storage.backend import get_backend

        backend = get_backend()
        if hasattr(backend, "begin_shutdown"):
            backend.begin_shutdown()
    except Exception as e:
        logger.warning(f"Shutdown: Backend shutdown signal failed: {e}")

    try:
        from app.session.required_context_cache import shutdown_required_context_cache

        shutdown_required_context_cache(wait=True)
        logger.info("Shutdown: Required context cache refresh executor stopped")
    except Exception as e:
        logger.warning(f"Shutdown: Required context cache shutdown failed: {e}")

    try:
        from app.storage import shutdown_association_index_refresh

        shutdown_association_index_refresh(wait=True)
        logger.info("Shutdown: Association index refresh executor stopped")
    except Exception as e:
        logger.warning(f"Shutdown: Association index refresh shutdown failed: {e}")

    try:
        from app.session.lifecycle_jobs_runtime import shutdown_lifecycle_runtime

        shutdown_lifecycle_runtime(wait=True)
        app.state.lifecycle_supervisor_state = "stopped"
        logger.info("Shutdown: Lifecycle runtime stopped")
    except Exception as e:
        logger.warning(f"Shutdown: Lifecycle runtime shutdown failed: {e}")

    try:
        from app.session.autolearn_maintenance import stop_autolearn_maintenance_supervisor

        stop_autolearn_maintenance_supervisor(wait=True)
        app.state.autolearn_maintenance_supervisor_state = "stopped"
        logger.info("Shutdown: Autolearn maintenance supervisor stopped")
    except Exception as e:
        logger.warning(f"Shutdown: Autolearn maintenance supervisor shutdown failed: {e}")

    # STABILITY-037 Fix 3b: Wait for autolearn executor to finish
    try:
        _executor = getattr(session_manager, "_learn_executor", None)
        if _executor is not None:
            logger.info("Shutdown: Waiting for autolearn executor (max 10s)...")
            _executor.shutdown(wait=True, cancel_futures=True)
            logger.info("Shutdown: Autolearn executor stopped")
    except Exception as e:
        logger.warning(f"Shutdown: Autolearn executor shutdown failed: {e}")

    _startup_task = getattr(app.state, "startup_task", None)
    if _startup_task and not _startup_task.done():
        _startup_task.cancel()
        logger.info("Shutdown: Cancelled deferred startup task")
    # STABILITY-030: Cancel in-flight index repair
    _repair_task = getattr(app.state, "index_repair_task", None)
    if _repair_task and not _repair_task.done():
        _repair_task.cancel()
        logger.info("Shutdown: Cancelled in-flight index repair")

    # MAINT-033: Stop maintenance scheduler
    try:
        from app.ops.maintenance_scheduler import stop_maintenance_scheduler

        await stop_maintenance_scheduler()
    except Exception as e:
        logger.warning(f"Shutdown: Scheduler stop failed: {e}")
    # RETRIEVAL-125 Phase C: stop the steady-state refresh drain
    try:
        from app.retrieval.refresh_drain import stop_refresh_drain

        await stop_refresh_drain()
    except Exception as e:
        logger.warning(f"Shutdown: TF-IDF refresh drain stop failed: {e}")
    try:
        from app.retrieval.lifecycle_index_drain import stop_lifecycle_index_drain

        await stop_lifecycle_index_drain()
        logger.info("Shutdown: Lifecycle index outbox drain stopped")
    except Exception as e:
        logger.warning(f"Shutdown: Lifecycle index outbox drain stop failed: {e}")
    try:
        shutdown_diagnostic_warmer(wait=True)  # EUNOMIA-126
        logger.info("Shutdown: diagnostic warmer stopped")
    except Exception as e:
        logger.warning(f"Shutdown: diagnostic warmer shutdown failed: {e}")
    try:
        from app.retrieval.foreground_embedding import foreground_embedding_process

        foreground_embedding_process.shutdown()
        logger.info("Shutdown: foreground embedding worker stopped")
    except Exception as e:
        logger.warning(f"Shutdown: foreground embedding worker stop failed: {e}")
    release_brain_lock()
    logger.info("Pith Server shutting down...")


def _register_signal_handlers():
    """OPS-075: Register SIGTERM/SIGINT handlers without overriding uvicorn shutdown."""
    import signal

    def _make_shutdown_handler(previous_handler):
        def _handle_shutdown_signal(signum, frame):
            import time as _sig_time
            import traceback as _tb

            sig_name = signal.Signals(signum).name
            caller_info = ""
            if frame is not None:
                caller_info = f" frame={frame.f_code.co_filename}:{frame.f_lineno} in {frame.f_code.co_name}"

            _uptime_s = _sig_time.monotonic() - getattr(app.state, "_start_monotonic", _sig_time.monotonic())
            _ppid = os.getppid()
            _source = "unknown"
            if _ppid == 1:
                _source = "launchd"
            elif _ppid == os.getpid():
                _source = "self"
            elif should_suppress_optional_subprocess("shutdown_parent_process_name"):
                _source = f"pid={_ppid}"
            else:
                try:
                    _pname = (
                        subprocess.check_output(["ps", "-p", str(_ppid), "-o", "comm="], timeout=1).decode().strip()
                    )
                    _source = f"parent:{_pname}(pid={_ppid})"
                except Exception:
                    _source = f"pid={_ppid}"

            logger.warning(
                "OPS-075/STABILITY-037: Received %s (pid=%d, ppid=%d, source=%s, "
                "uptime=%.1fs%s) — initiating graceful shutdown",
                sig_name,
                os.getpid(),
                _ppid,
                _source,
                _uptime_s,
                caller_info,
            )
            try:
                stack = "".join(_tb.format_stack(frame, limit=5))
                logger.warning("OPS-075/T1-3: Stack at %s:\n%s", sig_name, stack)
            except Exception:
                pass
            try:
                from app.ops.reflection_runner import reflection_runner

                active_reflection = reflection_runner.get_active_run()
                if active_reflection:
                    logger.warning(
                        "Reflection run active during %s shutdown signal: %s",
                        sig_name,
                        active_reflection,
                    )
            except Exception:
                logger.debug("Unable to capture active reflection snapshot during shutdown", exc_info=True)
            app.state.process_state = "stopping"
            if callable(previous_handler):
                return previous_handler(signum, frame)
            return None

        _handle_shutdown_signal._pith_shutdown_handler = True
        _handle_shutdown_signal._pith_previous_handler = previous_handler
        return _handle_shutdown_signal

    def _install(signum):
        current_handler = signal.getsignal(signum)
        if getattr(current_handler, "_pith_shutdown_handler", False):
            return
        sig_name = signal.Signals(signum).name
        signal.signal(signum, _make_shutdown_handler(current_handler))
        logger.info("OPS-075: Signal handler registered (%s)", sig_name)

    # Only register in main thread (uvicorn workers may fork)
    import threading

    if threading.current_thread() is threading.main_thread():
        _install(signal.SIGTERM)
        _install(signal.SIGINT)


def _get_feature_flags() -> dict:
    """TOOLING-034: Expose feature flag state for health/diagnostics.
    OPS-106: Now returns runtime-resolved values (env var overrides),
    not just config.py defaults. Uses get_feature_flag() per flag."""
    from app.core.config import FEATURE_FLAGS, get_feature_flag

    flags = {name: get_feature_flag(name, default) for name, default in FEATURE_FLAGS.items()}
    flags["LIFECYCLE_JOBS_ENABLED"] = bool(_cfg.LIFECYCLE_JOBS_ENABLED)
    flags["LIFECYCLE_SUPERVISOR_ENABLED"] = bool(_cfg.LIFECYCLE_SUPERVISOR_ENABLED)
    flags["REFLECTION_DURABLE_JOBS_ENABLED"] = bool(_cfg.REFLECTION_DURABLE_JOBS_ENABLED)
    flags["REFLECTION_COMPLETION_MONITOR_ENABLED"] = bool(_cfg.REFLECTION_COMPLETION_MONITOR_ENABLED)
    return flags


def _read_only_aggregates_enabled() -> bool:
    from app.core.config import get_feature_flag

    return get_feature_flag("READ_ONLY_AGGREGATES_ENABLED", False)


def _read_only_aggregates_fallback_allowed() -> bool:
    """Parent spec §15 safety flag: if True, a failing read_snapshot_db call
    falls back to the legacy connection path instead of surfacing HTTP 500.
    Default True so a transient SQLite hiccup does not degrade /pith_stats
    or /pith_search_suggestions. Set False only in hardening/assertion mode.
    """
    from app.core.config import get_feature_flag

    return get_feature_flag("READ_ONLY_AGGREGATES_FALLBACK_ALLOWED", True)


def _cascade_alert_threshold() -> int:
    """NITS-001: Lazy-load configurable cascade alert threshold."""
    from app.core.config import CASCADE_ALERT_THRESHOLD

    return CASCADE_ALERT_THRESHOLD


def _circuit_breaker_alert_threshold() -> int:
    """MONITOR-072: Lazy-load configurable circuit breaker alert threshold."""
    from app.core.config import CIRCUIT_BREAKER_ALERT_THRESHOLD

    return CIRCUIT_BREAKER_ALERT_THRESHOLD


def _get_contradiction_signal_backlog(conn=None) -> dict:
    """MONITOR-027: Check for unprocessed GRAPH_CONTRADICTION_SIGNAL events."""
    try:
        if conn is not None:
            count = conn.execute(
                "SELECT COUNT(*) FROM governance_events WHERE event_type = 'GRAPH_CONTRADICTION_SIGNAL'"
            ).fetchone()[0]
            return {"unprocessed_count": count, "alert": count > 1000}

        from app.storage.connection import read_snapshot_db

        with read_snapshot_db("health_contradiction_signal_backlog", allow_fallback=False) as conn:
            count = conn.execute(
                "SELECT COUNT(*) FROM governance_events WHERE event_type = 'GRAPH_CONTRADICTION_SIGNAL'"
            ).fetchone()[0]
        return {"unprocessed_count": count, "alert": count > 1000}
    except Exception as exc:
        return {
            "unprocessed_count": -1,
            "alert": False,
            "degraded": True,
            "reason": _safe_error(exc),
        }


def _get_pricing_health() -> dict:
    """MONITOR-028: Pricing metrics for /health endpoint."""
    try:
        from app.api.pricing import conversation_meter

        status = conversation_meter.get_status()
        return {
            "budget_zone": status.get("budget_zone", "unknown"),
            "turns_used": status.get("turns_used", 0),
            "turns_remaining": status.get("turns_remaining", 0),
            "daily_limit": status.get("daily_limit", 0),
            "usage_limits_enabled": status.get("usage_limits_enabled"),
            "unlimited_usage": status.get("unlimited_usage"),
            "capped_at": status.get("capped_at"),
        }
    except Exception:
        return {"error": "pricing_unavailable"}


@app.get("/healthz")
def healthz() -> dict:
    from app.core.profile import resolve_data_dir

    data_dir = Path(resolve_data_dir())
    return {
        "status": "healthy"
        if getattr(app.state, "process_state", "starting") in {"starting", "running"}
        else "stopping",
        "service": "pith",
        "timestamp": _utc_now_iso(),
        "version": SERVER_VERSION,
        "git_commit": _GIT_COMMIT,
        "git_branch": _GIT_BRANCH,
        "git_dirty": _GIT_DIRTY,
        "benchmark_mode": os.environ.get("PITH_BENCHMARK_MODE", "").lower() in ("true", "1"),
        "benchmark_readonly": os.environ.get("PITH_BENCHMARK_READONLY", "").lower() in ("true", "1"),
        "data_dir": str(data_dir),
        "db_path": str(data_dir / "pith.db"),
        "process_state": getattr(app.state, "process_state", "starting"),
    }


@app.get("/readyz")
def readyz(request: Request) -> dict:
    ready = _build_ready_state()
    ready["auth_status"] = _build_auth_status(request)
    return ready


@app.get("/runtime/answer_path_policy", dependencies=[Depends(verify_api_key)])
def answer_path_policy_status() -> AnswerPathPolicyResponse:
    from app.session.answer_path_policy import get_answer_path_policy

    snapshot = get_answer_path_policy().snapshot()
    return _answer_path_policy_response(snapshot)


@app.post("/runtime/answer_path_policy", dependencies=[Depends(verify_api_key)])
def update_answer_path_policy(
    request: Request,
    body: AnswerPathPolicyUpdateRequest,
) -> AnswerPathPolicyResponse:
    from app.session.answer_path_policy import (
        AnswerPathPolicyError,
        get_answer_path_policy,
    )

    _require_local_operator(request)
    ready = _build_ready_state()
    if ready["process_state"] != "running" or ready["retrieval_state"] == "recovering":
        reason = "process_not_running" if ready["process_state"] != "running" else "retrieval_recovering"
        _record_answer_path_policy_metric(
            "answer_path_policy_reject_total",
            {"reason": reason, "source": "runtime_api"},
        )
        raise HTTPException(
            status_code=503,
            detail="Answer-path runtime policy updates require a running process and initialized retrieval",
            headers={"Retry-After": "10"},
        )

    try:
        snapshot = get_answer_path_policy().set_runtime(
            observe_only=body.observe_only,
            enforcement_enabled=body.enforcement_enabled,
            ttl_seconds=body.ttl_seconds,
            enforce_modes=body.enforce_modes,
            source=body.source,
        )
    except AnswerPathPolicyError as exc:
        _record_answer_path_policy_metric(
            "answer_path_policy_reject_total",
            {"reason": "invalid_request", "source": "runtime_api"},
        )
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    _record_answer_path_policy_metric(
        "answer_path_policy_update_total",
        {"state": snapshot.state, "source": snapshot.source},
    )
    logger.info(
        "ANSWER-PATH-POLICY: update state=%s source=%s generation=%s expires_at=%s",
        snapshot.state,
        snapshot.source,
        snapshot.generation,
        snapshot.expires_at,
    )
    return _answer_path_policy_response(snapshot)


@app.post("/runtime/answer_path_policy/reset", dependencies=[Depends(verify_api_key)])
def reset_answer_path_policy(
    request: Request,
    body: AnswerPathPolicyResetRequest | None = None,
) -> AnswerPathPolicyResponse:
    from app.session.answer_path_policy import get_answer_path_policy

    _require_local_operator(request)
    source = body.source if body is not None else "runtime_api"
    snapshot = get_answer_path_policy().reset(source=source)
    _record_answer_path_policy_metric(
        "answer_path_policy_reset_total",
        {"state": snapshot.state, "source": snapshot.source},
    )
    logger.info(
        "ANSWER-PATH-POLICY: reset state=%s source=%s generation=%s",
        snapshot.state,
        snapshot.source,
        snapshot.generation,
    )
    return _answer_path_policy_response(snapshot)


def _resolve_health_detail(request: Request, detail: str | None = None) -> str:
    values: list[str] = []
    query_params = getattr(request, "query_params", None)
    if query_params is not None and hasattr(query_params, "getlist"):
        values = list(query_params.getlist("detail"))
    if len(values) > 1:
        raise HTTPException(status_code=400, detail="detail must be one of: summary, full, auto")
    raw_detail = (
        detail
        if detail is not None
        else (values[0] if values else os.environ.get("PITH_HEALTH_DEFAULT_DETAIL", "summary"))
    )
    resolved = str(raw_detail or "summary").strip().lower()
    if resolved not in {"summary", "full", "auto"}:
        raise HTTPException(status_code=400, detail="detail must be one of: summary, full, auto")
    return resolved


def _pressure_state_active_contention(pressure_state: Any | None) -> bool:
    payload = (
        pressure_state.to_dict()
        if hasattr(pressure_state, "to_dict")
        else (pressure_state if isinstance(pressure_state, dict) else {})
    )
    return bool(payload.get("active_contention"))


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _pressure_state_level(pressure_state: Any | None) -> str:
    payload = (
        pressure_state.to_dict()
        if hasattr(pressure_state, "to_dict")
        else (pressure_state if isinstance(pressure_state, dict) else {})
    )
    return str(payload.get("pressure_level") or "none")


def _health_budget_ms() -> float:
    return max(0.0, _env_float("PITH_FULL_HEALTH_BUDGET_MS", 2500.0))


def _health_elapsed_ms(start: float) -> float:
    return round((time.perf_counter() - start) * 1000.0, 2)


def _health_budget_exhausted(start: float, budget_ms: float) -> bool:
    return budget_ms > 0 and _health_elapsed_ms(start) >= budget_ms


def _health_section_budget_ms(section: str) -> float:
    env_name = f"PITH_HEALTH_SECTION_{section.upper()}_BUDGET_MS"
    return max(0.0, _env_float(env_name, _env_float("PITH_HEALTH_SECTION_BUDGET_MS", 25.0)))


def _health_remaining_ms(start: float, budget_ms: float) -> float | None:
    if budget_ms <= 0:
        return None
    return max(0.0, budget_ms - _health_elapsed_ms(start))


def _with_health_section_metadata(
    payload: dict,
    *,
    section: str,
    section_start: float,
    section_budget_ms: float,
    deferred: bool = False,
    reason: str | None = None,
) -> dict:
    enriched = dict(payload)
    enriched.setdefault("section", section)
    enriched.setdefault("section_elapsed_ms", _health_elapsed_ms(section_start))
    enriched.setdefault("section_budget_ms", section_budget_ms)
    enriched.setdefault("deferred", deferred)
    if reason is not None:
        enriched.setdefault("reason", reason)
    return enriched


def _run_health_section(
    section: str,
    health_start: float,
    global_budget_ms: float,
    builder,
) -> dict:
    section_budget_ms = _health_section_budget_ms(section)
    section_start = time.perf_counter()
    remaining_ms = _health_remaining_ms(health_start, global_budget_ms)
    if remaining_ms is not None and section_budget_ms > 0 and remaining_ms < section_budget_ms:
        return _with_health_section_metadata(
            _build_unavailable_health_metric("health_section_budget_exhausted"),
            section=section,
            section_start=section_start,
            section_budget_ms=section_budget_ms,
            deferred=True,
            reason="health_section_budget_exhausted",
        )
    try:
        payload = builder()
    except Exception as exc:
        payload = {
            "status": "unknown",
            "alert": True,
            "reason": f"{section}_health_failed",
            "error": _safe_error(exc),
        }
    return _with_health_section_metadata(
        payload,
        section=section,
        section_start=section_start,
        section_budget_ms=section_budget_ms,
    )


def _deferred_health_metric(reason: str, *, pressure_state: Any | None = None) -> dict:
    return {
        "status": "degraded",
        "alert": True,
        "deferred": True,
        "reason": reason,
        "pressure_level": _pressure_state_level(pressure_state),
    }


def _build_foreground_contract_health() -> dict[str, Any]:
    from app.ops.metrics import metrics

    since = (_utc_now() - timedelta(hours=1)).isoformat()
    opens = metrics.query_counter_summary(
        FOREGROUND_CONTRACT_CIRCUIT_OPEN_METRIC,
        since=since,
        strict=True,
    )
    enforce_opens = metrics.query_counter_summary(
        FOREGROUND_CONTRACT_CIRCUIT_OPEN_METRIC,
        since=since,
        labels_filter={"mode": "enforce"},
        strict=True,
    )
    decisions = metrics.query_counter_summary(
        FOREGROUND_CONTRACT_DECISION_METRIC,
        since=since,
        strict=True,
    )
    decision_count = int(decisions["count"])
    circuit_open_count = int(opens["count"])
    enforce_circuit_open_count = int(enforce_opens["count"])
    rate = round(circuit_open_count / decision_count * 100, 2) if decision_count else None
    if decision_count == 0:
        status = "unknown"
        alert = False
        reason = "no_decisions_in_window"
    elif enforce_circuit_open_count > 0:
        status = "warning"
        alert = True
        reason = "enforced_circuit_open_observed"
    else:
        status = "ok"
        alert = False
        reason = "no_enforced_circuit_opens"
    return {
        "status": status,
        "alert": alert,
        "decision_count": decision_count,
        "circuit_open_count": circuit_open_count,
        "enforce_circuit_open_count": enforce_circuit_open_count,
        "circuit_open_rate_pct": rate,
        "newest_open_at": opens["newest_timestamp"],
        "window_seconds": 3600,
        "reason": reason,
    }


@app.get("/health")
def health_check(request: Request, detail: str | None = None):
    health_start = time.perf_counter()
    health_detail = _resolve_health_detail(request, detail)
    health_budget_ms = _health_budget_ms()
    # /health is observational; do not wrap the whole response in a DB-boundary
    # request scope. Full-health diagnostics can stall or outlive clients, and a
    # broad scope then makes health itself appear as foreground DB contention.
    with nullcontext():
        try:
            from app.core.profile import get_active_profile, resolve_data_dir

            ready = _build_ready_state()
            external_maintenance = _build_external_maintenance_health()
            built_in_state = ready["maintenance_state"]
            effective_state, maintenance_mode = _effective_maintenance_state(
                built_in_state,
                external_maintenance,
            )
            ready["built_in_maintenance_state"] = built_in_state
            ready["maintenance_state"] = effective_state
            ready["maintenance_mode"] = maintenance_mode
            ready["external_maintenance"] = external_maintenance
            ready["profile"] = get_active_profile()
            data_dir = Path(resolve_data_dir())
            ready["data_dir"] = str(data_dir)
            ready["db_path"] = str(data_dir / "pith.db")
            ready["benchmark_mode"] = os.environ.get("PITH_BENCHMARK_MODE", "").lower() in ("true", "1")
            ready["benchmark_readonly"] = os.environ.get("PITH_BENCHMARK_READONLY", "").lower() in ("true", "1")
            ready["auth_status"] = _build_auth_status(request)
            ready["workstreams"] = _workstreams_capability_contract()
            try:
                from app.ops.reflection_runner import reflection_runner

                ready["active_reflection"] = reflection_runner.get_active_run()
            except Exception:
                ready["active_reflection"] = None
            try:
                from app.ops.pressure_state import build_pressure_state

                pressure_state = build_pressure_state(active_reflection=ready["active_reflection"], use_cache=True)
                ready["pressure_state"] = pressure_state.to_dict()
            except Exception as pressure_err:
                pressure_state = None
                ready["pressure_state"] = {
                    "active_contention": False,
                    "active_sources": [],
                    "pressure_level": "unknown",
                    "reason_codes": ["pressure_state_failed"],
                    "error": _safe_error(pressure_err),
                }
            required_context_cache = _build_required_context_cache_health()
            startup_defer = _should_defer_health_db_metrics(ready)
            try:
                from app.ops.pressure_policy import should_defer_health_diagnostics

                pressure_defer = health_detail in {"auto", "full"} and should_defer_health_diagnostics(pressure_state)
            except Exception:
                pressure_defer = health_detail == "auto" and _pressure_state_active_contention(pressure_state)
            budget_defer = health_detail == "full" and _health_budget_exhausted(health_start, health_budget_ms)
            defer_db_metrics = health_detail == "summary" or startup_defer or pressure_defer or budget_defer
            if health_detail == "summary":
                defer_reason = "summary_health_no_db_metrics"
            elif pressure_defer:
                if health_detail == "full":
                    defer_reason = "pressure_protected_health"
                else:
                    defer_reason = (
                        "active_contention"
                        if _pressure_state_active_contention(pressure_state)
                        else "pressure_protected_health"
                    )
            elif budget_defer:
                defer_reason = "health_detail_budget_exhausted"
            else:
                defer_reason = _health_metrics_defer_reason(ready) if startup_defer else None
            ready["metrics_detail"] = health_detail
            ready["health_budget_ms"] = health_budget_ms
            ready["db_metrics_deferred"] = bool(defer_db_metrics)
            if defer_reason:
                ready["db_metrics_defer_reason"] = defer_reason
            if health_detail == "full":
                # EUNOMIA-126: warmer/watchdog liveness (in-process; no DB, not defer-gated)
                ready["diagnostic_warmer"] = _diagnostic_warmer_snapshot()
            conversation_turn_latency = (
                _deferred_health_metric(defer_reason, pressure_state=pressure_state)
                if defer_db_metrics and defer_reason in {"pressure_protected_health", "health_detail_budget_exhausted"}
                else _build_unavailable_health_metric(defer_reason)
                if defer_db_metrics and defer_reason is not None
                else _run_health_section(
                    "conversation_turn_latency",
                    health_start,
                    health_budget_ms,
                    lambda: _build_conversation_turn_latency_health(pressure_state=pressure_state),
                )
            )
            if health_detail == "full" and _health_budget_exhausted(health_start, health_budget_ms):
                defer_db_metrics = True
                defer_reason = "health_detail_budget_exhausted"
            lifecycle_jobs = (
                _build_deferred_lifecycle_jobs_health(defer_reason, pressure_state=pressure_state)
                if defer_db_metrics and defer_reason is not None
                else _run_health_section(
                    "lifecycle_jobs",
                    health_start,
                    health_budget_ms,
                    _build_lifecycle_jobs_health,
                )
            )
            foreground_contract = (
                _deferred_health_metric(defer_reason, pressure_state=pressure_state)
                if defer_db_metrics and defer_reason in {"pressure_protected_health", "health_detail_budget_exhausted"}
                else _build_unavailable_health_metric(defer_reason)
                if defer_db_metrics and defer_reason is not None
                else _run_health_section(
                    "foreground_contract",
                    health_start,
                    health_budget_ms,
                    _build_foreground_contract_health,
                )
            )
            external_scheduler_component = external_maintenance["scheduler_state"]
            if external_scheduler_component == "not_installed":
                external_scheduler_component = "disabled"
            elif external_scheduler_component == "scheduled":
                external_scheduler_component = "available"
            ready["components"] = {
                "storage": "ok",
                "retrieval_index": ready["retrieval_state"],
                "semantic_full_search": ready.get("semantic_full_search_state", "unknown"),
                "activation_engine": "ok",
                "goal_engine": "ok",
                "curiosity_engine": "ok",
                "maintenance_scheduler": effective_state,
                "maintenance_scheduler_builtin": built_in_state,
                "maintenance_scheduler_external": external_scheduler_component,
                "required_context_cache": required_context_cache.get("status", "unknown"),
                "conversation_turn_latency": conversation_turn_latency.get("status", "unknown"),
                "lifecycle_jobs": lifecycle_jobs.get("status", "unknown"),
                "foreground_contract": foreground_contract.get("status", "unknown"),
                "autolearn_maintenance": "unknown",
            }
            if defer_db_metrics:
                contradiction_signals = (
                    _deferred_health_metric(defer_reason, pressure_state=pressure_state)
                    if defer_reason in {"pressure_protected_health", "health_detail_budget_exhausted"}
                    else _build_unavailable_health_metric(defer_reason)
                )
                indexed_concepts = None
                if defer_reason in {"pressure_protected_health", "health_detail_budget_exhausted"}:
                    deferred_session_learn_queue = _build_deferred_session_learn_queue_health(defer_reason)
                    session_learn_queue = {
                        **deferred_session_learn_queue,
                        "status": (
                            deferred_session_learn_queue.get("status")
                            if deferred_session_learn_queue.get("status") in {"warning", "critical"}
                            else "degraded"
                        ),
                        "alert": True,
                        "deferred": True,
                        "pressure_level": _pressure_state_level(pressure_state),
                    }
                else:
                    session_learn_queue = _build_deferred_session_learn_queue_health(defer_reason)
            else:
                if _read_only_aggregates_enabled():
                    try:
                        with read_snapshot_db("health") as conn:
                            contradiction_signals = _run_health_section(
                                "contradiction_signals",
                                health_start,
                                health_budget_ms,
                                lambda: _get_contradiction_signal_backlog(conn=conn),
                            )
                    except Exception as snap_err:
                        if not _read_only_aggregates_fallback_allowed():
                            raise
                        logger.warning(
                            "read-only snapshot failed for /health, falling back to legacy path: %s",
                            snap_err,
                        )
                        contradiction_signals = _run_health_section(
                            "contradiction_signals",
                            health_start,
                            health_budget_ms,
                            _get_contradiction_signal_backlog,
                        )
                else:
                    contradiction_signals = _run_health_section(
                        "contradiction_signals",
                        health_start,
                        health_budget_ms,
                        _get_contradiction_signal_backlog,
                    )
                indexed_concepts = retrieval_engine.index.document_count
                session_learn_queue = _run_health_section(
                    "session_learn_queue",
                    health_start,
                    health_budget_ms,
                    _build_session_learn_queue_health,
                )
            ready["metrics"] = {
                "indexed_concepts": indexed_concepts,
                "pricing": _get_pricing_health(),
                "contradiction_signals": contradiction_signals,
                "required_context_cache": required_context_cache,
                "conversation_turn_latency": conversation_turn_latency,
            }
            ready["metrics"]["session_learn_queue"] = session_learn_queue
            ready["metrics"]["lifecycle_jobs"] = lifecycle_jobs
            ready["metrics"]["foreground_contract"] = foreground_contract
            autolearn_maintenance = _build_autolearn_maintenance_health(defer_reason if defer_db_metrics else None)
            ready["metrics"]["autolearn_maintenance"] = autolearn_maintenance
            ready["components"]["autolearn_maintenance"] = autolearn_maintenance.get("status", "unknown")
            workstreams_metrics = _build_workstreams_metrics_health(defer_reason if defer_db_metrics else None)
            ready["metrics"]["workstreams"] = workstreams_metrics
            ready["components"]["session_learn_queue"] = session_learn_queue.get("status", "unknown")
            ready["components"]["workstreams"] = workstreams_metrics.get("status", "unknown")
            _apply_memory_durability_health(
                ready,
                lifecycle_jobs=lifecycle_jobs,
                session_learn_queue=session_learn_queue,
            )
            ready["feature_flags"] = _get_feature_flags()
            _derive_health_status(ready)
            ready["health_elapsed_ms"] = _health_elapsed_ms(health_start)
            return ready

        except Exception as e:
            logger.error(f"Health check failed: {e}", exc_info=True)
            return {
                "status": "unhealthy",
                "service": "pith",
                "timestamp": _utc_now_iso(),
                "version": SERVER_VERSION,
                "error": _safe_error(e),
            }


def _bounded_capture_budget_ms(raw: int | None, *, default_ms: int) -> int:
    if raw is None:
        return max(1, min(int(default_ms), DIAGNOSTIC_CAPTURE_BUDGET_MAX_MS))
    try:
        value = int(raw)
    except (TypeError, ValueError):
        raise HTTPException(status_code=400, detail="capture_budget_ms must be an integer")
    return max(1, min(value, DIAGNOSTIC_CAPTURE_BUDGET_MAX_MS))


def _fast_capture_budget_ms(section: str) -> int:
    if section == "fast_health":
        return max(1, int(_FAST_HEALTH_COLD_BUDGET_S * 1000))
    return max(1, int(_FAST_STATS_COLD_BUDGET_S * 1000))


def _validate_diagnostic_freshness(freshness: str) -> None:
    if freshness not in {"fast", "authoritative"}:
        raise HTTPException(status_code=400, detail="freshness must be 'fast' or 'authoritative'")


def _annotate_capture_contract(
    payload: dict,
    *,
    requested_freshness: str,
    authoritative: bool,
    value_semantics: str,
    degraded_reason: str | None,
    capture_budget_ms: int,
    capture_started: float | None = None,
) -> dict:
    if value_semantics not in {"real", "stale", "placeholder", "unavailable"}:
        raise ValueError(f"invalid diagnostic value semantics: {value_semantics}")
    annotated = dict(payload)
    annotated["capture_degraded"] = bool(degraded_reason or value_semantics in {"stale", "placeholder", "unavailable"})
    annotated["capture_degraded_reason"] = degraded_reason
    annotated["capture_value_semantics"] = value_semantics
    annotated["authoritative"] = authoritative
    annotated["requested_freshness"] = requested_freshness
    annotated["capture_budget_ms"] = capture_budget_ms
    if capture_started is not None:
        annotated["capture_elapsed_ms"] = round((time.monotonic() - capture_started) * 1000, 2)
    return annotated


@app.get("/pith_stats")
def pith_stats(
    detail: str = "fast",
    freshness: str = "fast",
    force_refresh: bool = False,
    capture_budget_ms: str | None = None,
):
    """Get overall pith statistics via aggregate SQL (no N+1 loop)."""
    with request_db_scope("pith_stats"):
        if detail not in {"fast", "full"}:
            raise HTTPException(status_code=400, detail="detail must be 'fast' or 'full'")
        _validate_diagnostic_freshness(freshness)
        if capture_budget_ms is not None:
            _bounded_capture_budget_ms(
                capture_budget_ms,
                default_ms=DIAGNOSTIC_AUTHORITATIVE_CAPTURE_BUDGET_DEFAULT_MS,
            )
        if detail == "fast":
            if freshness == "authoritative":
                budget_ms = _bounded_capture_budget_ms(
                    capture_budget_ms,
                    default_ms=DIAGNOSTIC_AUTHORITATIVE_CAPTURE_BUDGET_DEFAULT_MS,
                )
                return _build_pith_stats_authoritative_cached(budget_ms, force_refresh=force_refresh)
            return _build_pith_stats_fast_cached()

        from app.storage import get_pith_stats_aggregates

        # DEBT-145: Forward full aggregate dict instead of cherry-picking fields.
        # New fields from get_pith_stats_aggregates() are auto-surfaced.
        if _read_only_aggregates_enabled():
            try:
                with read_snapshot_db("pith_stats") as conn:
                    agg = get_pith_stats_aggregates(conn=conn)
                    agg["associations"] = count_associations(conn=conn)
            except Exception as snap_err:
                if not _read_only_aggregates_fallback_allowed():
                    raise
                logger.warning(
                    "read-only snapshot failed for /pith_stats, falling back to legacy path: %s",
                    snap_err,
                )
                agg = get_pith_stats_aggregates()
                agg["associations"] = count_associations()
        else:
            agg = get_pith_stats_aggregates()
            agg["associations"] = count_associations()
        agg["pending_questions"] = len(question_queue.get_questions(limit=1000))
        # BLIND-001: Surface computed blind spots in stats dashboard
        try:
            from app.session.self_model import SelfModelManager

            _blind_spots = SelfModelManager().get_blind_spots()
            agg["blind_spots"] = [
                {
                    "description": bs.description if isinstance(bs.description, str) else str(bs),
                    "severity": getattr(bs, "severity", "moderate"),
                }
                for bs in _blind_spots
            ]
        except Exception:
            agg["blind_spots"] = []
        agg.setdefault("mode", "full")
        agg.setdefault("generated_at", _utc_now_iso())
        agg.setdefault("cache_age_ms", 0)
        agg.setdefault("partial", False)
        agg.setdefault("section_errors", {})
        agg.setdefault("section_timings_ms", {})
        return _annotate_capture_contract(
            agg,
            requested_freshness=freshness,
            authoritative=freshness == "authoritative",
            value_semantics="real",
            degraded_reason=None,
            capture_budget_ms=_bounded_capture_budget_ms(
                capture_budget_ms,
                default_ms=DIAGNOSTIC_AUTHORITATIVE_CAPTURE_BUDGET_DEFAULT_MS,
            ),
        )


def _build_pith_stats_fast_payload() -> dict:
    """Build the fast stats payload and leave cache policy to the caller."""
    from app.storage import get_pith_stats_fast

    section_errors: dict[str, str] = {}
    payload = get_pith_stats_fast()
    try:
        payload["pending_questions"] = len(question_queue.get_questions(limit=1000))
    except Exception as err:
        payload["pending_questions"] = 0
        section_errors["pending_questions"] = _safe_error(err)
    payload.update(
        {
            "mode": "fast",
            "generated_at": _utc_now_iso(),
            "cache_age_ms": 0,
            "partial": bool(section_errors),
            "stale": False,
            "section_errors": section_errors,
        }
    )
    payload = _annotate_fast_stats_freshness(payload, "fresh", "ok", "cache_fresh", cache_age_ms=0)
    return _annotate_capture_contract(
        payload,
        requested_freshness="fast",
        authoritative=False,
        value_semantics="real",
        degraded_reason=None,
        capture_budget_ms=_fast_capture_budget_ms("fast_stats"),
    )


def _fast_stats_max_stale_ms() -> int:
    return int(max(0.0, _FAST_STATS_MAX_STALE_S) * 1000)


def _observability_snapshot_locked(observability: dict) -> dict:
    """Project an observability dict into the public shape.

    Replaces the internal ``last_success_monotonic`` key with a derived
    ``last_success_age_ms`` (None when no success has been recorded). The 0.0
    monotonic value is valid, so the guard is ``is not None`` (EUNOMIA-125).
    """
    snapshot = dict(observability)
    last_success = snapshot.pop("last_success_monotonic", None)
    if last_success is not None:
        snapshot["last_success_age_ms"] = round((time.monotonic() - last_success) * 1000)
    else:
        snapshot["last_success_age_ms"] = None
    return snapshot


def _fast_stats_observability_snapshot() -> dict:
    with _FAST_STATS_REFRESH_LOCK:
        return _observability_snapshot_locked(_FAST_STATS_OBSERVABILITY)


def _fast_health_observability_snapshot() -> dict:
    with _FAST_HEALTH_REFRESH_LOCK:
        return _observability_snapshot_locked(_FAST_HEALTH_OBSERVABILITY)


def _annotate_fast_stats_freshness(
    payload: dict,
    freshness_state: str,
    freshness_status: str,
    freshness_reason: str,
    *,
    cache_age_ms: int | None = None,
    observability: dict | None = None,
) -> dict:
    annotated = dict(payload)
    if cache_age_ms is not None:
        annotated["cache_age_ms"] = cache_age_ms
    annotated.update(
        {
            "freshness_state": freshness_state,
            "freshness_status": freshness_status,
            "freshness_reason": freshness_reason,
            "max_stale_ms": _fast_stats_max_stale_ms(),
            "refresh_observability": (
                observability if observability is not None else _fast_stats_observability_snapshot()
            ),
        }
    )
    return annotated


def _classify_stale_fast_stats(cache_age_ms: int, refresh_error: str | None) -> tuple[str, str, str]:
    if refresh_error:
        return "refresh_failed", "degraded", refresh_error
    if cache_age_ms > _fast_stats_max_stale_ms():
        return "stale_beyond_slo", "degraded", "cache_age_exceeded_max_stale"
    return "refreshing_bounded", "warning", "refresh_in_progress"


def _record_fast_stats_refresh_observation(success: bool, duration_ms: float, error: str | None = None) -> None:
    global _FAST_STATS_REFRESH_ERROR
    with _FAST_STATS_REFRESH_LOCK:
        if success:
            _FAST_STATS_OBSERVABILITY["refresh_success_count"] = (
                int(_FAST_STATS_OBSERVABILITY["refresh_success_count"] or 0) + 1
            )
            _FAST_STATS_OBSERVABILITY["last_refresh_error"] = None
            _FAST_STATS_OBSERVABILITY["last_success_monotonic"] = time.monotonic()
            _FAST_STATS_REFRESH_ERROR = None
        else:
            _FAST_STATS_OBSERVABILITY["refresh_failure_count"] = (
                int(_FAST_STATS_OBSERVABILITY["refresh_failure_count"] or 0) + 1
            )
            _FAST_STATS_OBSERVABILITY["last_refresh_error"] = error or "unknown_refresh_error"
            _FAST_STATS_REFRESH_ERROR = error or "unknown_refresh_error"
            if error == "slot_acquire_timeout":
                _FAST_STATS_OBSERVABILITY["slot_acquire_timeout_count"] = (
                    int(_FAST_STATS_OBSERVABILITY["slot_acquire_timeout_count"] or 0) + 1
                )
        _FAST_STATS_OBSERVABILITY["last_refresh_duration_ms"] = round(duration_ms, 2)


def _record_fast_stats_stale_served() -> None:
    with _FAST_STATS_REFRESH_LOCK:
        _FAST_STATS_OBSERVABILITY["stale_served_count"] = int(_FAST_STATS_OBSERVABILITY["stale_served_count"] or 0) + 1


def _record_fast_health_refresh_observation(success: bool, duration_ms: float, error: str | None = None) -> None:
    """Mirror of _record_fast_stats_refresh_observation for the health worker (EUNOMIA-125)."""
    global _FAST_HEALTH_REFRESH_ERROR
    with _FAST_HEALTH_REFRESH_LOCK:
        if success:
            _FAST_HEALTH_OBSERVABILITY["refresh_success_count"] = (
                int(_FAST_HEALTH_OBSERVABILITY["refresh_success_count"] or 0) + 1
            )
            _FAST_HEALTH_OBSERVABILITY["last_refresh_error"] = None
            _FAST_HEALTH_OBSERVABILITY["last_success_monotonic"] = time.monotonic()
            _FAST_HEALTH_REFRESH_ERROR = None
        else:
            _FAST_HEALTH_OBSERVABILITY["refresh_failure_count"] = (
                int(_FAST_HEALTH_OBSERVABILITY["refresh_failure_count"] or 0) + 1
            )
            _FAST_HEALTH_OBSERVABILITY["last_refresh_error"] = error or "unknown_refresh_error"
            _FAST_HEALTH_REFRESH_ERROR = error or "unknown_refresh_error"
            if error == "slot_acquire_timeout":
                _FAST_HEALTH_OBSERVABILITY["slot_acquire_timeout_count"] = (
                    int(_FAST_HEALTH_OBSERVABILITY["slot_acquire_timeout_count"] or 0) + 1
                )
        _FAST_HEALTH_OBSERVABILITY["last_refresh_duration_ms"] = round(duration_ms, 2)


def _record_fast_health_stale_served() -> None:
    with _FAST_HEALTH_REFRESH_LOCK:
        _FAST_HEALTH_OBSERVABILITY["stale_served_count"] = (
            int(_FAST_HEALTH_OBSERVABILITY["stale_served_count"] or 0) + 1
        )


def _knowledge_areas_observability_snapshot() -> dict:
    with _KNOWLEDGE_AREAS_REFRESH_LOCK:
        return _observability_snapshot_locked(_FAST_KNOWLEDGE_AREAS_OBSERVABILITY)


def _record_knowledge_areas_refresh_observation(success: bool, duration_ms: float, error: str | None = None) -> None:
    """Mirror of _record_fast_health_refresh_observation for the KA worker (TOOLING-100)."""
    global _KNOWLEDGE_AREAS_REFRESH_ERROR
    with _KNOWLEDGE_AREAS_REFRESH_LOCK:
        if success:
            _FAST_KNOWLEDGE_AREAS_OBSERVABILITY["refresh_success_count"] = (
                int(_FAST_KNOWLEDGE_AREAS_OBSERVABILITY["refresh_success_count"] or 0) + 1
            )
            _FAST_KNOWLEDGE_AREAS_OBSERVABILITY["last_refresh_error"] = None
            _FAST_KNOWLEDGE_AREAS_OBSERVABILITY["last_success_monotonic"] = time.monotonic()
            _KNOWLEDGE_AREAS_REFRESH_ERROR = None
        else:
            _FAST_KNOWLEDGE_AREAS_OBSERVABILITY["refresh_failure_count"] = (
                int(_FAST_KNOWLEDGE_AREAS_OBSERVABILITY["refresh_failure_count"] or 0) + 1
            )
            _FAST_KNOWLEDGE_AREAS_OBSERVABILITY["last_refresh_error"] = error or "unknown_refresh_error"
            _KNOWLEDGE_AREAS_REFRESH_ERROR = error or "unknown_refresh_error"
            if error == "slot_acquire_timeout":
                _FAST_KNOWLEDGE_AREAS_OBSERVABILITY["slot_acquire_timeout_count"] = (
                    int(_FAST_KNOWLEDGE_AREAS_OBSERVABILITY["slot_acquire_timeout_count"] or 0) + 1
                )
        _FAST_KNOWLEDGE_AREAS_OBSERVABILITY["last_refresh_duration_ms"] = round(duration_ms, 2)


def _record_knowledge_areas_stale_served() -> None:
    with _KNOWLEDGE_AREAS_REFRESH_LOCK:
        _FAST_KNOWLEDGE_AREAS_OBSERVABILITY["stale_served_count"] = (
            int(_FAST_KNOWLEDGE_AREAS_OBSERVABILITY["stale_served_count"] or 0) + 1
        )


def _refresh_fast_stats_cache() -> dict:
    """Refresh fast stats cache from a worker so callers can stay bounded."""
    global _FAST_STATS_CACHE, _FAST_STATS_REFRESH_ERROR
    started = time.perf_counter()
    acquired = _DIAGNOSTIC_ENDPOINT_SEMAPHORE.acquire(timeout=_DIAGNOSTIC_REFRESH_SLOT_TIMEOUT_S)
    if not acquired:
        duration_ms = (time.perf_counter() - started) * 1000
        _record_fast_stats_refresh_observation(False, duration_ms, "slot_acquire_timeout")
        raise TimeoutError("slot_acquire_timeout")
    try:
        payload = _build_pith_stats_fast_payload()
        duration_ms = (time.perf_counter() - started) * 1000
        _record_fast_stats_refresh_observation(True, duration_ms)
        payload = _annotate_fast_stats_freshness(payload, "fresh", "ok", "cache_fresh", cache_age_ms=0)
        with _FAST_STATS_CACHE_LOCK:
            _FAST_STATS_CACHE = (time.monotonic(), dict(payload))
        return payload
    except Exception as err:
        duration_ms = (time.perf_counter() - started) * 1000
        _record_fast_stats_refresh_observation(False, duration_ms, _safe_error(err))
        raise
    finally:
        _DIAGNOSTIC_ENDPOINT_SEMAPHORE.release()


def _record_fast_stats_refresh_result(future: concurrent.futures.Future) -> None:
    global _FAST_STATS_REFRESH_ERROR
    try:
        exc = future.exception()
    except concurrent.futures.CancelledError:
        exc = None
    if exc is not None:
        with _FAST_STATS_REFRESH_LOCK:
            _FAST_STATS_REFRESH_ERROR = _safe_error(exc)


def _ensure_fast_stats_refresh_started() -> concurrent.futures.Future:
    global _FAST_STATS_REFRESH_FUTURE
    add_callback = False
    with _FAST_STATS_REFRESH_LOCK:
        if _FAST_STATS_REFRESH_FUTURE is None or _FAST_STATS_REFRESH_FUTURE.done():
            _FAST_STATS_REFRESH_FUTURE = _DIAGNOSTIC_REFRESH_EXECUTOR.submit(_refresh_fast_stats_cache)
            add_callback = True
        future = _FAST_STATS_REFRESH_FUTURE
    if add_callback:
        future.add_done_callback(_record_fast_stats_refresh_result)
    return future


def _build_pith_stats_fast_cached() -> dict:
    """Build/coalesce default stats so status surfaces do not stampede SQLite."""
    now = time.monotonic()
    with _FAST_STATS_CACHE_LOCK:
        if _FAST_STATS_CACHE is not None:
            cached_at, cached_payload = _FAST_STATS_CACHE
            cache_age_ms = int((now - cached_at) * 1000)
            if cache_age_ms <= int(_FAST_STATS_CACHE_TTL_S * 1000):
                payload = dict(cached_payload)
                return _annotate_fast_stats_freshness(payload, "fresh", "ok", "cache_fresh", cache_age_ms=cache_age_ms)
            stale_cache = (cached_at, dict(cached_payload))
        else:
            stale_cache = None

    refresh_future = _ensure_fast_stats_refresh_started()
    if stale_cache is not None:
        with _FAST_STATS_REFRESH_LOCK:
            refresh_error = _FAST_STATS_REFRESH_ERROR
        return _build_stale_diagnostic_payload(stale_cache, "fast_stats", refresh_error or "refresh_in_progress")

    try:
        return refresh_future.result(timeout=max(0.001, _FAST_STATS_COLD_BUDGET_S))
    except concurrent.futures.TimeoutError:
        return _build_empty_fast_stats_payload("budget_exceeded")
    except Exception as err:
        return _build_empty_fast_stats_payload(_safe_error(err))


def _build_pith_stats_authoritative_cached(capture_budget_ms: int, *, force_refresh: bool = False) -> dict:
    """Run an opt-in bounded stats refresh for governance captures."""
    capture_started = time.monotonic()
    refresh_future = (
        _DIAGNOSTIC_REFRESH_EXECUTOR.submit(_refresh_fast_stats_cache)
        if force_refresh
        else _ensure_fast_stats_refresh_started()
    )
    try:
        payload = refresh_future.result(timeout=max(0.001, capture_budget_ms / 1000))
        return _annotate_capture_contract(
            payload,
            requested_freshness="authoritative",
            authoritative=True,
            value_semantics="real",
            degraded_reason=None,
            capture_budget_ms=capture_budget_ms,
            capture_started=capture_started,
        )
    except concurrent.futures.TimeoutError:
        with _FAST_STATS_CACHE_LOCK:
            stale_cache = _FAST_STATS_CACHE
        if stale_cache is not None:
            return _build_stale_diagnostic_payload(
                stale_cache,
                "fast_stats",
                "authoritative_budget_exceeded",
                requested_freshness="authoritative",
                authoritative=False,
                capture_budget_ms=capture_budget_ms,
                capture_started=capture_started,
            )
        return _build_empty_fast_stats_payload(
            "budget_exceeded",
            requested_freshness="authoritative",
            capture_budget_ms=capture_budget_ms,
            capture_started=capture_started,
        )
    except Exception as err:
        error = _safe_error(err)
        with _FAST_STATS_CACHE_LOCK:
            stale_cache = _FAST_STATS_CACHE
        if stale_cache is not None:
            return _build_stale_diagnostic_payload(
                stale_cache,
                "fast_stats",
                error,
                requested_freshness="authoritative",
                authoritative=False,
                capture_budget_ms=capture_budget_ms,
                capture_started=capture_started,
            )
        return _build_empty_fast_stats_payload(
            error,
            requested_freshness="authoritative",
            capture_budget_ms=capture_budget_ms,
            capture_started=capture_started,
        )


def _build_stale_diagnostic_payload(
    cache_entry: tuple[float, dict],
    section: str,
    error: str,
    *,
    requested_freshness: str = "fast",
    authoritative: bool = False,
    capture_budget_ms: int | None = None,
    capture_started: float | None = None,
) -> dict:
    cached_at, cached_payload = cache_entry
    payload = dict(cached_payload)
    errors = dict(payload.get("section_errors") or {})
    errors[section] = error
    cache_age_ms = int((time.monotonic() - cached_at) * 1000)
    state, status, reason = _classify_stale_fast_stats(cache_age_ms, error if error != "refresh_in_progress" else None)
    if section == "fast_health":
        _record_fast_health_stale_served()
        observability = _fast_health_observability_snapshot()
    elif section == "knowledge_areas":
        _record_knowledge_areas_stale_served()
        observability = _knowledge_areas_observability_snapshot()
    else:
        _record_fast_stats_stale_served()
        observability = None  # default snapshot = fast_stats observability
    payload.update(
        {
            "cache_age_ms": cache_age_ms,
            "partial": True,
            "stale": True,
            "section_errors": errors,
        }
    )
    payload = _annotate_fast_stats_freshness(
        payload, state, status, reason, cache_age_ms=cache_age_ms, observability=observability
    )
    return _annotate_capture_contract(
        payload,
        requested_freshness=requested_freshness,
        authoritative=authoritative,
        value_semantics="stale",
        degraded_reason=error,
        capture_budget_ms=capture_budget_ms or _fast_capture_budget_ms(section),
        capture_started=capture_started,
    )


def _build_empty_fast_stats_payload(
    error: str,
    *,
    requested_freshness: str = "fast",
    capture_budget_ms: int | None = None,
    capture_started: float | None = None,
) -> dict:
    if error == "budget_exceeded":
        state, status, reason = "cold_budget_exceeded", "warning", "budget_exceeded"
    else:
        state, status, reason = "cold_failed", "degraded", error
    payload = {
        "mode": "fast",
        "generated_at": _utc_now_iso(),
        "cache_age_ms": 0,
        "partial": True,
        "stale": False,
        "section_errors": {"fast_stats": error},
        "total_concepts": 0,
        "avg_confidence": 0.0,
        "avg_stability": 0.0,
        "knowledge_areas": 0,
        "associations": 0,
        "data_quality": {"null_timestamps": 0, "bad_json": 0},
        "pending_questions": 0,
    }
    payload = _annotate_fast_stats_freshness(payload, state, status, reason, cache_age_ms=0)
    return _annotate_capture_contract(
        payload,
        requested_freshness=requested_freshness,
        authoritative=False,
        value_semantics="placeholder",
        degraded_reason=error,
        capture_budget_ms=capture_budget_ms or _fast_capture_budget_ms("fast_stats"),
        capture_started=capture_started,
    )


def _build_empty_fast_health_payload(
    error: str,
    *,
    requested_freshness: str = "fast",
    capture_budget_ms: int | None = None,
    capture_started: float | None = None,
) -> dict:
    if error == "budget_exceeded":
        state, status, reason = "cold_budget_exceeded", "warning", "budget_exceeded"
    else:
        state, status, reason = "cold_failed", "degraded", error
    payload = {
        "mode": "fast",
        "generated_at": _utc_now_iso(),
        "cache_age_ms": 0,
        "partial": True,
        "stale": False,
        "section_errors": {"fast_health": error},
        "status": "partial",
        "health_score": 0.0,
        "total_concepts": 0,
        "avg_confidence": 0.0,
        "avg_stability": 0.0,
    }
    payload = _annotate_fast_stats_freshness(
        payload,
        state,
        status,
        reason,
        cache_age_ms=0,
        observability=_fast_health_observability_snapshot(),
    )
    return _annotate_capture_contract(
        payload,
        requested_freshness=requested_freshness,
        authoritative=False,
        value_semantics="placeholder",
        degraded_reason=error,
        capture_budget_ms=capture_budget_ms or _fast_capture_budget_ms("fast_health"),
        capture_started=capture_started,
    )


def _refresh_fast_health_cache() -> dict:
    """Refresh fast health cache from a worker so callers can stay bounded.

    EUNOMIA-125: mirror of _refresh_fast_stats_cache. Waits up to the long
    background timeout for the single diagnostic slot (build is ~4s) instead of
    bailing at 50ms, and records a named slot_acquire_timeout on miss so the
    failure is no longer silent.
    """
    global _FAST_HEALTH_CACHE, _FAST_HEALTH_REFRESH_ERROR
    started = time.perf_counter()
    acquired = _DIAGNOSTIC_ENDPOINT_SEMAPHORE.acquire(timeout=_DIAGNOSTIC_REFRESH_SLOT_TIMEOUT_S)
    if not acquired:
        duration_ms = (time.perf_counter() - started) * 1000
        _record_fast_health_refresh_observation(False, duration_ms, "slot_acquire_timeout")
        raise TimeoutError("slot_acquire_timeout")
    try:
        from app.storage import get_pith_health_fast

        health = get_pith_health_fast()
        health.update(
            {
                "mode": "fast",
                "generated_at": _utc_now_iso(),
                "cache_age_ms": 0,
                "partial": False,
                "stale": False,
                "section_errors": {},
            }
        )
        duration_ms = (time.perf_counter() - started) * 1000
        _record_fast_health_refresh_observation(True, duration_ms)
        health = _annotate_fast_stats_freshness(
            health,
            "fresh",
            "ok",
            "cache_fresh",
            cache_age_ms=0,
            observability=_fast_health_observability_snapshot(),
        )
        health = _annotate_capture_contract(
            health,
            requested_freshness="fast",
            authoritative=False,
            value_semantics="real",
            degraded_reason=None,
            capture_budget_ms=_fast_capture_budget_ms("fast_health"),
        )
        with _FAST_HEALTH_CACHE_LOCK:
            _FAST_HEALTH_CACHE = (time.monotonic(), dict(health))
        return health
    except Exception as err:
        duration_ms = (time.perf_counter() - started) * 1000
        _record_fast_health_refresh_observation(False, duration_ms, _safe_error(err))
        raise
    finally:
        _DIAGNOSTIC_ENDPOINT_SEMAPHORE.release()


def _record_fast_health_refresh_result(future: concurrent.futures.Future) -> None:
    global _FAST_HEALTH_REFRESH_ERROR
    try:
        exc = future.exception()
    except concurrent.futures.CancelledError:
        exc = None
    if exc is not None:
        with _FAST_HEALTH_REFRESH_LOCK:
            _FAST_HEALTH_REFRESH_ERROR = _safe_error(exc)


def _ensure_fast_health_refresh_started() -> concurrent.futures.Future:
    global _FAST_HEALTH_REFRESH_FUTURE
    add_callback = False
    with _FAST_HEALTH_REFRESH_LOCK:
        if _FAST_HEALTH_REFRESH_FUTURE is None or _FAST_HEALTH_REFRESH_FUTURE.done():
            _FAST_HEALTH_REFRESH_FUTURE = _DIAGNOSTIC_REFRESH_EXECUTOR.submit(_refresh_fast_health_cache)
            add_callback = True
        future = _FAST_HEALTH_REFRESH_FUTURE
    if add_callback:
        future.add_done_callback(_record_fast_health_refresh_result)
    return future


def _build_pith_health_fast_cached() -> dict:
    """Build/coalesce default health so diagnostic readers remain bounded.

    EUNOMIA-125: mirrors _build_pith_stats_fast_cached — serve warm-but-stale
    immediately and schedule a background refresh instead of refreshing inline
    only (which left the cache silently stale for hours on zero-traffic readers).
    """
    now = time.monotonic()
    with _FAST_HEALTH_CACHE_LOCK:
        if _FAST_HEALTH_CACHE is not None:
            cached_at, cached_payload = _FAST_HEALTH_CACHE
            cache_age_ms = int((now - cached_at) * 1000)
            if cache_age_ms <= int(_FAST_HEALTH_CACHE_TTL_S * 1000):
                payload = dict(cached_payload)
                payload["cache_age_ms"] = cache_age_ms
                return _annotate_capture_contract(
                    payload,
                    requested_freshness="fast",
                    authoritative=False,
                    value_semantics="real",
                    degraded_reason=None,
                    capture_budget_ms=_fast_capture_budget_ms("fast_health"),
                )
            stale_cache = (cached_at, dict(cached_payload))
        else:
            stale_cache = None

    refresh_future = _ensure_fast_health_refresh_started()
    if stale_cache is not None:
        with _FAST_HEALTH_REFRESH_LOCK:
            refresh_error = _FAST_HEALTH_REFRESH_ERROR
        return _build_stale_diagnostic_payload(stale_cache, "fast_health", refresh_error or "refresh_in_progress")

    try:
        return refresh_future.result(timeout=max(0.001, _FAST_HEALTH_COLD_BUDGET_S))
    except concurrent.futures.TimeoutError:
        return _build_empty_fast_health_payload("budget_exceeded")
    except Exception as err:
        return _build_empty_fast_health_payload(_safe_error(err))


def _build_pith_health_authoritative_cached(capture_budget_ms: int, *, force_refresh: bool = False) -> dict:
    """Run an opt-in bounded health refresh for governance captures."""
    capture_started = time.monotonic()
    refresh_future = (
        _DIAGNOSTIC_REFRESH_EXECUTOR.submit(_refresh_fast_health_cache)
        if force_refresh
        else _ensure_fast_health_refresh_started()
    )
    try:
        payload = refresh_future.result(timeout=max(0.001, capture_budget_ms / 1000))
        return _annotate_capture_contract(
            payload,
            requested_freshness="authoritative",
            authoritative=True,
            value_semantics="real",
            degraded_reason=None,
            capture_budget_ms=capture_budget_ms,
            capture_started=capture_started,
        )
    except concurrent.futures.TimeoutError:
        with _FAST_HEALTH_CACHE_LOCK:
            stale_cache = _FAST_HEALTH_CACHE
        if stale_cache is not None:
            return _build_stale_diagnostic_payload(
                stale_cache,
                "fast_health",
                "authoritative_budget_exceeded",
                requested_freshness="authoritative",
                authoritative=False,
                capture_budget_ms=capture_budget_ms,
                capture_started=capture_started,
            )
        return _build_empty_fast_health_payload(
            "budget_exceeded",
            requested_freshness="authoritative",
            capture_budget_ms=capture_budget_ms,
            capture_started=capture_started,
        )
    except Exception as err:
        error = _safe_error(err)
        with _FAST_HEALTH_CACHE_LOCK:
            stale_cache = _FAST_HEALTH_CACHE
        if stale_cache is not None:
            return _build_stale_diagnostic_payload(
                stale_cache,
                "fast_health",
                error,
                requested_freshness="authoritative",
                authoritative=False,
                capture_budget_ms=capture_budget_ms,
                capture_started=capture_started,
            )
        return _build_empty_fast_health_payload(
            error,
            requested_freshness="authoritative",
            capture_budget_ms=capture_budget_ms,
            capture_started=capture_started,
        )


def _build_deferred_full_health_payload(base: dict, active_reflection: dict | None) -> dict:
    """Return a full-mode health payload without synchronous legacy full analysis."""
    health = dict(base)
    section_errors = dict(health.get("section_errors") or {})
    section_errors.setdefault("full_analysis", "deferred: synchronous_full_health_disabled")
    section_errors.setdefault("fts_verbatim_parity", "deferred: synchronous_full_health_disabled")

    existing_reason = health.get("capture_degraded_reason")
    deferred_reason = "full_sections_deferred"
    if existing_reason:
        degraded_reason = (
            existing_reason if deferred_reason in str(existing_reason) else f"{existing_reason};{deferred_reason}"
        )
    else:
        degraded_reason = deferred_reason

    health["mode"] = "full"
    health["partial"] = True
    health["section_errors"] = section_errors
    health["capture_degraded"] = True
    health["capture_degraded_reason"] = degraded_reason
    health["active_reflection"] = active_reflection
    health.pop("fts_verbatim_parity", None)
    health.setdefault("generated_at", _utc_now_iso())
    health.setdefault("cache_age_ms", 0)
    health.setdefault("section_timings_ms", {})
    return health


_PITH_HEALTH_ALLOWED_INCLUDES = {
    "fts_concepts_parity",
    "fts_verbatim_parity",
}


def _parse_pith_health_include(include: str | None) -> set[str]:
    if not include:
        return set()
    requested = {part.strip() for part in include.split(",") if part.strip()}
    unknown = requested - _PITH_HEALTH_ALLOWED_INCLUDES
    if unknown:
        raise HTTPException(
            status_code=400,
            detail=f"unknown pith_health include(s): {','.join(sorted(unknown))}",
        )
    return requested


def _append_capture_degraded_reason(existing: object, reason: str) -> str:
    if not existing:
        return reason
    existing_text = str(existing)
    return existing_text if reason in existing_text else f"{existing_text};{reason}"


def _attach_requested_pith_health_sections(
    health: dict,
    requested_sections: set[str],
    *,
    capture_started: float,
    capture_budget_ms: int,
) -> dict:
    if not requested_sections:
        return health
    from app.storage.stats import get_fts_concepts_parity, get_fts_verbatim_parity

    enriched = dict(health)
    section_errors = dict(enriched.get("section_errors") or {})
    parity_sections = (
        ("fts_concepts_parity", get_fts_concepts_parity),
        ("fts_verbatim_parity", get_fts_verbatim_parity),
    )
    for section_name, loader in parity_sections:
        if section_name not in requested_sections:
            continue
        elapsed_ms = int((time.monotonic() - capture_started) * 1000)
        remaining_budget_ms = capture_budget_ms - elapsed_ms
        if remaining_budget_ms <= 0:
            parity = {
                "status": "unavailable",
                "error": "budget_exceeded",
                "budget_ms": 0,
            }
        else:
            parity_budget_ms = min(1000, remaining_budget_ms)
            try:
                parity = loader(budget_ms=parity_budget_ms)
            except Exception as err:
                parity = {
                    "status": "unavailable",
                    "error": _safe_error(err),
                    "budget_ms": parity_budget_ms,
                }

        enriched[section_name] = parity
        if parity.get("status") == "unavailable":
            section_errors[section_name] = parity.get("error", "unavailable")
            enriched["partial"] = True
            enriched["capture_degraded"] = True
            enriched["capture_degraded_reason"] = _append_capture_degraded_reason(
                enriched.get("capture_degraded_reason"),
                f"{section_name}_unavailable",
            )
        else:
            section_errors.pop(section_name, None)
    enriched["section_errors"] = section_errors
    return enriched


def _build_empty_knowledge_areas_payload(error: str) -> dict:
    return {
        "total": 0,
        "areas": [],
        "mode": "fast",
        "generated_at": _utc_now_iso(),
        "cache_age_ms": 0,
        "partial": True,
        "stale": False,
        "section_errors": {"knowledge_areas": error},
    }


def _refresh_knowledge_areas_cache() -> dict:
    """Refresh the knowledge-area cache from a worker so callers stay bounded.

    TOOLING-100: mirror of _refresh_fast_health_cache. Waits up to the long
    background timeout for the single diagnostic slot instead of bailing at 50ms,
    and records a named slot_acquire_timeout on miss (ends the silent-stale property).
    """
    global _KNOWLEDGE_AREAS_CACHE
    started = time.perf_counter()
    acquired = _DIAGNOSTIC_ENDPOINT_SEMAPHORE.acquire(timeout=_DIAGNOSTIC_REFRESH_SLOT_TIMEOUT_S)
    if not acquired:
        duration_ms = (time.perf_counter() - started) * 1000
        _record_knowledge_areas_refresh_observation(False, duration_ms, "slot_acquire_timeout")
        raise TimeoutError("slot_acquire_timeout")
    try:
        from app.storage import list_knowledge_area_summaries

        areas = list_knowledge_area_summaries()
        payload = {
            "total": len(areas),
            "areas": areas,
            "mode": "fast",
            "generated_at": _utc_now_iso(),
            "cache_age_ms": 0,
            "partial": False,
            "stale": False,
            "section_errors": {},
        }
        duration_ms = (time.perf_counter() - started) * 1000
        _record_knowledge_areas_refresh_observation(True, duration_ms)
        with _KNOWLEDGE_AREAS_CACHE_LOCK:
            _KNOWLEDGE_AREAS_CACHE = (time.monotonic(), dict(payload))
        return payload
    except Exception as err:
        duration_ms = (time.perf_counter() - started) * 1000
        logger.error("Fast knowledge area listing failed: %s", err, exc_info=True)
        _record_knowledge_areas_refresh_observation(False, duration_ms, _safe_error(err))
        raise
    finally:
        _DIAGNOSTIC_ENDPOINT_SEMAPHORE.release()


def _record_knowledge_areas_refresh_result(future: concurrent.futures.Future) -> None:
    global _KNOWLEDGE_AREAS_REFRESH_ERROR
    try:
        exc = future.exception()
    except concurrent.futures.CancelledError:
        exc = None
    if exc is not None:
        with _KNOWLEDGE_AREAS_REFRESH_LOCK:
            _KNOWLEDGE_AREAS_REFRESH_ERROR = _safe_error(exc)


def _ensure_knowledge_areas_refresh_started() -> concurrent.futures.Future:
    global _KNOWLEDGE_AREAS_REFRESH_FUTURE
    add_callback = False
    with _KNOWLEDGE_AREAS_REFRESH_LOCK:
        if _KNOWLEDGE_AREAS_REFRESH_FUTURE is None or _KNOWLEDGE_AREAS_REFRESH_FUTURE.done():
            _KNOWLEDGE_AREAS_REFRESH_FUTURE = _DIAGNOSTIC_REFRESH_EXECUTOR.submit(_refresh_knowledge_areas_cache)
            add_callback = True
        future = _KNOWLEDGE_AREAS_REFRESH_FUTURE
    if add_callback:
        future.add_done_callback(_record_knowledge_areas_refresh_result)
    return future


def _build_knowledge_areas_cached() -> dict:
    """Return knowledge-area summaries without materializing every concept.

    TOOLING-100: mirrors _build_pith_health_fast_cached — serve warm-but-stale
    immediately and schedule a background refresh instead of acquiring the single
    diagnostic slot inline (which left the cache silently stale under contention
    and emitted the deprecated slot-unavailable error string).
    """
    now = time.monotonic()
    with _KNOWLEDGE_AREAS_CACHE_LOCK:
        if _KNOWLEDGE_AREAS_CACHE is not None:
            cached_at, cached_payload = _KNOWLEDGE_AREAS_CACHE
            cache_age_ms = int((now - cached_at) * 1000)
            if cache_age_ms <= int(_KNOWLEDGE_AREAS_CACHE_TTL_S * 1000):
                payload = dict(cached_payload)
                payload["cache_age_ms"] = cache_age_ms
                return payload
            stale_cache = (cached_at, dict(cached_payload))
        else:
            stale_cache = None

    refresh_future = _ensure_knowledge_areas_refresh_started()
    if stale_cache is not None:
        with _KNOWLEDGE_AREAS_REFRESH_LOCK:
            refresh_error = _KNOWLEDGE_AREAS_REFRESH_ERROR
        return _build_stale_diagnostic_payload(stale_cache, "knowledge_areas", refresh_error or "refresh_in_progress")

    try:
        return refresh_future.result(timeout=max(0.001, _KNOWLEDGE_AREAS_COLD_BUDGET_S))
    except concurrent.futures.TimeoutError:
        return _build_empty_knowledge_areas_payload("budget_exceeded")
    except Exception as err:
        return _build_empty_knowledge_areas_payload(_safe_error(err))


def _reset_fast_stats_cache_for_tests() -> None:
    global _DIAGNOSTIC_WARMER_NEXT_INDEX
    global \
        _FAST_HEALTH_CACHE, \
        _FAST_STATS_CACHE, \
        _FAST_STATS_REFRESH_ERROR, \
        _FAST_STATS_REFRESH_FUTURE, \
        _KNOWLEDGE_AREAS_CACHE
    global _FAST_HEALTH_REFRESH_FUTURE, _FAST_HEALTH_REFRESH_ERROR
    global _KNOWLEDGE_AREAS_REFRESH_FUTURE, _KNOWLEDGE_AREAS_REFRESH_ERROR
    with _FAST_STATS_CACHE_LOCK:
        _FAST_STATS_CACHE = None
    with _FAST_STATS_REFRESH_LOCK:
        if _FAST_STATS_REFRESH_FUTURE is not None and not _FAST_STATS_REFRESH_FUTURE.done():
            _FAST_STATS_REFRESH_FUTURE.cancel()
        _FAST_STATS_REFRESH_FUTURE = None
        _FAST_STATS_REFRESH_ERROR = None
        _FAST_STATS_OBSERVABILITY.update(
            {
                "refresh_success_count": 0,
                "refresh_failure_count": 0,
                "stale_served_count": 0,
                "slot_acquire_timeout_count": 0,
                "last_refresh_duration_ms": None,
                "last_refresh_error": None,
                "last_success_monotonic": None,
            }
        )
    with _FAST_HEALTH_CACHE_LOCK:
        _FAST_HEALTH_CACHE = None
    with _FAST_HEALTH_REFRESH_LOCK:
        if _FAST_HEALTH_REFRESH_FUTURE is not None and not _FAST_HEALTH_REFRESH_FUTURE.done():
            _FAST_HEALTH_REFRESH_FUTURE.cancel()
        _FAST_HEALTH_REFRESH_FUTURE = None
        _FAST_HEALTH_REFRESH_ERROR = None
        _FAST_HEALTH_OBSERVABILITY.update(
            {
                "refresh_success_count": 0,
                "refresh_failure_count": 0,
                "stale_served_count": 0,
                "slot_acquire_timeout_count": 0,
                "last_refresh_duration_ms": None,
                "last_refresh_error": None,
                "last_success_monotonic": None,
            }
        )
    with _KNOWLEDGE_AREAS_CACHE_LOCK:
        _KNOWLEDGE_AREAS_CACHE = None
    with _KNOWLEDGE_AREAS_REFRESH_LOCK:
        if _KNOWLEDGE_AREAS_REFRESH_FUTURE is not None and not _KNOWLEDGE_AREAS_REFRESH_FUTURE.done():
            _KNOWLEDGE_AREAS_REFRESH_FUTURE.cancel()
        _KNOWLEDGE_AREAS_REFRESH_FUTURE = None
        _KNOWLEDGE_AREAS_REFRESH_ERROR = None
        _FAST_KNOWLEDGE_AREAS_OBSERVABILITY.update(
            {
                "refresh_success_count": 0,
                "refresh_failure_count": 0,
                "stale_served_count": 0,
                "slot_acquire_timeout_count": 0,
                "last_refresh_duration_ms": None,
                "last_refresh_error": None,
                "last_success_monotonic": None,
            }
        )
    with _DIAGNOSTIC_WARMER_LOCK:
        _DIAGNOSTIC_WARMER_NEXT_INDEX = 0
        _DIAGNOSTIC_WARMER_OBSERVABILITY.update(
            {
                "enabled": _DIAGNOSTIC_WARMER_ENABLED,
                "mode": _DIAGNOSTIC_WARMER_MODE,
                "alive": False,
                "tick_count": 0,
                "warm_submitted_count": 0,
                "watchdog_breach_count": 0,
                "last_tick_monotonic": None,
                "last_breach_lane": None,
                "last_submitted_lane": None,
                "interval_s": None,
                "invalid_config": _DIAGNOSTIC_WARMER_INVALID_CONFIG,
            }
        )


@app.get("/learning_metrics")
def learning_metrics():
    """Learning performance dashboard — monitors extraction pipeline health.

    Key metrics for routine monitoring:
    - type_distribution: L3+ vs L1 ratio (target: >20% L3+)
    - daily_throughput: concepts created per day (last 7 days)
    - budget_utilization: daily budget usage pattern
    - pipeline_health: rejection rates, dedup rates
    """
    from app.storage import _db

    # B7 fix: Use _db() context manager instead of raw sqlite3.connect().
    # The old code opened a second connection bypassing _get_connection(),
    # which meant: (a) no _db_lock serialization, (b) default synchronous=FULL
    # instead of matching the app, (c) a concurrent reader outside the
    # managed connection — all amplifying WAL corruption risk.
    with _db() as conn:
        c = conn.cursor()

        # Type distribution (all time)
        c.execute("SELECT concept_type, COUNT(*) FROM concepts GROUP BY concept_type ORDER BY COUNT(*) DESC")
        type_dist = {row[0] or "untyped": row[1] for row in c.fetchall()}
        total = sum(type_dist.values())
        abstract_types = {"principle", "method", "heuristic", "cognitive_strategy", "system_model"}
        l3_count = sum(v for k, v in type_dist.items() if k in abstract_types)

        # Daily throughput (last 7 days)
        c.execute("""SELECT DATE(created_at) as day, COUNT(*),
                     SUM(CASE WHEN concept_type IN ('principle','method','heuristic','cognitive_strategy','system_model') THEN 1 ELSE 0 END) as l3_count
                     FROM concepts WHERE created_at > datetime('now', '-7 days')
                     GROUP BY day ORDER BY day""")
        daily = [{"date": r[0], "total": r[1], "l3_plus": r[2]} for r in c.fetchall()]

        # Recent 24h type breakdown
        c.execute("""SELECT concept_type, COUNT(*) FROM concepts
                     WHERE created_at > datetime('now', '-1 day')
                     GROUP BY concept_type ORDER BY COUNT(*) DESC""")
        last_24h = {row[0] or "untyped": row[1] for row in c.fetchall()}
        total_24h = sum(last_24h.values())
        l3_24h = sum(v for k, v in last_24h.items() if k in abstract_types)

        # Session manager budget info
        budget_remaining = session_manager._check_daily_budget()
        budget_total = session_manager.DAILY_BUDGET
        try:
            from app.storage.turn_ingestion import get_ingestion_capture_summary

            ingestion_capture = get_ingestion_capture_summary(conn)
            ingestion_capture_error = None
        except Exception as e:
            ingestion_capture = None
            ingestion_capture_error = str(e)

    # MONITOR-001: Derived observability signals from MetricsCollector
    import json
    from datetime import timedelta

    from app.api.pricing import conversation_meter
    from app.ops.metrics import metrics as _lm_metrics

    _1h_ago = (_utc_now() - timedelta(hours=1)).isoformat()
    _24h_ago = (_utc_now() - timedelta(hours=24)).isoformat()

    # Learning velocity (concepts created per minute, last hour)
    velocity = _lm_metrics.query_rate("learn_pipeline_created", window_minutes=60)

    # Dedup efficiency (what % of pipeline input becomes new concepts?)
    _created_1h = _lm_metrics.query_count("learn_pipeline_created", since=_1h_ago)
    _skipped_1h = _lm_metrics.query_count("learn_pipeline_skipped", since=_1h_ago)
    _evolved_1h = _lm_metrics.query_count("learn_pipeline_evolved", since=_1h_ago)
    _total_1h = _created_1h + _skipped_1h + _evolved_1h
    dedup_efficiency = round(_created_1h / _total_1h * 100, 1) if _total_1h else 0

    # KA growth distribution (from learn_concept_created labels)
    _ka_rows = _lm_metrics.query("learn_concept_created", since=_1h_ago, limit=5000)
    ka_dist: dict[str, int] = {}
    for row in _ka_rows:
        _labels_raw = row.get("labels", "{}")
        _labels = json.loads(_labels_raw) if isinstance(_labels_raw, str) else (_labels_raw or {})
        ka = _labels.get("ka", "unknown")
        ka_dist[ka] = ka_dist.get(ka, 0) + int(row.get("value", 0))
    ka_dist = dict(sorted(ka_dist.items(), key=lambda x: -x[1]))

    # Budget zone info (from ConversationMeter)
    meter_status = conversation_meter.get_status()

    # Zone transitions (last 24h)
    _transitions = _lm_metrics.query("budget_zone_transition", since=_24h_ago, limit=100)

    # Pipeline health (latency)
    pipeline_latency = _lm_metrics.query_aggregate("learn_pipeline_latency_ms", since=_1h_ago)
    budget_trend = _lm_metrics.query("learn_budget_remaining", since=_1h_ago, limit=100)

    # --- TIER2-DAY1: concept_type correction observability ---
    from app.core.models import CONCEPT_TYPES_SET

    _ct_correction_1h = _lm_metrics.query_count("concept_type_correction", since=_1h_ago)
    _ct_correction_24h = _lm_metrics.query_count("concept_type_correction", since=_24h_ago)
    # Correction breakdown by from→to labels
    _ct_correction_rows = _lm_metrics.query("concept_type_correction", since=_24h_ago, limit=5000)
    _ct_corrections_by_pair: dict[str, int] = {}
    for _ctr in _ct_correction_rows:
        _ctr_labels_raw = _ctr.get("labels", "{}")
        _ctr_labels = json.loads(_ctr_labels_raw) if isinstance(_ctr_labels_raw, str) else (_ctr_labels_raw or {})
        _pair_key = f"{_ctr_labels.get('from', '?')}→{_ctr_labels.get('to', '?')}"
        _ct_corrections_by_pair[_pair_key] = _ct_corrections_by_pair.get(_pair_key, 0) + 1
    _leakage_count = sum(v for k, v in type_dist.items() if k not in CONCEPT_TYPES_SET and k != "untyped")

    return {
        "type_distribution": {
            "all_time": type_dist,
            "total": total,
            "l3_plus_count": l3_count,
            "l3_plus_pct": round(l3_count / total * 100, 1) if total else 0,
            "target_pct": 20.0,
            "status": "healthy" if l3_count / total * 100 >= 20 else "below_target",
        },
        # TIER2-DAY1: concept_type correction rates and leakage detection
        "concept_type_health": {
            "correction_rate_1h": _ct_correction_1h,
            "correction_rate_24h": _ct_correction_24h,
            "corrections_by_pair_24h": _ct_corrections_by_pair,
            "leakage_count": _leakage_count,
            "leakage_status": "clean" if _leakage_count == 0 else f"ALERT: {_leakage_count} non-canonical types",
        },
        "last_24h": {
            "types": last_24h,
            "total": total_24h,
            "l3_plus_count": l3_24h,
            "l3_plus_pct": round(l3_24h / total_24h * 100, 1) if total_24h else 0,
        },
        "daily_throughput": daily,
        "budget": {
            "daily_limit": budget_total,
            "remaining_today": budget_remaining,
            "used_today": budget_total - budget_remaining,
            "utilization_pct": round((budget_total - budget_remaining) / budget_total * 100, 1),
        },
        # --- MONITOR-001: New observability signals ---
        "velocity": {
            "concepts_per_min": velocity,
            "dedup_efficiency_pct": dedup_efficiency,
            "created_1h": _created_1h,
            "evolved_1h": _evolved_1h,
            "skipped_1h": _skipped_1h,
        },
        "ka_growth": {
            "last_hour": ka_dist,
            "top_ka": next(iter(ka_dist), None),
            "ka_count": len(ka_dist),
        },
        "budget_health": {
            "zone": meter_status["budget_zone"],
            "tier": meter_status["tier"],
            "capped_at": meter_status.get("capped_at"),
            "zone_transitions_24h": len(_transitions),
            "transitions": _transitions[:10],
            "budget_trend": [{"time": r["timestamp"], "remaining": r["value"]} for r in budget_trend[-20:]],
        },
        "pipeline_health": {
            "latency_ms": pipeline_latency,
            "status": "healthy" if pipeline_latency.get("p95", 0) < 5000 else "degraded",
        },
        "ingestion_capture": ingestion_capture,
        "ingestion_capture_error": ingestion_capture_error,
    }


def _parse_search_filter_time(value: str | None, *, end_of_day: bool = False, strict: bool = True):
    if not value:
        return None
    from datetime import UTC, datetime
    from datetime import time as _time

    text = str(value).strip()
    try:
        if len(text) == 10 and text[4] == "-" and text[7] == "-":
            parsed_date = datetime.fromisoformat(text).date()
            parsed = datetime.combine(parsed_date, _time.max if end_of_day else _time.min)
        else:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        if not strict:
            return None
        raise HTTPException(status_code=400, detail=f"Invalid temporal filter value: {value}") from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed


def _concept_temporal_value(concept, field_name: str) -> str | None:
    value = getattr(concept, field_name, None) if concept is not None else None
    if value in (None, ""):
        return None
    return str(value)


def _result_payload_with_temporal(result: SearchResult, concept=None) -> dict:
    payload = result.model_dump() if hasattr(result, "model_dump") else dict(result)
    for field_name in ("created_at", "valid_from", "original_date", "content_updated_at"):
        if payload.get(field_name) in (None, ""):
            payload[field_name] = _concept_temporal_value(concept, field_name)
    return payload


def _apply_search_temporal_filters(
    results: list[SearchResult], query: SearchQuery
) -> tuple[list[SearchResult], list[dict], dict]:
    has_filter = bool(query.since or query.until)
    metadata = {
        "applied": has_filter,
        "time_field": query.time_field,
        "since": query.since,
        "until": query.until,
        "filter_scope": "none",
        "candidate_count": len(results),
        "filtered_count": len(results),
        "requested_max_results": query.max_results,
        "invalid_temporal_count": 0,
    }
    if not has_filter:
        payloads = [
            _result_payload_with_temporal(result, load_concept(result.concept_id, track_access=False))
            for result in results
        ]
        return results, payloads, metadata

    since_dt = _parse_search_filter_time(query.since)
    until_dt = _parse_search_filter_time(query.until, end_of_day=True)
    filtered: list[SearchResult] = []
    payloads: list[dict] = []
    invalid_temporal_count = 0
    for result in results:
        concept = load_concept(result.concept_id, track_access=False)
        temporal_value = _concept_temporal_value(concept, query.time_field)
        if not temporal_value:
            continue
        value_dt = _parse_search_filter_time(temporal_value, strict=False)
        if value_dt is None:
            invalid_temporal_count += 1
            continue
        if since_dt and value_dt < since_dt:
            continue
        if until_dt and value_dt > until_dt:
            continue
        filtered.append(result)
        payloads.append(_result_payload_with_temporal(result, concept))

    metadata.update(
        {
            "filter_scope": "post_retrieval_overfetch",
            "filtered_count": len(filtered),
            "invalid_temporal_count": invalid_temporal_count,
            "filter_warning": (
                "Temporal filtering is applied to an overfetched retrieval candidate set, "
                "not an exhaustive database date scan."
            ),
        }
    )
    return filtered[: query.max_results], payloads[: query.max_results], metadata


@app.post("/pith_search")
def pith_search(query: SearchQuery):
    """Search for concepts using RAG retrieval."""
    try:
        requested_max_results = query.max_results
        search_query = query
        if query.since or query.until:
            candidate_limit = max(int(requested_max_results or 5) * 20, 50)
            search_query = query.model_copy(update={"max_results": candidate_limit})
        results = retrieval_engine.search(search_query)

        # MATURITY-001: Filter quarantined/discarded from external API results
        results = [r for r in results if (r.maturity or "ESTABLISHED") not in _BLOCKED_MATURITIES]
        query_for_filters = query.model_copy(update={"max_results": requested_max_results})
        results, result_payloads, filter_metadata = _apply_search_temporal_filters(results, query_for_filters)
        # C2: Enrich with ambient_context from top result's associations
        ambient = []
        if results:
            top_id = results[0].concept_id
            result_ids = {r.concept_id for r in results}
            ambient = select_ambient_concepts(top_id, query=query.query, exclude_ids=result_ids)

        return {
            "results": result_payloads,
            "ambient_context": {"related": ambient} if ambient else {},
            "filters": filter_metadata,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.get("/pith_get_concept")
def pith_get_concept(concept_id: str, version: str = "latest"):
    """Get concept by ID and version."""
    concept = load_concept(concept_id, version)
    if not concept:
        raise HTTPException(status_code=404, detail=f"Concept {concept_id} not found")

    if version == "all":
        return {"concepts": concept}  # Returns list

    # C2: Enrich with ambient_context from association neighbors
    ambient = select_ambient_concepts(concept_id, query=concept.summary)

    result = concept.model_dump() if hasattr(concept, "model_dump") else concept
    if ambient:
        result["ambient_context"] = {"related": ambient}
    return result


@app.post("/pith_propose_concept", dependencies=[Depends(verify_api_key)])
def pith_propose_concept(proposal: ConceptProposal):
    """Propose new concept."""
    # PERF-FORT-1: Semaphore prevents threadpool starvation under concurrent load
    acquired = _HEAVY_ENDPOINT_SEMAPHORE.acquire(timeout=HEAVY_ENDPOINT_TIMEOUT_S)
    if not acquired:
        raise HTTPException(
            status_code=503,
            detail="Server under heavy load — try again in a few seconds",
            headers={"Retry-After": "3"},
        )
    try:
        return _pith_propose_concept_inner(proposal)
    finally:
        _HEAVY_ENDPOINT_SEMAPHORE.release()


def _pith_propose_concept_inner(proposal: ConceptProposal):
    """Inner logic for propose_concept — separated for semaphore wrapping."""
    # Validate proposal
    valid, message = validate_proposal(proposal)
    if not valid:
        raise HTTPException(status_code=400, detail=message)

    # §5.8.4 H18: Write-scoped governance context for event tracing
    from app.governance.governance_context import write_governance_context

    with write_governance_context("propose_concept") as gov_ctx:
        return _pith_propose_concept_with_governance(proposal, gov_ctx)


def _pith_propose_concept_with_governance(proposal: ConceptProposal, _gov_ctx):
    """One proposal attempt inside the caller-owned governance context."""
    # Memory Integrity §5.1.5: Write-time contradiction check
    contra_result = None
    try:
        from app.cognitive.contradiction import detect_write_contradiction

        contra_result = detect_write_contradiction(
            new_summary=proposal.summary,
            new_knowledge_area=getattr(proposal, "knowledge_area", "general") or "general",
            concept_id=proposal.concept_id,
        )
        # Log ingestion validation event through GovernanceContext
        if _gov_ctx:
            _gov_ctx.log_ingestion_validation(
                concept_id=proposal.concept_id,
                validation_result=contra_result.action,
                reason=contra_result.reason or "",
                contradiction_score=getattr(contra_result, "contradiction_score", 0.0),
                tier_used=getattr(contra_result, "tier_used", 0),
            )
        if contra_result.action == "HARD_REJECT":
            from app.governance.policy_engine import PolicyViolation, get_policy_engine

            try:
                engine = get_policy_engine()
                engine._log_violation(
                    PolicyViolation(
                        rule_id="write_contradiction_hard_reject",
                        severity="BLOCK",
                        concept_id=proposal.concept_id,
                        detail=contra_result.reason,
                        caller_context="pith_propose_concept",
                    )
                )
            except Exception:
                pass
            raise HTTPException(
                status_code=409, detail=f"Concept contradicts existing knowledge: {contra_result.reason}"
            )
    except HTTPException:
        raise
    except Exception as e:
        logger.warning(f"propose_concept: contradiction check failed (non-fatal): {e}")

    evolution_selected = False
    # Memory Integrity §Gap 2 / A4-H1: Dedup at ingestion
    # INGEST-005: Use embedding dedup (matches session_learn path) with config thresholds
    try:
        from app.core.config import (
            EMBEDDING_EVOLVE_THRESHOLD,
            EMBEDDING_SKIP_THRESHOLD,
            FEATURE_FLAGS,
        )

        if FEATURE_FLAGS.get("DEDUP_AT_INGESTION_ENABLED", False):
            _use_embedding = FEATURE_FLAGS.get("EMBEDDING_DEDUP_ENABLED", False)
            if _use_embedding:
                dedup_results = retrieval_engine.search_for_dedup_embedding(proposal.summary, top_k=3)
                _skip_threshold = EMBEDDING_SKIP_THRESHOLD
                _evolve_threshold = EMBEDDING_EVOLVE_THRESHOLD
            else:
                dedup_results = retrieval_engine.search_for_dedup_tfidf(proposal.summary, top_k=3)
                _skip_threshold = 0.85
                _evolve_threshold = 0.50

            top_cosine = dedup_results[0]["cosine_score"] if dedup_results else 0.0
            top_match = dedup_results[0] if dedup_results else None

            # INGEST-007: Cross-KA merge guard
            from app.core.config import CROSS_KA_EVOLVE_THRESHOLD, ka_groups_match

            _incoming_ka = getattr(proposal, "knowledge_area", "general") or "general"
            _match_ka = top_match.get("knowledge_area", "") if top_match else ""
            _ka_match = ka_groups_match(_incoming_ka, _match_ka)
            _effective_evolve = _evolve_threshold if _ka_match else CROSS_KA_EVOLVE_THRESHOLD

            # Classify dedup zone (DATA-055 parity)
            if top_cosine >= _skip_threshold:
                _dedup_zone = "SKIP"
            elif top_cosine >= _effective_evolve and top_match:
                _dedup_zone = "EVOLVE"
            else:
                _dedup_zone = "CREATE"

            # INGEST-007: Log KA guard decision
            if not _ka_match and top_cosine >= _evolve_threshold:
                logger.info(
                    f"INGEST-007: Cross-KA guard activated — "
                    f"incoming={_incoming_ka} match={_match_ka} "
                    f"cosine={top_cosine:.4f} effective_thresh={_effective_evolve:.2f} "
                    f"zone={_dedup_zone}"
                )

            # INGEST-005: Structured dedup log (matches session_learn DATA-055 format)
            _dedup_method = "embedding" if _use_embedding else "tfidf"
            _match_id = top_match["concept_id"] if top_match else None
            logger.info(
                f"DEDUP_DECISION: zone={_dedup_zone} cosine={top_cosine:.4f} "
                f"match={_match_id} method={_dedup_method} "
                f"skip_thresh={_skip_threshold} evolve_thresh={_evolve_threshold:.2f} "
                f"caller=propose_concept "
                f"summary_hash={hashlib.sha256(proposal.summary.encode()).hexdigest()[:12]}"
            )

            if _dedup_zone == "SKIP":
                return {
                    "status": "skipped_duplicate",
                    "existing_concept_id": top_match["concept_id"],
                    "cosine_score": top_cosine,
                    "message": f"Near-duplicate of {top_match['concept_id']} (cosine={top_cosine:.3f})",
                }
            elif _dedup_zone == "EVOLVE":
                evolution_selected = True
                try:
                    from app.cognitive.learning import evolve_concept
                    from app.core.models import ConceptEvolution

                    evo = ConceptEvolution(
                        concept_id=top_match["concept_id"],
                        new_summary=proposal.summary,
                        new_evidence=getattr(proposal, "evidence", None),
                    )
                    evolved = evolve_concept(evo)
                    if evolved:
                        retrieval_engine.add_concept(evolved.id)
                        return {
                            "status": "merged_into_existing",
                            "existing_concept_id": top_match["concept_id"],
                            "cosine_score": top_cosine,
                            "evolved_version": evolved.version,
                            "message": f"Merged into {top_match['concept_id']} (cosine={top_cosine:.3f})",
                        }
                    raise HTTPException(status_code=400, detail="Evolution not warranted or concept not found")
                except HTTPException:
                    raise
                except Exception as e:
                    logger.exception("propose_concept: selected evolution failed; creation suppressed")
                    raise HTTPException(status_code=500, detail="Concept evolution failed; outcome may be partial") from e
    except Exception as e:
        if evolution_selected:
            raise
        logger.warning(f"propose_concept: dedup check failed (non-fatal): {e}")

    # Create concept
    try:
        concept = create_concept(proposal)
        # If QUARANTINE, override maturity
        try:
            if contra_result.action == "QUARANTINE":
                from app.storage import _db

                with _db() as conn:
                    conn.execute(
                        "UPDATE concepts SET maturity = 'QUARANTINED', "
                        "data = json_set(data, '$.maturity', 'QUARANTINED') "
                        "WHERE id = ?",
                        (concept.id,),
                    )
                logger.info(
                    f"propose_concept: quarantined {concept.id} due to contradiction with {contra_result.contradicting_concept_id}"
                )
        except Exception as e:
            logger.warning(f"propose_concept: quarantine update failed: {e}")

        # FED-005: Emit federation event for propose_concept
        try:
            session_manager._emit_federation_event(
                event_type="concept_proposed",
                concept_id=concept.id,
                payload={
                    "summary": concept.summary,
                    "confidence": concept.confidence,
                    "knowledge_area": getattr(concept, "knowledge_area", "general"),
                    "concept_type": getattr(concept, "concept_type", "observation"),
                    "original_confidence": concept.confidence,
                },
                model_id="unknown",
            )
        except Exception as e:
            logger.debug(f"propose_concept: federation event failed (non-fatal): {e}")

        # Update index
        retrieval_engine.add_concept(concept.id)

        # Auto-associate with existing concepts
        from app.cognitive.association import auto_associate_single
        from app.core.models import AutoAssociateSingleRequest

        assoc_request = AutoAssociateSingleRequest(threshold=0.12, max_edges=3)
        try:
            assoc_result = auto_associate_single(concept.id, assoc_request)
            assoc_count = assoc_result.edges_created
        except Exception as e:
            logger.warning(f"propose_concept: auto_associate failed for {concept.id}: {e}")
            assoc_count = 0

        # C3: Implicit learning event + consume budget
        session_manager._consume_budget()
        session_manager.register_implicit_learning_event(
            event_type="concept_proposed",
            concept_id=concept.id,
            summary=concept.summary,
        )

        # C2: Enrich with similar existing concepts (dedup value)
        ambient = select_ambient_concepts(concept.id, query=concept.summary)

        # P1-1: Handle always_activate flag if provided in request body
        aa_skipped = False
        raw_body = proposal.model_dump()
        if raw_body.get("always_activate"):
            from app.core.config import MAX_ALWAYS_ACTIVATE
            from app.storage import load_always_activate_concepts, set_always_activate

            current_aa = load_always_activate_concepts()
            if len(current_aa) >= MAX_ALWAYS_ACTIVATE:
                logger.warning(
                    f"propose_concept: always_activate skipped for {concept.id} — "
                    f"cap reached ({len(current_aa)}/{MAX_ALWAYS_ACTIVATE})"
                )
                aa_skipped = True
            else:
                set_always_activate(concept.id, True)

        response = {
            "status": "created",
            "concept_id": concept.id,
            "version": concept.version,
            "message": "Concept created successfully",
            "associations_created": assoc_count,
        }
        if aa_skipped:
            response["always_activate_warning"] = (
                f"always_activate flag not set — cap reached "
                f"({MAX_ALWAYS_ACTIVATE}/{MAX_ALWAYS_ACTIVATE}). Unset one first."
            )
        if ambient:
            response["ambient_context"] = {"related": ambient}
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.post("/pith_evolve_concept", dependencies=[Depends(verify_api_key)])
def pith_evolve_concept_endpoint(evolution: ConceptEvolution):
    """Evolve existing concept."""
    # §5.8.4 H18: Write-scoped governance context
    from app.governance.governance_context import write_governance_context

    with write_governance_context("evolve_concept"):
        return _pith_evolve_concept_inner(evolution)


def _pith_evolve_concept_inner(evolution: ConceptEvolution):
    """Evolve within a governance context that closes on every outcome."""
    concept = evolve_concept(evolution)

    if not concept:
        raise HTTPException(status_code=400, detail="Evolution not warranted or concept not found")

    # Update index
    retrieval_engine.add_concept(concept.id)

    # Memory Integrity A4-H1: Post-evolution dedup check
    dedup_warning = None
    try:
        from app.core.config import FEATURE_FLAGS

        if FEATURE_FLAGS.get("DEDUP_AT_INGESTION_ENABLED", False):
            dedup_results = retrieval_engine.search_for_dedup_tfidf(concept.summary, top_k=3)
            for match in dedup_results:
                if match["concept_id"] != concept.id and match["concept_id"] != evolution.concept_id:
                    if match["cosine_score"] >= 0.85:
                        dedup_warning = {
                            "duplicate_of": match["concept_id"],
                            "cosine_score": match["cosine_score"],
                            "message": f"Post-evolution: now duplicates {match['concept_id']}",
                        }
                        logger.warning(
                            f"evolve_concept: post-evolution dedup alert — "
                            f"{concept.id} now duplicates {match['concept_id']} "
                            f"(cosine={match['cosine_score']:.3f})"
                        )
                        break
    except Exception as e:
        logger.warning(f"evolve_concept: post-evolution dedup check failed: {e}")

    # C3: Implicit learning event
    session_manager.register_implicit_learning_event(
        event_type="concept_evolved",
        concept_id=concept.id,
        summary=concept.summary,
    )

    # P1-1: Handle always_activate flag if explicitly set
    if evolution.always_activate is not None:
        if evolution.always_activate:
            from app.core.config import MAX_ALWAYS_ACTIVATE
            from app.storage import load_always_activate_concepts, set_always_activate

            current_aa = load_always_activate_concepts()
            if len(current_aa) >= MAX_ALWAYS_ACTIVATE:
                logger.warning(
                    f"evolve_concept: always_activate skipped for {concept.id} — "
                    f"cap reached ({len(current_aa)}/{MAX_ALWAYS_ACTIVATE})"
                )
            else:
                set_always_activate(concept.id, True)
        else:
            from app.storage import set_always_activate

            set_always_activate(concept.id, False)

    # C2: Enrich with affected concepts via associations
    ambient = select_ambient_concepts(concept.id, query=concept.summary)

    response = {
        "status": "evolved",
        "concept_id": concept.id,
        "version": concept.version,
        "previous_version": concept.supersedes,
        "message": "Concept evolved successfully",
    }
    if ambient:
        response["ambient_context"] = {"related": ambient}
    if dedup_warning:
        response["dedup_warning"] = dedup_warning
    return response


class AlwaysActivateRequest(PydanticBaseModel):
    """P1-1: Request to set/unset always-activate flag."""

    concept_id: str
    value: bool = True


@app.post("/pith_set_always_activate", dependencies=[Depends(verify_api_key)])
def pith_set_always_activate(request: AlwaysActivateRequest):
    """Set or unset always_activate flag on a concept. P1-1."""
    from app.core.config import MAX_ALWAYS_ACTIVATE
    from app.storage import load_always_activate_concepts, set_always_activate

    # Governance: cap at MAX_ALWAYS_ACTIVATE concepts
    if request.value:
        current = load_always_activate_concepts()
        if len(current) >= MAX_ALWAYS_ACTIVATE:
            raise HTTPException(
                status_code=400,
                detail=f"Maximum {MAX_ALWAYS_ACTIVATE} always-activate concepts allowed. Currently {len(current)} flagged. Unset one first.",
            )
    updated = set_always_activate(request.concept_id, request.value)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Concept {request.concept_id} not found")
    return {"status": "updated", "concept_id": request.concept_id, "always_activate": request.value}


@app.get("/pith_list_always_activate", dependencies=[Depends(verify_api_key)])
def pith_list_always_activate():
    """List all concepts with always_activate flag. P1-1."""
    from app.core.config import MAX_ALWAYS_ACTIVATE
    from app.storage import load_always_activate_concepts

    concepts = load_always_activate_concepts()
    return {"count": len(concepts), "max": MAX_ALWAYS_ACTIVATE, "concepts": concepts}


# =============================================================================
# Quarantine Management — §5.2.5 Gap 5 (Memory Integrity Spec v1.2)
# =============================================================================


@app.get("/pith/quarantine", dependencies=[Depends(verify_api_key)])
def list_quarantined(limit: int = 50):
    """List concepts with maturity='QUARANTINED'.

    Returns concept_id, summary, confidence, quarantine_entered, evidence count.
    Feature-gated by QUARANTINE_ENDPOINTS_ENABLED.
    """
    from app.core.config import FEATURE_FLAGS

    if not FEATURE_FLAGS.get("QUARANTINE_ENDPOINTS_ENABLED", False):
        raise HTTPException(status_code=503, detail="Quarantine endpoints not enabled")

    from app.storage import get_db_connection

    conn = get_db_connection()
    rows = conn.execute(
        """
        SELECT id, summary, confidence, maturity, data
        FROM concepts
        WHERE maturity = 'QUARANTINED'
        ORDER BY updated_at DESC
        LIMIT ?
    """,
        (min(limit, 200),),
    ).fetchall()

    results = []
    for row in rows:
        import json as _json

        data = _json.loads(row["data"]) if row["data"] else {}
        results.append(
            {
                "concept_id": row["id"],
                "summary": row["summary"],
                "confidence": row["confidence"],
                "quarantine_entered": data.get("quarantine_entered"),
                "evidence_count": len(data.get("evidence", [])),
                "knowledge_area": data.get("knowledge_area", ""),
            }
        )
    return {"count": len(results), "quarantined": results}


class QuarantineActionRequest(PydanticBaseModel):
    """Request body for quarantine promote/discard actions."""

    reason: str = ""


@app.post("/pith/quarantine/{concept_id}/promote", dependencies=[Depends(verify_api_key)])
def promote_from_quarantine(concept_id: str, request: QuarantineActionRequest = QuarantineActionRequest()):
    """Promote a quarantined concept to PROVISIONAL.

    Updates maturity, maturity_promoted_at, maturity_promotion_evidence.
    Logs to policy_violations for audit trail.
    """
    from app.core.config import FEATURE_FLAGS

    if not FEATURE_FLAGS.get("QUARANTINE_ENDPOINTS_ENABLED", False):
        raise HTTPException(status_code=503, detail="Quarantine endpoints not enabled")

    concept = load_concept(concept_id, track_access=False)
    if not concept:
        raise HTTPException(status_code=404, detail=f"Concept {concept_id} not found")
    if concept.maturity != "QUARANTINED":
        raise HTTPException(status_code=409, detail=f"Concept {concept_id} is {concept.maturity}, not QUARANTINED")

    now = _utc_now_iso()
    concept.maturity = "PROVISIONAL"
    concept.maturity_promoted_at = now
    concept.maturity_promotion_evidence = request.reason or "manual_promotion"

    save_concept(concept)

    # Audit log
    from app.governance.policy_engine import log_policy_event

    log_policy_event(
        rule_id="quarantine_promote",
        severity="LOG",
        concept_id=concept_id,
        detail=f"Promoted from QUARANTINED to PROVISIONAL: {request.reason}",
        caller_context="quarantine_endpoint",
    )

    return {
        "status": "promoted",
        "concept_id": concept_id,
        "new_maturity": "PROVISIONAL",
        "promoted_at": now,
    }


@app.post("/pith/quarantine/{concept_id}/discard", dependencies=[Depends(verify_api_key)])
def discard_quarantined(concept_id: str, request: QuarantineActionRequest = QuarantineActionRequest()):
    """Discard a quarantined concept (set maturity to DISCARDED).

    Version history preserved in concept_versions for forensics.
    Logs to policy_violations for audit trail.
    """
    from app.core.config import FEATURE_FLAGS

    if not FEATURE_FLAGS.get("QUARANTINE_ENDPOINTS_ENABLED", False):
        raise HTTPException(status_code=503, detail="Quarantine endpoints not enabled")

    concept = load_concept(concept_id, track_access=False)
    if not concept:
        raise HTTPException(status_code=404, detail=f"Concept {concept_id} not found")
    if concept.maturity != "QUARANTINED":
        raise HTTPException(status_code=409, detail=f"Concept {concept_id} is {concept.maturity}, not QUARANTINED")

    concept.maturity = "DISCARDED"
    save_concept(concept)

    # Audit log
    from app.governance.policy_engine import log_policy_event

    log_policy_event(
        rule_id="quarantine_discard",
        severity="LOG",
        concept_id=concept_id,
        detail=f"Discarded from quarantine: {request.reason}",
        caller_context="quarantine_endpoint",
    )

    return {
        "status": "discarded",
        "concept_id": concept_id,
        "new_maturity": "DISCARDED",
    }


# =============================================================================
# Rejection Visibility — §5.2.10 H14 (Memory Integrity Spec v1.2)
# =============================================================================


@app.get("/pith/policy/rejections", dependencies=[Depends(verify_api_key)])
def get_policy_rejections(
    since: str | None = None,
    severity: str | None = None,
    limit: int = 100,
):
    """Get filtered rejection log with rate statistics.

    §5.2.10 H14: Operators need visibility into why concepts were rejected.
    Returns rejections from policy_violations table plus hourly rate stats.
    Feature-gated by REJECTION_VISIBILITY_ENABLED.

    Query params:
        since: ISO datetime filter (e.g. '2026-02-25T00:00:00')
        severity: Filter by severity ('BLOCK', 'WARN')
        limit: Max results (default 100)
    """
    from app.core.config import FEATURE_FLAGS

    if not FEATURE_FLAGS.get("REJECTION_VISIBILITY_ENABLED", False):
        raise HTTPException(
            status_code=503,
            detail="Rejection visibility endpoint not enabled (REJECTION_VISIBILITY_ENABLED=False)",
        )
    from app.governance.policy_engine import get_rejections

    return get_rejections(since=since, severity=severity, limit=limit)


# =============================================================================
# Behavioral Directives — CRUD (DOMAINS_AND_DIRECTIVES_SPEC.md Section 3.6)
# =============================================================================


class DirectiveRequest(PydanticBaseModel):
    """Create or update a behavioral directive."""

    directive_id: str
    category: str
    content: str
    priority: int = 100


@app.post("/directives", dependencies=[Depends(verify_api_key)])
def create_or_update_directive(request: DirectiveRequest):
    """Create or update a directive (upsert by directive_id). S4.8."""
    from app.governance.directives import DirectiveValidationError, save_directive

    try:
        result = save_directive(
            directive_id=request.directive_id,
            category=request.category,
            content=request.content,
            priority=request.priority,
        )
        return result
    except DirectiveValidationError as e:
        raise HTTPException(status_code=400, detail={"error": e.error_code, "message": e.detail})


@app.get("/directives")
def list_directives(category: str | None = None, active: bool | None = None):
    """List all directives with optional filters."""
    from app.governance.directives import load_directives

    all_directives = load_directives(active_only=active if active is not None else True)
    if category:
        all_directives = [d for d in all_directives if d["category"] == category]
    return {"count": len(all_directives), "directives": all_directives}


@app.get("/directive/{directive_id}")
def get_directive_detail(directive_id: str):
    """Get a single directive with version history."""
    from app.governance.directives import get_directive

    result = get_directive(directive_id, include_versions=True)
    if not result:
        raise HTTPException(status_code=404, detail=f"Directive {directive_id} not found")
    return result


@app.delete("/directive/{directive_id}", dependencies=[Depends(verify_api_key)])
def delete_directive_endpoint(directive_id: str):
    """Soft-delete a directive (sets active=false)."""
    from app.governance.directives import delete_directive

    if delete_directive(directive_id):
        return {"status": "deactivated", "directive_id": directive_id}
    raise HTTPException(status_code=404, detail=f"Directive {directive_id} not found")


# =============================================================================
# Wave 4a — pith_salience Tool (§4a.5)
# =============================================================================


class SalienceRequest(PydanticBaseModel):
    concept_id: str | None = None
    mode: str = "get"  # get | set | recompute | bulk_recompute
    salience: float | None = None  # For mode="set"
    reason: str | None = None  # For mode="set"


@app.post("/pith_salience", dependencies=[Depends(verify_api_key)])
def pith_salience(request: SalienceRequest):
    """Get or set concept salience.

    Modes:
    - get: Return current salience + breakdown for concept_id
    - set: Manually set salience (salience_source="user")
    - recompute: Trigger system recomputation for concept_id
    - bulk_recompute: Recompute all concepts (reflection-time only)
    """
    from app.retrieval.salience import recompute_salience

    if request.mode == "get":
        if not request.concept_id:
            raise HTTPException(status_code=400, detail="concept_id required for get mode")
        concept = load_concept(request.concept_id)
        if not concept:
            raise HTTPException(status_code=404, detail=f"Concept {request.concept_id} not found")
        return {
            "concept_id": request.concept_id,
            "salience": concept.salience,
            "salience_source": concept.salience_source,
            "salience_set_at": concept.salience_set_at,
            "salience_reason": concept.salience_reason,
        }

    elif request.mode == "set":
        if not request.concept_id:
            raise HTTPException(status_code=400, detail="concept_id required for set mode")
        if request.salience is None:
            raise HTTPException(status_code=400, detail="salience value required for set mode")
        concept = load_concept(request.concept_id, track_access=False)
        if not concept:
            raise HTTPException(status_code=404, detail=f"Concept {request.concept_id} not found")
        concept.salience = max(0.0, min(1.0, request.salience))
        concept.salience_source = "user"
        concept.salience_set_at = _utc_now_iso()
        concept.salience_reason = request.reason or "Manually set by user"
        from app.storage import save_concept

        save_concept(concept)
        return {
            "status": "updated",
            "concept_id": request.concept_id,
            "salience": concept.salience,
            "salience_source": "user",
        }

    elif request.mode == "recompute":
        if not request.concept_id:
            raise HTTPException(status_code=400, detail="concept_id required for recompute mode")
        result = recompute_salience(concept_id=request.concept_id)
        return result

    elif request.mode == "bulk_recompute":
        result = recompute_salience(concept_id=None)
        return result

    else:
        raise HTTPException(status_code=400, detail=f"Unknown mode: {request.mode}")


@app.post("/pith_link_concepts", dependencies=[Depends(verify_api_key)])
def pith_link_concepts(association: Association):
    """Create association between concepts."""
    # Verify both concepts exist
    concept_a = load_concept(association.concept_a, track_access=False)
    concept_b = load_concept(association.concept_b, track_access=False)

    if not concept_a:
        raise HTTPException(status_code=404, detail=f"Concept {association.concept_a} not found")
    if not concept_b:
        raise HTTPException(status_code=404, detail=f"Concept {association.concept_b} not found")

    # Add association
    add_association(association.concept_a, association.concept_b, association.relation, association.strength)

    # C3: Implicit learning event
    session_manager.register_implicit_learning_event(
        event_type="concepts_linked",
        concept_id=f"{association.concept_a}<->{association.concept_b}",
        summary=f"Linked {association.concept_a} to {association.concept_b} via {association.relation}",
    )

    return {
        "status": "linked",
        "concept_a": association.concept_a,
        "concept_b": association.concept_b,
        "relation": association.relation,
        "message": "Concepts linked successfully",
    }


@app.get("/pith_related_concepts")
def pith_related_concepts(concept_id: str, max_depth: int = 2) -> list[str]:
    """Get concepts related to given concept."""
    concept = load_concept(concept_id)
    if not concept:
        raise HTTPException(status_code=404, detail=f"Concept {concept_id} not found")

    related = get_related_concepts(concept_id, max_depth)
    # MATURITY-001: Filter quarantined/discarded from external results
    filtered = []
    for cid in related:
        c = load_concept(cid, track_access=False)
        if c and getattr(c, "maturity", "ESTABLISHED") not in _BLOCKED_MATURITIES:
            filtered.append(cid)
    return filtered


@app.post("/pith_curiosity", dependencies=[Depends(verify_api_key)])
def pith_curiosity():
    """Generate questions for weak concepts."""
    questions = curiosity_engine.generate_questions()

    # Add to queue
    question_queue.add_questions(questions)

    return {"generated": len(questions), "questions": [q.model_dump() for q in questions]}


@app.get("/pith_questions")
def pith_questions(limit: int = 10) -> list[dict]:
    """Get questions from curiosity queue."""
    questions = question_queue.get_questions(limit)
    return questions


@app.get("/pith_curiosity/experiment_frontier", dependencies=[Depends(verify_api_key)])
def pith_curiosity_experiment_frontier(limit: int = 20, baseline_limit: int = 20) -> dict:
    """Preview read-only Curiosity questions generated from Experiment outputs."""
    bounded_limit = max(1, min(int(limit), 50))
    bounded_baseline_limit = max(0, min(int(baseline_limit), 50))
    payload = curiosity_engine.generate_experiment_frontier_questions(
        limit=bounded_limit,
        baseline_limit=bounded_baseline_limit,
    )
    payload["operator_surface"] = {
        "read_only": True,
        "writes_to_queue": False,
        "writes_to_concepts": False,
        "writes_to_experiments": False,
        "limit": bounded_limit,
        "baseline_limit": bounded_baseline_limit,
    }
    return payload


@app.post("/pith_reindex", dependencies=[Depends(verify_api_key)])
def pith_reindex():
    """Rebuild the entire search index, purging stale entries."""
    try:
        # Compact first to purge ghost entries from deleted concepts
        retrieval_engine.index._compact_matrix()
        # Then rebuild to pick up any missing concepts
        retrieval_engine.build_index()
        indexed_count = len(retrieval_engine.index.concept_ids) - len(retrieval_engine.index.deleted_indices)
        return {
            "status": "success",
            "message": "Index compacted and rebuilt successfully",
            "concepts_indexed": indexed_count,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.get("/pith_integrity")
def pith_integrity(repair: bool = False):
    """Check index integrity and optionally auto-repair drift.

    SYSTEMIC_FIXES_SPEC v1.1 Fix 2: Dedicated integrity endpoint.

    Query params:
        repair: If true, auto-repair any drift found (default: false).
    """
    try:
        integrity = retrieval_engine.verify_index_integrity()
        result = {**integrity}

        if repair and not integrity["is_healthy"]:
            repair_result = retrieval_engine.repair_index_drift(integrity=integrity)
            post_repair_integrity = repair_result.get("post_repair_integrity")
            if post_repair_integrity:
                result = {**post_repair_integrity}
            result["repair"] = repair_result

        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.get("/pith_concept_integrity_probe")
def pith_concept_integrity_probe():
    """Contention-immune read-only Surface-1 concept-integrity probe (EUNOMIA-127).

    Returns freshly-computed concept-integrity sub-checks even while the diagnostic
    slot (_DIAGNOSTIC_ENDPOINT_SEMAPHORE) is starved. Non-raising: any failure path
    returns degraded:true with a reason. Auth posture matches /pith_integrity
    (no verify_api_key dependency).
    """
    return JSONResponse(_run_concept_integrity_probe())


def _association_integrity_snapshot(conn) -> dict[str, Any]:
    hard_orphans = conn.execute(
        """SELECT COUNT(*) FROM associations a
           WHERE NOT EXISTS (SELECT 1 FROM concepts c WHERE c.id = a.source)
              OR NOT EXISTS (SELECT 1 FROM concepts c WHERE c.id = a.target)"""
    ).fetchone()[0]
    missing_source = conn.execute(
        """SELECT COUNT(*) FROM associations a
           WHERE NOT EXISTS (SELECT 1 FROM concepts c WHERE c.id = a.source)"""
    ).fetchone()[0]
    missing_target = conn.execute(
        """SELECT COUNT(*) FROM associations a
           WHERE NOT EXISTS (SELECT 1 FROM concepts c WHERE c.id = a.target)"""
    ).fetchone()[0]
    inactive_existing = conn.execute(
        """SELECT COUNT(*) FROM associations a
           JOIN concepts s ON s.id = a.source
           JOIN concepts t ON t.id = a.target
           WHERE COALESCE(s.status, 'active') != 'active'
              OR COALESCE(t.status, 'active') != 'active'
              OR COALESCE(s.is_current, 1) != 1
              OR COALESCE(t.is_current, 1) != 1"""
    ).fetchone()[0]
    return {
        "hard_orphans": hard_orphans,
        "missing_source": missing_source,
        "missing_target": missing_target,
        "inactive_existing_edges": inactive_existing,
        "total_associations": conn.execute("SELECT COUNT(*) FROM associations").fetchone()[0],
        "is_healthy": hard_orphans == 0,
    }


@app.get("/pith_association_integrity")
def pith_association_integrity(repair: bool = False, dry_run: bool = True):
    """Inspect and optionally repair hard dangling association rows."""
    try:
        with _db() as conn:
            pre = _association_integrity_snapshot(conn)

        result = {**pre, "repair": {"dry_run": dry_run, "attempted": False, "deleted": 0}}
        if repair:
            if dry_run:
                result["repair"] = {
                    "dry_run": True,
                    "attempted": False,
                    "would_delete": pre["hard_orphans"],
                    "preserved_inactive_existing_edges": pre["inactive_existing_edges"],
                }
            else:
                with _db_immediate() as conn:
                    before = _association_integrity_snapshot(conn)
                    cursor = conn.execute(
                        """DELETE FROM associations
                           WHERE NOT EXISTS (SELECT 1 FROM concepts c WHERE c.id = associations.source)
                              OR NOT EXISTS (SELECT 1 FROM concepts c WHERE c.id = associations.target)"""
                    )
                    deleted = cursor.rowcount if cursor.rowcount is not None else 0
                    after = _association_integrity_snapshot(conn)
                if deleted:
                    _invalidate_associations_cache()
                result = {
                    **after,
                    "repair": {
                        "dry_run": False,
                        "attempted": True,
                        "deleted": deleted,
                        "pre_repair": before,
                        "post_repair": after,
                        "preserved_inactive_existing_edges": after["inactive_existing_edges"],
                    },
                }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


def _json_knowledge_area_expr() -> str:
    return "COALESCE(json_extract(data, '$.knowledge_area'), json_extract(data, '$.metadata.knowledge_area'))"


def _ka_admission_state_expr() -> str:
    return "COALESCE(json_extract(data, '$.metadata.ka_admission_state'), '')"


def _unreviewed_general_predicate() -> str:
    return """knowledge_area = 'general'
             AND COALESCE(json_extract(data, '$.metadata.ka_admission_state'), '') NOT IN (
                 'intentional_general',
                 'deterministic_ambiguous'
             )
             AND COALESCE(json_extract(data, '$.metadata.knowledge_area_review'), '') != 'deterministic_ambiguous'"""


_AMBIGUOUS_SECOND_PASS_RULES: dict[str, tuple[str, ...]] = {
    "operations": (
        r"\bdeploy(?:ed|ment)?\b",
        r"\bruntime\b",
        r"\bhealth\b",
        r"\bstaging\b",
        r"\blaunchd\b",
        r"\bheartbeat\b",
        r"\bmaintenance\b",
        r"\brollback\b",
        r"\bcloudflare\b",
        r"\br2\b",
    ),
    "implementation": (
        r"\bimplemented\b",
        r"\bpatch(?:ed)?\b",
        r"\bcommit\b",
        r"\bPR\s*#?\d+\b",
        r"\bbranch\b",
        r"\brebas(?:e|ed|ing)\b",
        r"\bmerg(?:e|ed|ing)\b",
        r"\bcode\b",
        r"\bendpoint\b",
    ),
    "testing": (
        r"\btests?\b",
        r"\btesting\b",
        r"\bverification\b",
        r"\bverified\b",
        r"\bsmoke\b",
        r"\bcanary\b",
    ),
    "debugging": (
        r"\bRCA\b",
        r"\broot cause\b",
        r"\bdiagnostic\b",
        r"\bfailure\b",
        r"\bregression\b",
        r"\btrace\b",
    ),
    "specification": (
        r"\bspec\b",
        r"\bspecification\b",
        r"\bcontract\b",
        r"\bprotocol\b",
    ),
    "review_methodology": (
        r"\bgauntlet\b",
        r"\breview\b",
        r"\baudit\b",
        r"\bchecklist\b",
    ),
    "pith_benchmarks": (
        r"\bLoCoMo\b",
        r"\bLME\b",
        r"\bBEAM\b",
        r"\bMH262\b",
        r"\bbenchmark\b",
        r"\bscore-bearing\b",
    ),
    "documentation": (
        r"\bdocs?\b",
        r"\bpacket\b",
        r"\breport\b",
        r"\bREADME\b",
    ),
}
_AMBIGUOUS_SECOND_PASS_MIN_SCORE = 2
_AMBIGUOUS_SECOND_PASS_MAX_SCAN = 20_000


def _second_pass_ambiguous_ka(summary: str) -> dict[str, Any]:
    """Classify an already-reviewed ambiguous general concept via strict phrase rules."""
    if not summary:
        return {"status": "unresolved", "area": None, "scores": {}, "rule": None, "confidence": None}

    scores: dict[str, int] = {}
    matched: dict[str, list[str]] = {}
    for area, patterns in _AMBIGUOUS_SECOND_PASS_RULES.items():
        hits = [pattern for pattern in patterns if re.search(pattern, summary, flags=re.IGNORECASE)]
        if hits:
            scores[area] = len(hits)
            matched[area] = hits

    eligible = {area: score for area, score in scores.items() if score >= _AMBIGUOUS_SECOND_PASS_MIN_SCORE}
    if len(eligible) == 1:
        area, score = next(iter(eligible.items()))
        return {
            "status": "classified",
            "area": area,
            "scores": scores,
            "rule": ",".join(matched[area]),
            "confidence": min(0.99, 0.88 + (0.02 * min(score, 4))),
        }
    if len(eligible) > 1:
        return {"status": "conflict", "area": None, "scores": scores, "rule": None, "confidence": None}
    return {"status": "unresolved", "area": None, "scores": scores, "rule": None, "confidence": None}


def _ambiguous_review_predicate() -> str:
    return """knowledge_area = 'general'
             AND (
                 COALESCE(json_extract(data, '$.metadata.ka_admission_state'), '') = 'deterministic_ambiguous'
                 OR COALESCE(json_extract(data, '$.metadata.knowledge_area_review'), '') = 'deterministic_ambiguous'
             )"""


def _ambiguous_second_pass_candidates(
    conn, *, batch_limit: int, scan_limit: int | None = None
) -> tuple[list[tuple[str, str, float, str]], list[str], list[str], int]:
    scan_limit = max(batch_limit, min(scan_limit or batch_limit, _AMBIGUOUS_SECOND_PASS_MAX_SCAN))
    rows = conn.execute(
        """SELECT id, summary
           FROM concepts
           WHERE is_current = 1
             AND """
        + _ambiguous_review_predicate()
        + """
           ORDER BY created_at DESC
           LIMIT ?""",
        (scan_limit,),
    ).fetchall()

    classified: list[tuple[str, str, float, str]] = []
    conflicts: list[str] = []
    unresolved: list[str] = []
    for row in rows:
        decision = _second_pass_ambiguous_ka(row["summary"] or "")
        if decision["status"] == "classified":
            classified.append((row["id"], decision["area"], decision["confidence"], decision["rule"]))
        elif decision["status"] == "conflict":
            conflicts.append(row["id"])
        else:
            unresolved.append(row["id"])
    return classified[:batch_limit], conflicts, unresolved, len(classified)


def _safe_general_ka_candidates(conn, *, batch_limit: int) -> tuple[list[tuple[str, str, str]], list[str]]:
    from app.cognitive.taxonomy import classify_knowledge_area

    rows = conn.execute(
        """SELECT id, summary
           FROM concepts
           WHERE is_current = 1
             AND """
        + _unreviewed_general_predicate()
        + """
           ORDER BY created_at DESC
           LIMIT ?""",
        (batch_limit,),
    ).fetchall()
    planned_updates: list[tuple[str, str, str]] = []
    ambiguous_ids: list[str] = []
    for row in rows:
        classified, source, score = classify_knowledge_area(row["summary"] or "", "general", strict=True)
        if (
            classified
            and classified not in ("general", "unclassified")
            and (source == "inferred" or (source == "embedding" and score is not None and score >= 0.80))
        ):
            planned_updates.append((row["id"], classified, source))
        else:
            ambiguous_ids.append(row["id"])
    return planned_updates, ambiguous_ids


def _safe_unclassified_ka_candidates(conn, *, batch_limit: int) -> list[tuple[str, str, str]]:
    from app.cognitive.taxonomy import classify_knowledge_area

    rows = conn.execute(
        """SELECT id, summary
           FROM concepts
           WHERE is_current = 1
             AND knowledge_area = 'unclassified'
             AND COALESCE(json_extract(data, '$.metadata.ka_admission_state'), '') IN (
                 'queued_unclassified',
                 'fallback_failure'
             )
           ORDER BY
             CASE COALESCE(json_extract(data, '$.metadata.ka_admission_state'), '')
                 WHEN 'queued_unclassified' THEN 0 ELSE 1
             END,
             created_at DESC
           LIMIT ?""",
        (batch_limit,),
    ).fetchall()
    planned_updates: list[tuple[str, str, str]] = []
    for row in rows:
        classified, source, score = classify_knowledge_area(row["summary"] or "", "general", strict=True)
        if (
            classified
            and classified not in ("general", "unclassified")
            and (source == "inferred" or (source == "embedding" and score is not None and score >= 0.80))
        ):
            planned_updates.append((row["id"], classified, source))
    return planned_updates


class KAReviewApplyRequest(PydanticBaseModel):
    review_summary_path: str = Field(..., min_length=1)
    review_ledger_path: str = Field(..., min_length=1)
    final_proof_csv_path: str = Field(..., min_length=1)
    expected_review_commit: str = Field(..., min_length=7, max_length=40)
    dry_run: StrictBool = True
    apply: StrictBool = False
    accepted_ids_only: StrictBool = True


_KA_REVIEW_ALLOWED_PREFIXES = (
    "docs/reports/ka_007_manual_review/",
    "docs/reports/ka_007_full_plan_final_proof/",
)


def _ka_review_error(status_code: int, code: str, message: str, **extra: Any) -> HTTPException:
    detail: dict[str, Any] = {"error": code, "message": message}
    detail.update(extra)
    return HTTPException(status_code=status_code, detail=detail)


def _resolve_ka_review_internal_root(*, require_git: bool = True) -> Path:
    raw_root = os.environ.get("PITH_REVIEW_ARTIFACT_ROOT", "").strip()
    if not raw_root:
        raise _ka_review_error(
            409,
            "review_artifact_root_missing",
            "Review artifact root must be configured for KA review apply.",
        )
    root = Path(raw_root).expanduser().resolve()
    if not root.exists() or not root.is_dir():
        raise _ka_review_error(
            409, "review_artifact_root_invalid", "Configured review artifact root is not a directory."
        )
    if require_git and not (root / ".git").exists():
        raise _ka_review_error(
            409, "review_artifact_root_not_git", "Configured review artifact root is not a git worktree."
        )
    return root


def _resolve_ka_review_artifact(root: Path, raw_path: str) -> tuple[Path, str]:
    candidate = Path(raw_path).expanduser()
    if not candidate.is_absolute():
        candidate = root / candidate
    try:
        resolved = candidate.resolve()
        rel = resolved.relative_to(root)
    except ValueError as exc:
        raise _ka_review_error(
            400,
            "artifact_path_outside_root",
            "Review artifact path must stay inside the configured review artifact root.",
        ) from exc
    rel_posix = rel.as_posix()
    if not any(rel_posix.startswith(prefix) for prefix in _KA_REVIEW_ALLOWED_PREFIXES):
        raise _ka_review_error(
            400,
            "artifact_path_not_allowed",
            "Review artifact path is not in an allowed KA review report directory.",
            path=rel_posix,
        )
    if not resolved.exists() or not resolved.is_file():
        raise _ka_review_error(400, "artifact_missing", "Review artifact path does not exist.", path=rel_posix)
    return resolved, rel_posix


def _git_output(repo_root: Path, args: list[str]) -> str:
    if should_suppress_optional_subprocess("ka_review_git_output"):
        raise _ka_review_error(
            503,
            "subprocess_suppressed_fork_safety",
            "Git artifact verification is suppressed because the API process is fork-sensitive.",
        )
    env = os.environ.copy()
    for key in ("GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE"):
        env.pop(key, None)
    try:
        return subprocess.check_output(
            ["git", "-C", str(repo_root), *args],
            stderr=subprocess.DEVNULL,
            text=True,
            env=env,
        ).strip()
    except subprocess.CalledProcessError as exc:
        raise _ka_review_error(409, "git_artifact_verification_failed", "Git artifact verification failed.") from exc


def _verify_ka_review_artifact_blob(repo_root: Path, commit: str, path: Path, rel_path: str) -> str:
    if not re.fullmatch(r"[0-9a-fA-F]{7,40}", commit or ""):
        raise _ka_review_error(400, "invalid_review_commit", "expected_review_commit must be a 7-40 char hex commit.")
    commit_obj = _git_output(repo_root, ["rev-parse", "--verify", f"{commit}^{{commit}}"])
    tree_line = _git_output(repo_root, ["ls-tree", "-r", commit_obj, "--", rel_path])
    if not tree_line:
        raise _ka_review_error(
            409, "artifact_not_in_commit", "Review artifact is not present in expected commit.", path=rel_path
        )
    parts = tree_line.split()
    if len(parts) < 4 or parts[1] != "blob":
        raise _ka_review_error(
            409, "artifact_not_blob", "Review artifact in expected commit is not a blob.", path=rel_path
        )
    expected_blob = parts[2]
    working_blob = _git_output(repo_root, ["hash-object", str(path)])
    if working_blob != expected_blob:
        raise _ka_review_error(
            409,
            "artifact_working_tree_drift",
            "Working review artifact differs from expected commit blob.",
            path=rel_path,
            expected_blob=expected_blob,
            working_blob=working_blob,
        )
    return expected_blob


def _load_ka_review_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise _ka_review_error(400, "invalid_review_summary", "Review summary JSON is malformed.") from exc
    if not isinstance(data, dict):
        raise _ka_review_error(400, "invalid_review_summary", "Review summary must be a JSON object.")
    return data


def _load_ka_review_csv(path: Path) -> list[dict[str, str]]:
    try:
        with path.open(newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))
    except OSError as exc:
        raise _ka_review_error(400, "invalid_review_csv", "Review CSV artifact could not be read.") from exc


def _status_set(rows: list[dict[str, str]], status: str) -> set[str]:
    return {row.get("concept_id", "").strip() for row in rows if row.get("manual_review_status", "").strip() == status}


def _verify_ka_review_artifacts(request: KAReviewApplyRequest) -> dict[str, Any]:
    root = _resolve_ka_review_internal_root()
    artifact_specs = {
        "summary": request.review_summary_path,
        "ledger": request.review_ledger_path,
        "proof": request.final_proof_csv_path,
    }
    resolved: dict[str, tuple[Path, str]] = {
        name: _resolve_ka_review_artifact(root, raw_path) for name, raw_path in artifact_specs.items()
    }
    blobs = {
        name: _verify_ka_review_artifact_blob(root, request.expected_review_commit, path, rel_path)
        for name, (path, rel_path) in resolved.items()
    }

    summary = _load_ka_review_json(resolved["summary"][0])
    ledger_rows = _load_ka_review_csv(resolved["ledger"][0])
    proof_rows = _load_ka_review_csv(resolved["proof"][0])

    if summary.get("apply_design_allowed") != "accepted_ids_only":
        raise _ka_review_error(
            409, "review_not_accepted_id_only", "Review summary does not allow accepted-ID-only apply."
        )

    summary_accepted = {str(cid).strip() for cid in (summary.get("accepted_ids") or []) if str(cid).strip()}
    summary_rejected = {str(cid).strip() for cid in (summary.get("rejected_ids") or []) if str(cid).strip()}
    summary_needs_human = {str(cid).strip() for cid in (summary.get("needs_human_ids") or []) if str(cid).strip()}
    ledger_accepted = _status_set(ledger_rows, "accept")
    ledger_rejected = _status_set(ledger_rows, "reject")
    ledger_needs_human = _status_set(ledger_rows, "needs_human")

    if summary_accepted != ledger_accepted:
        raise _ka_review_error(409, "accepted_id_disagreement", "Review summary and ledger disagree on accepted IDs.")
    if summary_rejected != ledger_rejected:
        raise _ka_review_error(409, "rejected_id_disagreement", "Review summary and ledger disagree on rejected IDs.")
    if summary_needs_human != ledger_needs_human:
        raise _ka_review_error(
            409, "needs_human_id_disagreement", "Review summary and ledger disagree on needs-human IDs."
        )
    if (summary_accepted & summary_rejected) or (summary_accepted & summary_needs_human):
        raise _ka_review_error(409, "blocked_id_overlap", "Accepted IDs overlap rejected or needs-human IDs.")
    if not summary_accepted:
        raise _ka_review_error(409, "accepted_ids_empty", "Review summary has no accepted IDs to apply.")

    proof_targets: dict[str, str] = {}
    for row in proof_rows:
        concept_id = (row.get("concept_id") or "").strip()
        if concept_id in summary_accepted:
            if (row.get("decision") or "").strip() != "recommend_reclassify":
                raise _ka_review_error(
                    409,
                    "accepted_id_not_recommended",
                    "Accepted ID is not a final proof reclassification recommendation.",
                    concept_id=concept_id,
                )
            target = (row.get("recommended_knowledge_area") or "").strip()
            if not target:
                raise _ka_review_error(
                    409, "accepted_id_missing_target", "Accepted ID has no target KA.", concept_id=concept_id
                )
            proof_targets[concept_id] = target

    missing = sorted(summary_accepted - set(proof_targets))
    if missing:
        raise _ka_review_error(
            409, "accepted_ids_missing_from_proof", "Accepted IDs are missing from final proof.", missing=missing
        )

    return {
        "root": root,
        "paths": {name: rel_path for name, (_, rel_path) in resolved.items()},
        "blobs": blobs,
        "accepted_ids": sorted(summary_accepted),
        "rejected_ids": sorted(summary_rejected),
        "needs_human_ids": sorted(summary_needs_human),
        "targets": proof_targets,
    }


def _create_ka_review_apply_snapshot() -> dict[str, Any]:
    import sqlite3 as _sqlite3

    from app.core.profile import resolve_data_dir, resolve_db_path

    data_dir = resolve_data_dir()
    source_path = resolve_db_path(data_dir)
    backup_dir = data_dir / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    timestamp = _utc_now_iso().replace(":", "").replace("-", "").replace(".", "_").replace("+", "Z")
    backup_path = backup_dir / f"pith_ka_review_apply_{timestamp}.db"
    tmp_path = backup_path.with_suffix(".db.tmp")
    if not source_path.exists():
        raise _ka_review_error(409, "db_snapshot_source_missing", "Source DB does not exist.")

    try:
        src = _sqlite3.connect(f"file:{source_path}?mode=ro", uri=True)
        try:
            dst = _sqlite3.connect(str(tmp_path))
            try:
                src.backup(dst, pages=-1)
            finally:
                dst.close()
        finally:
            src.close()
        tmp_path.replace(backup_path)
        verify_conn = _sqlite3.connect(f"file:{backup_path}?mode=ro", uri=True)
        try:
            quick_check = verify_conn.execute("PRAGMA quick_check").fetchone()[0]
            concept_count = verify_conn.execute("SELECT COUNT(*) FROM concepts WHERE is_current = 1").fetchone()[0]
        finally:
            verify_conn.close()
    except HTTPException:
        raise
    except Exception as exc:
        if tmp_path.exists():
            tmp_path.unlink(missing_ok=True)
        raise _ka_review_error(409, "db_snapshot_failed", "Could not create WAL-safe DB snapshot.") from exc
    if quick_check != "ok":
        raise _ka_review_error(
            409,
            "db_snapshot_quick_check_failed",
            "DB snapshot quick_check did not return ok.",
            quick_check=quick_check,
            path=str(backup_path),
        )
    return {"path": str(backup_path), "quick_check": quick_check, "concept_count": concept_count}


def _json_data_ka(data: dict[str, Any]) -> str | None:
    value = data.get("knowledge_area")
    return str(value) if value is not None else None


def _json_meta_ka(data: dict[str, Any]) -> str | None:
    meta = data.get("metadata")
    if not isinstance(meta, dict):
        return None
    value = meta.get("knowledge_area")
    return str(value) if value is not None else None


def _prepare_ka_review_row(
    row,
    target_ka: str,
    *,
    now: str,
    review_commit: str,
    review_artifact: str,
) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    from app.core.taxonomy_utils import normalize_knowledge_area

    concept_id = row["id"]
    current_ka = row["knowledge_area"]
    base = {"concept_id": concept_id, "target_ka": target_ka, "current_ka": current_ka}
    if int(row["is_current"] or 0) != 1:
        return None, {**base, "result": "skipped", "reason": "not_current"}
    if current_ka != "general":
        return None, {**base, "result": "skipped", "reason": "current_ka_changed"}
    try:
        data = json.loads(row["data"]) if row["data"] else {}
    except json.JSONDecodeError:
        return None, {**base, "result": "skipped", "reason": "invalid_json"}
    if not isinstance(data, dict):
        return None, {**base, "result": "skipped", "reason": "invalid_json"}

    data_ka = _json_data_ka(data)
    meta_ka = _json_meta_ka(data)
    if data_ka not in (None, "general") or meta_ka not in (None, "general"):
        return None, {
            **base,
            "result": "skipped",
            "reason": "json_ka_changed",
            "json_ka": data_ka,
            "metadata_ka": meta_ka,
        }

    normalized_target, source = normalize_knowledge_area(target_ka, strict=True)
    if not normalized_target or normalized_target == "general":
        return None, {
            **base,
            "result": "skipped",
            "reason": "invalid_target_ka",
            "normalized_target_ka": normalized_target,
            "normalization_source": source,
        }

    meta = data.get("metadata")
    if not isinstance(meta, dict):
        meta = {}
        data["metadata"] = meta
    data["knowledge_area"] = normalized_target
    meta["knowledge_area"] = normalized_target
    meta["knowledge_area_source"] = "manual_review_accepted_id"
    meta["ka_admission_state"] = "classified"
    meta["ka_admission_source"] = "manual_review_accepted_id"
    meta["ka_admission_at"] = now
    meta["ka_reclassified_from"] = "general"
    meta["ka_reclassified_at"] = now
    meta["ka_review_commit"] = review_commit
    meta["ka_review_artifact"] = review_artifact
    return data, {**base, "target_ka": normalized_target, "result": "ready", "normalization_source": source}


def _ka_integrity_snapshot(conn, *, batch_limit: int, review_ambiguous: bool = False) -> dict[str, Any]:
    from app.cognitive.ka_admission import KA_QUEUED_UNCLASSIFIED_STALE_HOURS

    json_ka = _json_knowledge_area_expr()
    state_expr = _ka_admission_state_expr()
    mismatch_count = conn.execute(
        f"""SELECT COUNT(*) FROM concepts
            WHERE is_current = 1
              AND COALESCE(knowledge_area, '') != COALESCE({json_ka}, '')"""
    ).fetchone()[0]
    total_current = conn.execute("SELECT COUNT(*) FROM concepts WHERE is_current = 1").fetchone()[0]
    general_current = conn.execute(
        "SELECT COUNT(*) FROM concepts WHERE is_current = 1 AND knowledge_area = 'general'"
    ).fetchone()[0]
    unreviewed_general = conn.execute(
        f"""SELECT COUNT(*) FROM concepts
           WHERE is_current = 1
             AND {_unreviewed_general_predicate()}"""
    ).fetchone()[0]
    intentional_general = conn.execute(
        f"""SELECT COUNT(*) FROM concepts
           WHERE is_current = 1 AND knowledge_area = 'general'
             AND {state_expr} = 'intentional_general'"""
    ).fetchone()[0]
    deterministic_ambiguous = conn.execute(
        f"""SELECT COUNT(*) FROM concepts
           WHERE is_current = 1 AND knowledge_area = 'general'
             AND ({state_expr} = 'deterministic_ambiguous'
                  OR COALESCE(json_extract(data, '$.metadata.knowledge_area_review'), '') = 'deterministic_ambiguous')"""
    ).fetchone()[0]
    queued_unclassified = conn.execute(
        f"""SELECT COUNT(*) FROM concepts
           WHERE is_current = 1 AND knowledge_area = 'unclassified'
             AND {state_expr} = 'queued_unclassified'"""
    ).fetchone()[0]
    queued_unclassified_stale = conn.execute(
        f"""SELECT COUNT(*) FROM concepts
           WHERE is_current = 1 AND knowledge_area = 'unclassified'
             AND {state_expr} = 'queued_unclassified'
             AND datetime(COALESCE(json_extract(data, '$.metadata.ka_admission_at'), created_at)) < datetime('now', ?)""",
        (f"-{KA_QUEUED_UNCLASSIFIED_STALE_HOURS} hours",),
    ).fetchone()[0]
    fallback_failure = conn.execute(
        f"""SELECT COUNT(*) FROM concepts
           WHERE is_current = 1 AND knowledge_area = 'unclassified'
             AND {state_expr} = 'fallback_failure'"""
    ).fetchone()[0]
    invalid_ka_admission_state = conn.execute(
        f"""SELECT COUNT(*) FROM concepts
           WHERE is_current = 1
             AND {state_expr} != ''
             AND {state_expr} NOT IN (
                 'classified',
                 'intentional_general',
                 'deterministic_ambiguous',
                 'queued_unclassified',
                 'fallback_failure'
             )"""
    ).fetchone()[0]
    planned_updates, ambiguous_ids = _safe_general_ka_candidates(conn, batch_limit=batch_limit)
    unclassified_updates = _safe_unclassified_ka_candidates(conn, batch_limit=batch_limit)
    snapshot = {
        "sql_json_mismatches": mismatch_count,
        "general_current": general_current,
        "unreviewed_general": unreviewed_general,
        "intentional_general": intentional_general,
        "deterministic_ambiguous": deterministic_ambiguous,
        "queued_unclassified": queued_unclassified,
        "queued_unclassified_stale": queued_unclassified_stale,
        "fallback_failure": fallback_failure,
        "invalid_ka_admission_state": invalid_ka_admission_state,
        "total_current": total_current,
        "general_pct": round(general_current / total_current, 4) if total_current else 0.0,
        "batch_limit": batch_limit,
        "batch_reclassifiable": len(planned_updates),
        "batch_unclassified_reclassifiable": len(unclassified_updates),
        "batch_ambiguous": len(ambiguous_ids),
        "is_healthy": (
            mismatch_count == 0
            and unreviewed_general == 0
            and fallback_failure == 0
            and queued_unclassified_stale == 0
            and invalid_ka_admission_state == 0
        ),
    }
    if review_ambiguous:
        ambiguous_review, ambiguous_conflicts, ambiguous_unresolved, ambiguous_reclassifiable_total = (
            _ambiguous_second_pass_candidates(conn, batch_limit=batch_limit, scan_limit=_AMBIGUOUS_SECOND_PASS_MAX_SCAN)
        )
        snapshot.update(
            {
                "ambiguous_review_reclassifiable": len(ambiguous_review),
                "ambiguous_review_reclassifiable_total": ambiguous_reclassifiable_total,
                "ambiguous_review_conflicts": len(ambiguous_conflicts),
                "ambiguous_review_unresolved": len(ambiguous_unresolved),
                "ambiguous_review_scan_limit": _AMBIGUOUS_SECOND_PASS_MAX_SCAN,
            }
        )
    return snapshot


@app.get("/pith_ka_integrity")
def pith_ka_integrity(
    repair: bool = False,
    dry_run: bool = True,
    batch_limit: int = 250,
    review_ambiguous: bool = False,
):
    """Inspect and optionally repair deterministic knowledge-area drift."""
    batch_limit = max(1, min(batch_limit, 1000))
    try:
        with _db() as conn:
            pre = _ka_integrity_snapshot(conn, batch_limit=batch_limit, review_ambiguous=review_ambiguous)
        result = {
            **pre,
            "repair": {"dry_run": dry_run, "attempted": False, "updated": 0, "ambiguous": pre["batch_ambiguous"]},
        }
        if not repair:
            return result

        with _db() as conn:
            planned_updates, ambiguous_ids = _safe_general_ka_candidates(conn, batch_limit=batch_limit)
            unclassified_updates = _safe_unclassified_ka_candidates(conn, batch_limit=batch_limit)
            ambiguous_review, ambiguous_conflicts, ambiguous_unresolved = (
                _ambiguous_second_pass_candidates(
                    conn, batch_limit=batch_limit, scan_limit=_AMBIGUOUS_SECOND_PASS_MAX_SCAN
                )[:3]
                if review_ambiguous
                else ([], [], [])
            )
            mismatch_rows = conn.execute(
                f"""SELECT id, knowledge_area
                    FROM concepts
                    WHERE is_current = 1
                      AND COALESCE(knowledge_area, '') != COALESCE({_json_knowledge_area_expr()}, '')"""
            ).fetchall()

        if dry_run:
            result["repair"] = {
                "dry_run": True,
                "attempted": False,
                "would_update": len(planned_updates),
                "would_update_unclassified": len(unclassified_updates),
                "would_fix_mismatches": len(mismatch_rows),
                "ambiguous": len(ambiguous_ids),
                "would_mark_ambiguous": len(ambiguous_ids),
                "ambiguous_ids": ambiguous_ids[:50],
                "would_update_ambiguous_review": len(ambiguous_review),
                "ambiguous_review_conflicts": len(ambiguous_conflicts),
                "ambiguous_review_unresolved": len(ambiguous_unresolved),
                "ambiguous_review_ids": [row[0] for row in ambiguous_review[:50]],
                "review_ambiguous": review_ambiguous,
            }
            return result

        updated = 0
        unclassified_updated = 0
        mismatch_fixed = 0
        ambiguous_marked = 0
        ambiguous_review_updated = 0
        with _db_immediate() as conn:
            now = _utc_now_iso()
            for row in mismatch_rows:
                conn.execute(
                    """UPDATE concepts
                       SET data = json_set(
                           COALESCE(data, '{}'),
                           '$.knowledge_area', ?,
                           '$.metadata.knowledge_area', ?
                       ),
                       updated_at = ?
                       WHERE id = ?""",
                    (row["knowledge_area"], row["knowledge_area"], now, row["id"]),
                )
                mismatch_fixed += 1
            for concept_id, area, source in planned_updates:
                conn.execute(
                    """UPDATE concepts
                       SET knowledge_area = ?,
                           data = json_set(
                               COALESCE(data, '{}'),
                               '$.knowledge_area', ?,
                               '$.metadata.knowledge_area', ?,
                               '$.metadata.knowledge_area_source', ?,
                               '$.metadata.ka_admission_state', 'classified',
                               '$.metadata.ka_admission_source', ?,
                               '$.metadata.ka_admission_at', ?
                           ),
                           updated_at = ?
                       WHERE id = ? AND is_current = 1 AND knowledge_area = 'general'""",
                    (area, area, area, source, source, now, now, concept_id),
                )
                updated += conn.execute("SELECT changes()").fetchone()[0]
            for concept_id, area, source in unclassified_updates:
                conn.execute(
                    """UPDATE concepts
                       SET knowledge_area = ?,
                           data = json_set(
                               COALESCE(data, '{}'),
                               '$.knowledge_area', ?,
                               '$.metadata.knowledge_area', ?,
                               '$.metadata.knowledge_area_source', ?,
                               '$.metadata.ka_admission_state', 'classified',
                               '$.metadata.ka_admission_source', ?,
                               '$.metadata.ka_admission_at', ?
                           ),
                           updated_at = ?
                       WHERE id = ? AND is_current = 1 AND knowledge_area = 'unclassified'""",
                    (area, area, area, source, source, now, now, concept_id),
                )
                unclassified_updated += conn.execute("SELECT changes()").fetchone()[0]
            for concept_id, area, confidence, rule in ambiguous_review:
                conn.execute(
                    """UPDATE concepts
                       SET knowledge_area = ?,
                           data = json_set(
                               COALESCE(data, '{}'),
                               '$.knowledge_area', ?,
                               '$.metadata.knowledge_area', ?,
                               '$.metadata.knowledge_area_source', 'deterministic_second_pass',
                               '$.metadata.ka_admission_state', 'classified',
                               '$.metadata.ka_admission_source', 'deterministic_second_pass',
                               '$.metadata.ka_confidence', ?,
                               '$.metadata.ka_reclassified_from', 'general',
                               '$.metadata.ka_reclassified_at', ?,
                               '$.metadata.ka_second_pass_rule', ?,
                               '$.metadata.ka_second_pass_at', ?
                           ),
                           updated_at = ?
                       WHERE id = ? AND is_current = 1 AND knowledge_area = 'general'""",
                    (area, area, area, confidence, now, rule, now, now, concept_id),
                )
                ambiguous_review_updated += conn.execute("SELECT changes()").fetchone()[0]
            for concept_id in ambiguous_ids:
                conn.execute(
                    """UPDATE concepts
                       SET data = json_set(
                           COALESCE(data, '{}'),
                           '$.metadata.ka_admission_state', 'deterministic_ambiguous',
                           '$.metadata.ka_admission_source', 'repair',
                           '$.metadata.ka_admission_at', ?,
                           '$.metadata.ka_reviewed_at', ?,
                           '$.metadata.knowledge_area_review', 'deterministic_ambiguous',
                           '$.metadata.knowledge_area_reviewed_at', ?
                       ),
                       updated_at = ?
                       WHERE id = ? AND is_current = 1 AND knowledge_area = 'general'""",
                    (now, now, now, now, concept_id),
                )
                ambiguous_marked += conn.execute("SELECT changes()").fetchone()[0]
            post = _ka_integrity_snapshot(conn, batch_limit=batch_limit, review_ambiguous=review_ambiguous)
        result = {
            **post,
            "repair": {
                "dry_run": False,
                "attempted": True,
                "updated": updated,
                "unclassified_updated": unclassified_updated,
                "mismatches_fixed": mismatch_fixed,
                "ambiguous_marked": ambiguous_marked,
                "ambiguous_review_updated": ambiguous_review_updated,
                "ambiguous_review_conflicts": len(ambiguous_conflicts),
                "ambiguous_review_unresolved": len(ambiguous_unresolved),
                "ambiguous": len(ambiguous_ids),
                "ambiguous_ids": ambiguous_ids[:50],
                "review_ambiguous": review_ambiguous,
                "pre_repair": pre,
                "post_repair": post,
            },
        }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.post("/pith_ka_review_apply", dependencies=[Depends(verify_api_key)])
def pith_ka_review_apply(request: KAReviewApplyRequest):
    """Apply manually accepted KA review recommendations with artifact and health gates."""
    try:
        if not request.accepted_ids_only:
            raise _ka_review_error(400, "accepted_ids_only_required", "accepted_ids_only must be true.")
        if request.apply and request.dry_run:
            raise _ka_review_error(400, "ambiguous_apply_flags", "apply=true requires dry_run=false.")
        if not request.dry_run and not request.apply:
            raise _ka_review_error(400, "apply_flag_required", "dry_run=false requires apply=true.")

        artifacts = _verify_ka_review_artifacts(request)
        accepted_ids = artifacts["accepted_ids"]
        targets = artifacts["targets"]
        pre: dict[str, Any]
        with _db() as conn:
            pre = _ka_integrity_snapshot(conn, batch_limit=1000, review_ambiguous=False)
            placeholders = ",".join("?" for _ in accepted_ids)
            rows = conn.execute(
                f"SELECT id, knowledge_area, is_current, status, data FROM concepts WHERE id IN ({placeholders})",
                tuple(accepted_ids),
            ).fetchall()
        if request.apply and not pre.get("is_healthy"):
            raise _ka_review_error(
                409,
                "ka_integrity_unhealthy",
                "KA integrity must be healthy before accepted-ID apply.",
                pre_integrity=pre,
            )

        row_by_id = {row["id"]: row for row in rows}
        now = _utc_now_iso()
        review_artifact = artifacts["paths"]["ledger"]
        dry_rows: list[dict[str, Any]] = []
        skipped: list[dict[str, Any]] = []
        for concept_id in accepted_ids:
            row = row_by_id.get(concept_id)
            if row is None:
                result = {
                    "concept_id": concept_id,
                    "target_ka": targets[concept_id],
                    "result": "skipped",
                    "reason": "missing_concept",
                }
                skipped.append(result)
                dry_rows.append(result)
                continue
            data, result = _prepare_ka_review_row(
                row,
                targets[concept_id],
                now=now,
                review_commit=request.expected_review_commit,
                review_artifact=review_artifact,
            )
            if data is None:
                skipped.append(result)
                dry_rows.append(result)
            else:
                dry_rows.append({**result, "result": "would_update" if request.dry_run else "ready"})

        artifact_verification = {
            "summary_blob": artifacts["blobs"]["summary"],
            "ledger_blob": artifacts["blobs"]["ledger"],
            "proof_blob": artifacts["blobs"]["proof"],
            "accepted_count": len(artifacts["accepted_ids"]),
            "rejected_count": len(artifacts["rejected_ids"]),
            "needs_human_count": len(artifacts["needs_human_ids"]),
        }
        base_response: dict[str, Any] = {
            "success": True,
            "dry_run": request.dry_run,
            "attempted": False,
            "artifact_commit": request.expected_review_commit,
            "artifact_verification": artifact_verification,
            "pre_integrity": pre,
            "snapshot": None,
            "planned": sum(1 for row in dry_rows if row["result"] in {"would_update", "ready"}),
            "updated": 0,
            "skipped": skipped,
            "rows": dry_rows,
            "post_integrity": None,
        }
        if request.dry_run:
            return base_response

        snapshot = _create_ka_review_apply_snapshot()
        apply_rows: list[dict[str, Any]] = []
        apply_skipped: list[dict[str, Any]] = []
        updated = 0
        with _db_immediate() as conn:
            now = _utc_now_iso()
            for concept_id in accepted_ids:
                row = conn.execute(
                    "SELECT id, knowledge_area, is_current, status, data FROM concepts WHERE id = ?",
                    (concept_id,),
                ).fetchone()
                if row is None:
                    result = {
                        "concept_id": concept_id,
                        "target_ka": targets[concept_id],
                        "result": "skipped",
                        "reason": "missing_concept",
                    }
                    apply_skipped.append(result)
                    apply_rows.append(result)
                    continue
                data, result = _prepare_ka_review_row(
                    row,
                    targets[concept_id],
                    now=now,
                    review_commit=request.expected_review_commit,
                    review_artifact=review_artifact,
                )
                if data is None:
                    apply_skipped.append(result)
                    apply_rows.append(result)
                    continue
                rowcount = update_concept_data(conn, concept_id, data)
                if rowcount == 1:
                    updated += 1
                    apply_rows.append({**result, "result": "updated"})
                else:
                    failed = {**result, "result": "skipped", "reason": "update_failed"}
                    apply_skipped.append(failed)
                    apply_rows.append(failed)
            post = _ka_integrity_snapshot(conn, batch_limit=1000, review_ambiguous=False)
        return {
            **base_response,
            "dry_run": False,
            "attempted": True,
            "snapshot": snapshot,
            "planned": sum(1 for row in apply_rows if row["result"] == "updated"),
            "updated": updated,
            "skipped": apply_skipped,
            "rows": apply_rows,
            "post_integrity": post,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.delete("/pith_question/{concept_id}", dependencies=[Depends(verify_api_key)])
def remove_question(concept_id: str):
    """Remove question for concept from queue."""
    question_queue.remove_question(concept_id)
    return {"status": "removed", "concept_id": concept_id}


def _reflection_summary_text(summary: Any, mode: str) -> str:
    # OPS-046: Build human-readable reflection_summary (always present).
    parts = []
    if summary.concepts_consolidated:
        parts.append(f"{summary.concepts_consolidated} consolidated")
    if summary.concepts_decayed:
        parts.append(f"{summary.concepts_decayed} decayed")
    if summary.concepts_archived:
        parts.append(f"{summary.concepts_archived} forgotten")
    if getattr(summary, "concepts_gc_archived", 0):  # REFLECT-025
        parts.append(f"{summary.concepts_gc_archived} gc-archived")
    if getattr(summary, "forgetting_candidates", 0):  # REFLECT-025: early-warning gauge
        parts.append(f"{summary.forgetting_candidates} forget-candidates")
    if summary.concepts_recalibrated:
        parts.append(f"{summary.concepts_recalibrated} recalibrated")
    if summary.concepts_promoted:
        parts.append(f"{summary.concepts_promoted} promoted")
    if summary.concepts_time_matured:
        parts.append(f"{summary.concepts_time_matured} matured")
    if summary.associations_updated:
        parts.append(f"{summary.associations_updated} associations updated")
    if summary.questions_generated:
        parts.append(f"{summary.questions_generated} questions generated")

    if summary.aborted:
        abort_location = getattr(summary, "abort_stage", None) or summary.last_completed_step or "startup"
        return f"{mode.capitalize()} reflection aborted: {summary.abort_reason or 'unknown'} after {abort_location}"
    return f"{mode.capitalize()} reflection: " + (", ".join(parts) if parts else "no changes")


def _reflection_api_response(result: Any, *, verbose: bool) -> dict[str, Any]:
    summary = result.summary
    if summary is None:
        response = result.response_fields
        response["reflection_summary"] = f"{result.mode.capitalize()} reflection: no changes"
        return response

    response = {
        "reflection_summary": _reflection_summary_text(summary, result.mode),
        "mode": result.mode,
        "run_id": result.run_id,
        "run_status": result.status,
        "source": result.source,
        "duration_ms": result.duration_ms,
        "concepts_consolidated": summary.concepts_consolidated,
        "concepts_decayed": summary.concepts_decayed,
        "concepts_archived": summary.concepts_archived,
        "forgetting_candidates": getattr(summary, "forgetting_candidates", 0),  # REFLECT-025: early-warning gauge
        "concepts_gc_archived": getattr(summary, "concepts_gc_archived", 0),  # REFLECT-025: GC archival (was dropped)
        "concepts_recalibrated": summary.concepts_recalibrated,
        "concepts_promoted": summary.concepts_promoted,
        "concepts_time_matured": summary.concepts_time_matured,
        "associations_updated": summary.associations_updated,
        "questions_generated": summary.questions_generated,
        "gc_queue_remaining": summary.gc_queue_remaining,
        "timestamp": summary.timestamp,
        "aborted": summary.aborted,
        "abort_reason": summary.abort_reason,
        "last_completed_step": summary.last_completed_step,
        "abort_stage": getattr(summary, "abort_stage", None),
        "budget_status": getattr(summary, "budget_status", "completed"),
    }

    # Verbose fields: internal scoring details omitted by default (OPS-048 alignment).
    if verbose:
        response["phase_timings"] = summary.phase_timings
        response["deferred_phases"] = getattr(summary, "deferred_phases", [])
        response["phase_budget_decisions"] = getattr(summary, "phase_budget_decisions", {})
        response["merge_progress"] = getattr(summary, "merge_progress", {})
        response["evidence_cv"] = {
            "composite": summary.evidence_cv_composite,
            "reliability": summary.evidence_cv_reliability,
            "directness": summary.evidence_cv_directness,
            "consistency": summary.evidence_cv_consistency,
            "corroboration": summary.evidence_cv_corroboration,
            "recency": summary.evidence_cv_recency,
        }

    return response


@app.post("/pith_reflect", dependencies=[Depends(verify_api_key)])
def pith_reflect(mode: str = "incremental", verbose: bool = False, response: Response = None):
    """Run reflection/consolidation cycle.

    Args:
        mode: 'incremental' (default) or 'full'
        verbose: If True, include phase_timings and evidence_cv breakdowns.
                 If False (default), return key counts + reflection_summary only.

    The reflection_summary field is always present regardless of verbose setting.
    """
    try:
        from app.ops.reflection_runner import (
            ReflectionRunRequest,
            run_reflection,
            submit_reflection_background,
        )

        engine_override = None if isinstance(reflection_engine, _LazyImportProxy) else reflection_engine
        require_ready = mode == "full" and engine_override is None
        request = ReflectionRunRequest(
            mode=mode,
            source="api",
            verbose=verbose,
            require_ready=require_ready,
            ready_state=_build_ready_state() if require_ready else None,
            reflection_engine_override=engine_override,
        )
        result = (
            submit_reflection_background(request)
            if mode == "full" and engine_override is None
            else run_reflection(request)
        )
        if result.status in {"accepted", "deferred", "queued"}:
            if response is not None:
                response.status_code = 202
            accepted_response = result.response_fields
            if result.status == "accepted":
                accepted_response["reflection_summary"] = "Full reflection accepted for durable background execution"
            elif result.status == "queued":
                accepted_response["reflection_summary"] = "Full reflection queued for durable background execution"
            else:
                accepted_response["reflection_summary"] = "Full reflection deferred by admission policy"
            return accepted_response
        if result.status == "rejected":
            headers = None
            retry_after = result.admission.retry_after_seconds if result.admission else None
            if retry_after is not None:
                headers = {"Retry-After": str(retry_after)}
            raise HTTPException(
                status_code=result.admission.http_status if result.admission else 503,
                detail=result.response_fields,
                headers=headers,
            )
        if result.status == "failed":
            raise HTTPException(status_code=500, detail=result.response_fields)
        if verbose:
            response = _reflection_api_response(result, verbose=True)
            # MONITOR-063: helper gates "phase_timings" behind verbose output.
        else:
            response = _reflection_api_response(result, verbose=False)
        if "reflection_summary" not in response:
            response["reflection_summary"] = f"{mode.capitalize()} reflection: no changes"
        return response
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.get("/pith_health")
def pith_health(
    detail: str = "fast",
    freshness: str = "fast",
    force_refresh: bool = False,
    capture_budget_ms: str | None = None,
    include: str | None = None,
):
    """Get pith health analysis."""
    if detail not in {"fast", "full"}:
        raise HTTPException(status_code=400, detail="detail must be 'fast' or 'full'")
    requested_sections = _parse_pith_health_include(include)
    _validate_diagnostic_freshness(freshness)
    request_budget_ms = None
    if capture_budget_ms is not None or detail == "full" or freshness == "authoritative" or requested_sections:
        request_budget_ms = _bounded_capture_budget_ms(
            capture_budget_ms,
            default_ms=DIAGNOSTIC_AUTHORITATIVE_CAPTURE_BUDGET_DEFAULT_MS,
        )
    capture_started = time.monotonic()
    ready = _build_ready_state()
    try:
        from app.ops.reflection_runner import reflection_runner

        active_reflection = reflection_runner.get_active_run()
    except Exception:
        active_reflection = None
    if _should_defer_health_db_metrics(ready):
        reason = _health_metrics_defer_reason(ready)
        payload = {
            "mode": detail,
            "generated_at": _utc_now_iso(),
            "cache_age_ms": 0,
            "partial": True,
            "section_errors": {"startup": reason},
            "status": "recovering",
            "health_score": 0.0,
            "total_concepts": 0,
            "avg_confidence": 0.0,
            "avg_stability": 0.0,
            "ready_state": {
                "mode": ready.get("mode"),
                "process_state": ready.get("process_state"),
                "write_state": ready.get("write_state"),
                "retrieval_state": ready.get("retrieval_state"),
            },
            "active_reflection": active_reflection,
        }
        return _annotate_capture_contract(
            payload,
            requested_freshness=freshness,
            authoritative=False,
            value_semantics="unavailable",
            degraded_reason=reason,
            capture_budget_ms=request_budget_ms or DIAGNOSTIC_AUTHORITATIVE_CAPTURE_BUDGET_DEFAULT_MS,
        )
    if detail == "fast":
        if freshness == "authoritative":
            base_health = _build_pith_health_authoritative_cached(request_budget_ms, force_refresh=force_refresh)
        else:
            base_health = _build_pith_health_fast_cached()
        return _attach_requested_pith_health_sections(
            base_health,
            requested_sections,
            capture_started=capture_started,
            capture_budget_ms=request_budget_ms or DIAGNOSTIC_AUTHORITATIVE_CAPTURE_BUDGET_DEFAULT_MS,
        )

    budget_ms = request_budget_ms or DIAGNOSTIC_AUTHORITATIVE_CAPTURE_BUDGET_DEFAULT_MS
    if freshness == "authoritative":
        base_health = _build_pith_health_authoritative_cached(budget_ms, force_refresh=force_refresh)
    else:
        base_health = _build_pith_health_fast_cached()
    full_health = _build_deferred_full_health_payload(base_health, active_reflection)
    return _attach_requested_pith_health_sections(
        full_health,
        requested_sections,
        capture_started=capture_started,
        capture_budget_ms=budget_ms,
    )


@app.get("/memory_projection")
def memory_projection():
    """HEALTH-002: Predictive memory growth projection."""
    try:
        return get_memory_projection_data()
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.get("/retrieval_distribution")
def retrieval_distribution():
    """MEASURE-005: Retrieval score distribution report."""
    try:
        return get_distribution_report()
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.get("/health/maintenance")
def maintenance_health():
    """Amendment 3: Check maintenance scheduler health via heartbeat file."""
    result = _build_maintenance_health()
    result["session_learn_queue"] = _build_session_learn_queue_health()
    try:
        from app.retrieval.lifecycle_index_drain import get_lifecycle_index_outbox_status

        result["lifecycle_index_outbox"] = get_lifecycle_index_outbox_status()
    except Exception as exc:
        result["lifecycle_index_outbox"] = {
            "status": "critical",
            "alert": True,
            "worker_running": False,
            "latest_error": _safe_error(exc),
        }
    return result


@app.get("/health/backup")
def backup_health():
    """OPS-575: Serve bounded producer-cached maintenance-backup proof."""
    from app.core.profile import resolve_data_dir
    from app.ops.backup_health import build_backup_health_response

    return build_backup_health_response(resolve_data_dir(), now=_utc_now())


@app.post("/pith/benchmark", dependencies=[Depends(verify_api_key)])
async def benchmark_endpoint(mode: str = "full"):
    """AF-05: Run the internal CogGov governance diagnostic.

    This is local health evidence only, not public benchmark evidence.
    The diagnostic logic lives in app/coggov_bench.py (992+ lines).
    Amendment 7: 5-minute timeout to prevent server hangs.
    """
    import asyncio as _asyncio

    if mode not in ("light", "full"):
        raise HTTPException(status_code=400, detail="mode must be 'light' or 'full'")

    import threading as _threading

    async def _wait_for_worker_shutdown(reason: str) -> None:
        if bench_task is None:
            return
        try:
            await _asyncio.wait_for(bench_task, timeout=5)
        except CogGovBenchCancelled:
            logger.info("Benchmark worker acknowledged %s cancellation", reason)
        except Exception as exc:
            logger.warning(
                "Benchmark worker stopped after %s with %s: %s",
                reason,
                type(exc).__name__,
                exc,
            )

    cancel_event = _threading.Event()
    bench_task = None
    try:
        from app.ops.coggov_bench import CogGovBenchCancelled, run_coggov_bench

        bench_task = _asyncio.create_task(_asyncio.to_thread(run_coggov_bench, mode=mode, cancel_event=cancel_event))
        done, _ = await _asyncio.wait({bench_task}, timeout=300)  # 5 minute max without cancelling worker
        if not done:
            raise TimeoutError
        result = bench_task.result()
        return result.to_dict() if hasattr(result, "to_dict") else result
    except TimeoutError:
        cancel_event.set()
        await _wait_for_worker_shutdown("timeout")
        raise HTTPException(status_code=504, detail=f"Benchmark timed out after 300s in {mode} mode")
    except _asyncio.CancelledError:
        cancel_event.set()
        await _wait_for_worker_shutdown("request")
        raise
    except CogGovBenchCancelled:
        raise HTTPException(status_code=503, detail="Benchmark cancelled before completion")
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


# --- Profile Management ---


@app.get("/profiles")
def get_profiles():
    """List available data profiles under ~/pith-data/."""
    from app.core.profile import get_active_profile, list_profiles

    return {
        "active": get_active_profile(),
        "profiles": list_profiles(),
    }


@app.get("/profile")
def get_profile():
    """Return active profile name and resolved data path."""
    from app.core.profile import get_active_profile, resolve_data_dir

    return {
        "profile": get_active_profile(),
        "data_dir": str(resolve_data_dir()),
    }


# --- Maintenance / Autonomous Cognition ---


@app.post("/maintenance", dependencies=[Depends(verify_api_key)])
async def maintenance_endpoint(request: Request, body: dict = {}):
    """Run autonomous maintenance cycle (sleeptime compute).

    Body params:
      phases: list[int] — which phases to run (default: all 1-5)
      dry_run: bool — preview without executing (default: false)

    Phases:
      1: Scheduled async tasks (currency scan, authority recal, etc.)
      2: Reflection cycle (decay, forgetting, strengthening, merging)
      3: Experiment generation (synthesis, hypothesis, counterfactual, analogy)
      4: Curiosity — question generation for weak concepts
      5: Health report + degradation alerts
    """
    from app.ops.maintenance import run_maintenance
    from app.ops.maintenance_scheduler import maintenance_lock  # A2: Shared mutex

    phases = body.get("phases")
    dry_run = body.get("dry_run", False)

    op = body.get("op")
    if op == "tfidf_repair":
        # In-process fresh-rebuild + atomic swap (RETRIEVAL-123). Runs in the
        # server process so the in-process writer-quiesce gate covers the hot
        # path. to_thread keeps the event loop responsive during the ~65s build.
        from app.ops.pressure_state import clear_maintenance_lease, write_maintenance_lease

        async with maintenance_lock:
            lease = write_maintenance_lease(source="tfidf_repair", phase="repair", expected_timeout_seconds=180)
            try:
                report = await asyncio.to_thread(retrieval_engine.rebuild_and_swap_repair, dry_run=dry_run)
            finally:
                clear_maintenance_lease(run_id=lease.run_id)
        return report

    async with maintenance_lock:
        report = await run_maintenance(phases=phases, dry_run=dry_run)
    return report.to_dict()


@app.get("/maintenance/status", dependencies=[Depends(verify_api_key)])
def maintenance_status():
    """Get status of all async tasks and degradation alerts."""
    from app.ops.async_tasks import task_runner
    from app.storage import get_db_connection

    conn = get_db_connection()
    status = task_runner.get_status(conn)

    # RETRIEVAL-123: expose in-process writer-quiesce observability.
    try:
        status["quiesce"] = {
            "quiesce_active": retrieval_engine._quiesce.is_set(),
            "inflight_writers": retrieval_engine._inflight_writers,
            "quiesce_skipped": dict(retrieval_engine._quiesce_skipped),
        }
    except Exception:
        pass

    # MONITOR-163: expose TF-IDF refresh-drain status for the out-of-process monitor.
    try:
        from app.retrieval.refresh_drain import get_drain_status

        status["tfidf_refresh_drain"] = get_drain_status()
    except Exception:
        pass

    try:
        from app.retrieval.lifecycle_index_drain import get_lifecycle_index_outbox_status

        status["lifecycle_index_outbox"] = get_lifecycle_index_outbox_status()
    except Exception as exc:
        status["lifecycle_index_outbox"] = {
            "status": "critical",
            "alert": True,
            "worker_running": False,
            "latest_error": _safe_error(exc),
        }

    return status


# --- OPS-080: Consumer Status Endpoint ---


@app.get("/status")
def status_endpoint():
    """Public status endpoint showing tier, features, maintenance, and auth state.

    No auth required — returns non-sensitive operational metadata only.
    """
    from app.core.config import (
        EDGE_LLM_RECLASSIFICATION_ENABLED,
        FEATURE_FLAGS,
        KA_LLM_RECLASSIFICATION_ENABLED,
        LLM_TIER,
    )
    from app.ops.maintenance_scheduler import (
        MAINTENANCE_INTERVAL_SECONDS,
        _circuit_open,
        _consecutive_failures,
        _scheduler_task,
    )

    # Read heartbeat if available
    scheduler_status = "unknown"
    try:
        from app.core.profile import resolve_data_dir

        heartbeat_path = Path(resolve_data_dir()) / "maintenance_heartbeat.json"
        if heartbeat_path.exists():
            import json

            hb = json.loads(heartbeat_path.read_text())
            scheduler_status = hb.get("status", "unknown")
    except Exception:
        pass

    # LLM feature summary
    llm_features = {
        "tier3_extraction": FEATURE_FLAGS.get("TIER3_LLM_EXTRACTION_ENABLED", False),
        "experiment_resolution": FEATURE_FLAGS.get("LLM_EXPERIMENT_RESOLUTION_ENABLED", False),
        "contradiction_tier2": FEATURE_FLAGS.get("LLM_CONTRADICTION_TIER2_ENABLED", False),
        "edge_reclassification": EDGE_LLM_RECLASSIFICATION_ENABLED,
        "ka_reclassification": KA_LLM_RECLASSIFICATION_ENABLED,
    }

    return {
        "llm_tier": LLM_TIER,
        "llm_tier_label": {0: "offline", 1: "commodity", 2: "frontier"}.get(LLM_TIER, "unknown"),
        "llm_features": llm_features,
        "auth": {
            "api_key_set": bool(API_KEY),
            "auto_generated": "PITH_API_KEY" not in (os.environ.get("_PITH_ORIGINAL_ENV", "")),
        },
        "maintenance": {
            "scheduler_active": _scheduler_task is not None and not _scheduler_task.done()
            if _scheduler_task
            else False,
            "scheduler_status": scheduler_status,
            "interval_seconds": MAINTENANCE_INTERVAL_SECONDS,
            "circuit_open": _circuit_open,
            "consecutive_failures": _consecutive_failures,
        },
        "server_version": SERVER_VERSION,
    }


# --- RETRIEVAL-019: Evolution Backfill Endpoints ---


@app.post("/backfill/run", dependencies=[Depends(verify_api_key)])
async def backfill_run(request: Request, body: dict = {}):
    """Run evolution backfill for a knowledge area.

    Body params:
        knowledge_area (str): Target KA to process (required)
        dry_run (bool): If true, evaluate but don't commit (default: false)
        window_days (int): Max age gap between pairs (default: 14)
        auto_commit (bool): Auto-commit approved pairs (default: true)
    """
    from app.ops.backfill import run_backfill

    knowledge_area = body.get("knowledge_area")
    if not knowledge_area:
        raise HTTPException(status_code=400, detail="knowledge_area is required")

    result = run_backfill(
        knowledge_area=knowledge_area,
        dry_run=body.get("dry_run", False),
        window_days=body.get("window_days", 14),
        auto_commit=body.get("auto_commit", True),
    )

    return {
        "batch_id": result.batch_id,
        "knowledge_area": result.knowledge_area,
        "phase": result.phase,
        "candidates_generated": result.candidates_generated,
        "pairs_evaluated": result.pairs_evaluated,
        "auto_approved": result.auto_approved,
        "manual_review": result.manual_review,
        "auto_rejected": result.auto_rejected,
        "committed": result.committed,
        "exec_rejected": result.exec_rejected,
        "duration_ms": round(result.duration_ms, 1),
        "errors": result.errors,
    }


@app.get("/backfill/status", dependencies=[Depends(verify_api_key)])
def backfill_status(batch_id: str):
    """Get status summary for a backfill batch."""
    from app.ops.backfill import get_batch_status

    return get_batch_status(batch_id)


@app.post("/backfill/rollback", dependencies=[Depends(verify_api_key)])
async def backfill_rollback(request: Request, body: dict = {}):
    """Rollback a committed backfill batch."""
    from app.ops.backfill import rollback_batch

    batch_id = body.get("batch_id")
    if not batch_id:
        raise HTTPException(status_code=400, detail="batch_id is required")

    count = rollback_batch(batch_id)
    return {"batch_id": batch_id, "rolled_back": count}


# --- THREAD-004: Thread Reorganization Endpoints ---


@app.post("/thread_reorg/mine", dependencies=[Depends(verify_api_key)])
def thread_reorg_mine(body: dict = {}):
    from app.ops.thread_reorg import mine_active_thread

    _require_thread_reorg_ready(require_retrieval_ready=True)
    _acquire_thread_reorg_slot()
    try:
        result = mine_active_thread(body.get("source_thread_id"))
        include_merge_decisions = bool(body.get("include_merge_decisions", False))
        return {
            "status": "ok",
            "source_thread_id": result.source_thread_id,
            "source_thread_title": result.source_thread_title,
            "resolved_count": result.resolved_count,
            "stale_concept_ids": result.stale_concept_ids,
            "cluster_count": result.cluster_count,
            "clusters": result.clusters,
            "candidate_stats": result.candidate_stats,
            "deferred_singletons": result.deferred_singletons,
            "percentile_snapshot": result.percentile_snapshot,
            "merge_decision_count": len(result.merge_decisions),
            "merge_decisions_truncated": not include_merge_decisions,
            "merge_decisions": result.merge_decisions if include_merge_decisions else [],
        }
    finally:
        _HEAVY_ENDPOINT_SEMAPHORE.release()


@app.post("/thread_reorg/batch/preview", dependencies=[Depends(verify_api_key)])
def thread_reorg_batch_preview(body: dict):
    from app.ops.thread_reorg import preview_batch

    _require_thread_reorg_ready(require_write=True)
    _acquire_thread_reorg_slot()
    try:
        if not body.get("source_thread_id"):
            raise HTTPException(400, "source_thread_id is required")
        if not body.get("clusters"):
            raise HTTPException(400, "clusters are required")
        payload = preview_batch(
            source_thread_id=body["source_thread_id"],
            clusters=body["clusters"],
            evaluation_set_id=body.get("evaluation_set_id"),
            max_batch_size=body.get("max_batch_size"),
        )
        payload["batch_status"] = payload.pop("status")
        return {
            "status": "ok",
            **payload,
        }
    finally:
        _HEAVY_ENDPOINT_SEMAPHORE.release()


@app.post("/thread_reorg/batch/preview_residual", dependencies=[Depends(verify_api_key)])
def thread_reorg_batch_preview_residual(body: dict):
    from app.ops.thread_reorg import preview_deferred_review_batch

    _require_thread_reorg_ready(require_write=True, require_retrieval_ready=True)
    _acquire_thread_reorg_slot()
    try:
        if not body.get("source_thread_id"):
            raise HTTPException(400, "source_thread_id is required")
        try:
            payload = preview_deferred_review_batch(
                source_thread_id=body["source_thread_id"],
                bucket_ids=body.get("bucket_ids"),
                evaluation_set_id=body.get("evaluation_set_id"),
                max_batch_size=body.get("max_batch_size"),
            )
        except ValueError as exc:
            detail = str(exc)
            if detail in {
                "No deferred singleton buckets available for review",
                "No deferred bucket concepts passed the residual review quality gates",
            }:
                raise HTTPException(409, detail) from exc
            raise HTTPException(400, detail) from exc
        payload["batch_status"] = payload.pop("status")
        return {
            "status": "ok",
            **payload,
        }
    finally:
        _HEAVY_ENDPOINT_SEMAPHORE.release()


@app.post("/thread_reorg/batch/commit", dependencies=[Depends(verify_api_key)])
def thread_reorg_batch_commit(body: dict):
    from app.ops.thread_reorg import commit_batch

    _require_thread_reorg_ready(require_write=True)
    _acquire_thread_reorg_slot()
    try:
        batch_id = body.get("batch_id")
        if not batch_id:
            raise HTTPException(400, "batch_id is required")
        try:
            payload = commit_batch(batch_id)
        except ValueError as exc:
            if str(exc) == "THREAD_REORG_BATCH_WRITE_ENABLED is disabled":
                raise HTTPException(409, "thread reorg batch commit is disabled on this runtime") from exc
            raise
        payload["batch_status"] = payload.pop("status")
        return {"status": "ok", **payload}
    finally:
        _HEAVY_ENDPOINT_SEMAPHORE.release()


@app.get("/thread_reorg/batch/status", dependencies=[Depends(verify_api_key)])
def thread_reorg_batch_status(batch_id: str, include_members: bool = False, member_limit: int = 100):
    from app.ops.thread_reorg import get_batch_status

    payload = get_batch_status(batch_id, include_members=include_members, member_limit=member_limit)
    payload["batch_status"] = payload.pop("status")
    return {"status": "ok", **payload}


@app.post("/thread_reorg/batch/rollback", dependencies=[Depends(verify_api_key)])
def thread_reorg_batch_rollback(body: dict):
    from app.ops.thread_reorg import rollback_batch

    _require_thread_reorg_ready(require_write=True)
    _acquire_thread_reorg_slot()
    try:
        batch_id = body.get("batch_id")
        if not batch_id:
            raise HTTPException(400, "batch_id is required")
        payload = rollback_batch(batch_id)
        payload["batch_status"] = payload.pop("status")
        return {"status": "ok", **payload}
    finally:
        _HEAVY_ENDPOINT_SEMAPHORE.release()


# --- Phase 1A: Forgetting Recovery (Spec deviation — not in any spec) ---


@app.post("/pith_recover", dependencies=[Depends(verify_api_key)])
def pith_recover(concept_id: str):
    """Restore an archived (forgotten) concept back to active graph.

    Forgetting archives concepts, but recovery must always be possible.
    Archived concepts are never deleted.
    """
    if restore_concept(concept_id):
        retrieval_engine.build_index()  # Re-include in search
        return {
            "status": "restored",
            "concept_id": concept_id,
            "message": f"Concept {concept_id} restored from archive to active graph",
        }
    raise HTTPException(status_code=404, detail=f"Concept {concept_id} not found in archive")


@app.get("/pith_archived")
def pith_list_archived():
    """List all archived (forgotten) concepts."""
    archived = list_archived_concepts()
    return {"archived_count": len(archived), "concept_ids": archived}


@app.get("/pith_introspect")
def pith_introspect(mode: str = "summary", update: bool = False):
    """Return cognitive self-assessment.

    Modes:
      summary          — identity, health, top_strengths, weakest_areas, recent_errors
      full             — complete SelfModel object
      capability_check — CognitiveCapabilityInventory only
      epistemic_check  — EpistemicProfile only

    Latency targets:
      update=false: <200ms (cached read)
      update=true:  <500ms (recompute from live data, any mode)

    Phase 1A deviations:
      - 'weakest_areas' replaces 'top_gaps' (blind_spots is stubbed)
      - 'recent_errors' returns empty (error_history is stubbed)
    """
    if mode not in ("summary", "full", "capability_check", "epistemic_check"):
        raise HTTPException(
            status_code=400, detail=f"Invalid mode '{mode}'. Use: summary, full, capability_check, epistemic_check"
        )
    try:
        # PERF-077: Pre-load concepts via read_snapshot_db to avoid O(N) writer-lock
        # contention in introspect fallback path. Only needed when update=True
        # triggers SelfModel regeneration from live concept data.
        from app.storage.concepts import list_concepts_full

        concepts = list_concepts_full() if update else None
        return self_model_manager.introspect(mode=mode, update=update, concepts=concepts)
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.post("/pith_activate_context", dependencies=[Depends(verify_api_key)])
def pith_activate_context(context: str, boost: float = 0.5):
    """
    Activate concepts based on current context.

    Pre-loads related concepts for faster retrieval.
    """
    try:
        predictive_activation.activate_from_context(context, boost)
        active = predictive_activation.get_active_concepts()
        return {"activated": len(active), "concepts": [{"concept_id": cid, "activation": act} for cid, act in active]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.get("/pith_activation_state")
def pith_activation_state():
    """Get current activation state."""
    try:
        state = predictive_activation.get_activation_state()
        return state
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.post("/pith_set_goal", dependencies=[Depends(verify_api_key)])
def pith_set_goal(goal: str, context: dict = None):
    """
    Set current goal for goal-directed retrieval.

    Goals: improve_process, solve_problem, understand_system,
           make_decision, learn_topic, plan_project, etc.
    """
    try:
        goal_directed.set_goal(goal, context or {})
        return {"status": "goal_set", "goal": goal, "message": f"Goal '{goal}' activated for retrieval boosting"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.post("/pith_clear_goal", dependencies=[Depends(verify_api_key)])
def pith_clear_goal():
    """Clear the current goal."""
    try:
        goal_directed.clear_goal()
        return {"status": "goal_cleared"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.get("/pith_predict_next")
def pith_predict_next(current_concepts: list[str], num_predictions: int = 5):
    """
    Predict which concepts are likely to be needed next.

    Based on activation patterns and associations.
    """
    try:
        predictions = predictive_activation.predict_next_concepts(current_concepts, num_predictions)
        return {"predictions": predictions, "count": len(predictions)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.post("/pith_reset_activation", dependencies=[Depends(verify_api_key)])
def pith_reset_activation():
    """Reset all concept activations (new session/context)."""
    try:
        predictive_activation.reset()
        return {"status": "reset", "message": "All activations cleared"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.post("/pith_import_conversation", dependencies=[Depends(verify_api_key)])
def pith_import_conversation(
    conversation_text: str, source_id: str = "manual_import", knowledge_area: str = "imported", chunk_size: int = 200
):
    """
    Import and learn from a historical conversation.

    Processes conversation text and extracts learnable concepts.
    """
    try:
        result = conversation_processor.process_conversation(
            conversation_text=conversation_text,
            source_id=source_id,
            knowledge_area=knowledge_area,
            chunk_size=chunk_size,
        )

        # Rebuild index after import
        retrieval_engine.build_index()

        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.post("/pith_import_batch", dependencies=[Depends(verify_api_key)])
def pith_import_batch(conversations: list[dict], knowledge_area: str = "imported"):
    """
    Import multiple conversations in batch.

    Uses conversation_processor.process_batch() which writes directly to storage
    via create_concept() — does NOT go through session_learn, so rate limits and
    daily budgets do not apply. INGEST-042 audit confirmed the original INGEST-023
    rate elevation here was dead code (process_batch never calls session_learn).

    Args:
        conversations: List of {"text": str, "source_id": str} dicts
        knowledge_area: Knowledge area for imported concepts

    Returns:
        Batch processing summary
    """
    try:
        logger.info(f"pith_import_batch: processing {len(conversations)} conversations")

        result = conversation_processor.process_batch(conversations=conversations, knowledge_area=knowledge_area)

        # Rebuild index after batch import
        retrieval_engine.build_index()

        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.get("/pith_import_stats")
def pith_import_stats():
    """Get retrospective import statistics."""
    try:
        stats = conversation_processor.get_stats()
        return stats
    except Exception as e:
        raise HTTPException(status_code=500, detail=_safe_error(e))


# ============================================
# Conversation Import Pipeline (v2)
# ============================================


@app.post("/pith_import_file", dependencies=[Depends(verify_api_key)])
def pith_import_file(
    file_path: str,
    source: str,
    skip_report: bool = False,
    resume: bool = False,
):
    """Import conversation history from ChatGPT/Claude export files.

    Full pipeline: parse → normalize → bulk import → report generation.
    Spec: CONVERSATION_IMPORT_PIPELINE_v2.md (gauntlet 8.5/10 PASS)
    """
    from pathlib import Path as _Path

    from app.ops.import_pipeline import run_import_pipeline

    try:
        from app.core.profile import resolve_data_dir

        checkpoint_dir = _Path(resolve_data_dir()) / "import_checkpoints"
        result = run_import_pipeline(
            file_path=file_path,
            source=source,
            skip_report=skip_report,
            resume=resume,
            checkpoint_dir=checkpoint_dir,
        )
        # Rebuild index after import
        retrieval_engine.build_index()
        return result
    except (ValueError, FileNotFoundError) as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"pith_import_file error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.post("/pith_import_cancel", dependencies=[Depends(verify_api_key)])
def pith_import_cancel():
    """Cancel an in-progress import."""
    from app.ops.import_pipeline import cancel_import

    cancel_import()
    return {"status": "cancel_requested"}


# ============================================
# KA-ARCH-001: Dynamic KA Hints Endpoint
# ============================================


@app.get("/pith_ka_hints")
def pith_ka_hints(max_hints: int = 12) -> dict:
    """Get dynamic KA vocabulary hints for extraction prompts.

    Returns the user's most active knowledge areas, ordered by maturity
    and concept count. Use these hints in extraction prompts to align
    vocabulary with the user's established domain language.

    KA-ARCH-001 Fix 9: Adaptive extraction primitive.
    """
    try:
        from app.cognitive.taxonomy import get_ka_hints

        hints = get_ka_hints(max_hints)
        return {"ka_hints": hints, "count": len(hints)}
    except Exception as e:
        logger.error(f"pith_ka_hints failed: {e}")
        return {"ka_hints": ["knowledge", "workflow", "relationships", "context", "goals", "observations"], "count": 6}


# ============================================
# PITH INTEGRATION ENDPOINTS
# ============================================


@app.get("/knowledge_areas")
def list_knowledge_areas_endpoint() -> dict[str, Any]:
    """List all knowledge areas with concept counts."""
    return _build_knowledge_areas_cached()


@app.get("/knowledge_areas/{area_name}")
def get_knowledge_area_concepts(area_name: str) -> dict[str, Any]:
    """Get all concepts in a specific knowledge area."""
    from app.storage import list_concepts_for_knowledge_area

    area_concepts = list_concepts_for_knowledge_area(area_name)
    if not area_concepts:
        raise HTTPException(status_code=404, detail=f"Knowledge area '{area_name}' not found")

    return {"area": area_name, "concept_count": len(area_concepts), "concepts": area_concepts}


@app.post("/pith_suggest_associations", dependencies=[Depends(verify_api_key)])
def suggest_associations(concept_id: str, max_suggestions: int = 5) -> list[dict]:
    """Suggest potential associations based on semantic similarity."""
    concept = load_concept(concept_id, track_access=False)
    if not concept:
        raise HTTPException(status_code=404, detail=f"Concept {concept_id} not found")

    query = SearchQuery(query=concept.summary, max_results=max_suggestions + 1)
    results = retrieval_engine.search(query)

    suggestions = []
    for result in results:
        if result.concept_id != concept_id:
            source_ka = concept.metadata.get("knowledge_area", "unknown")
            target_ka = result.knowledge_area or "unknown"

            if source_ka == target_ka:
                relation = "related_to"
                reasoning = f"Both in {source_ka} knowledge area"
            else:
                relation = "related_to"
                reasoning = f"Cross-domain: {source_ka} <-> {target_ka}"

            suggestions.append(
                {
                    "concept_id": result.concept_id,
                    "similarity_score": round(result.relevance_score, 2),
                    "suggested_relation": relation,
                    "reasoning": reasoning,
                }
            )

    return suggestions[:max_suggestions]


@app.get("/pith_concept_timeline")
def concept_timeline(limit: int = 20) -> list[dict]:
    """Get recent concept creation timeline."""
    all_concepts = list_concepts_full()  # Single bulk query — no N+1
    timeline = []

    for concept in all_concepts:
        timeline.append(
            {
                "id": concept.id,
                "created_at": concept.created_at,
                "knowledge_area": concept.metadata.get("knowledge_area", "unknown"),
                "confidence": concept.confidence,
                "summary": concept.summary[:100] + "..." if len(concept.summary) > 100 else concept.summary,
            }
        )

    timeline.sort(key=lambda x: x["created_at"], reverse=True)
    return timeline[:limit]


@app.get("/pith_search_suggestions")
def search_suggestions(query: str, limit: int = 5) -> list[str]:
    """Get search query suggestions based on existing concepts."""
    with request_db_scope("pith_search_suggestions"):
        if _read_only_aggregates_enabled():
            try:
                with read_snapshot_db("pith_search_suggestions") as conn:
                    all_concepts = list_concepts_full(conn=conn)
            except Exception as snap_err:
                if not _read_only_aggregates_fallback_allowed():
                    raise
                logger.warning(
                    "read-only snapshot failed for /pith_search_suggestions, falling back: %s",
                    snap_err,
                )
                all_concepts = list_concepts_full()
        else:
            all_concepts = list_concepts_full()  # Single bulk query — no N+1
        suggestions = set()
        query_lower = query.lower()

        for concept in all_concepts:
            ka = concept.metadata.get("knowledge_area", "")
            if query_lower in ka.lower():
                suggestions.add(ka)
            if query_lower in concept.id.lower():
                suggestions.add(concept.id.replace("_", " "))
            if len(suggestions) >= limit * 2:
                break

        return sorted(list(suggestions))[:limit]


# ============================================================
# Auto-Association Endpoints (Phase 1.3)
# ============================================================


@app.post("/auto_associate_batch", dependencies=[Depends(verify_api_key)])
def auto_associate_batch_endpoint(request: AutoAssociateBatchRequest = None):
    """Run batch auto-association pipeline across all active concepts.

    Two-tier strategy:
      Tier 1 — cosine similarity above tier1_threshold (default 0.18)
      Tier 2 — lower cosine + same knowledge_area for remaining orphans

    All parameters optional with sensible defaults. Use dry_run=true to preview.
    """
    if request is None:
        request = AutoAssociateBatchRequest()
    try:
        result = auto_associate_batch(request, invocation_source="api")
        return result.model_dump()
    except Exception as e:
        logger.error(f"auto_associate_batch error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=_safe_error(e))


@app.post("/auto_associate/{concept_id}", dependencies=[Depends(verify_api_key)])
def auto_associate_single_endpoint(concept_id: str, request: AutoAssociateSingleRequest = None):
    """Auto-associate a single concept with its nearest neighbors.

    Finds similar concepts via TF-IDF cosine similarity and creates
    'related_to' edges for matches above the threshold.
    """
    if request is None:
        request = AutoAssociateSingleRequest()
    try:
        result = auto_associate_single(concept_id, request)
        if not result.matches and result.edges_created == 0:
            concept = load_concept(concept_id, track_access=False)
            if not concept:
                raise HTTPException(status_code=404, detail=f"Concept {concept_id} not found")
        return result.model_dump()
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"auto_associate_single error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=_safe_error(e))


# ============================================================
# Session Middleware (Phase 1A D7)
# ============================================================


@app.get("/pith_orient")
def pith_orient(
    time_window: str = "7_days",
    include_threads: bool = True,
    include_recommendations: bool = True,
    force_refresh: bool = False,
    include_workstreams: bool = False,
    workstream_limit: int = 8,
    origin_id: str | None = None,
    session_id: str | None = None,
):
    """Generate present moment orientation.

    Returns where-been, where-am, where-going for session bootstrap.
    """
    valid_windows = {"1_day", "7_days", "30_days", "all"}
    if time_window not in valid_windows:
        raise HTTPException(status_code=400, detail=f"Invalid time_window. Must be one of: {valid_windows}")

    payload = _pith_orient_base_payload(
        time_window=time_window,
        force_refresh=force_refresh,
    )
    if include_workstreams:
        payload = _pith_orient_payload_with_workstreams(
            payload,
            workstream_limit=workstream_limit,
            origin_id=origin_id,
            session_id=session_id,
        )
    else:
        payload.pop("workstreams", None)
    return payload


@app.post("/session_start", dependencies=[Depends(verify_api_key)])
def session_start(body: dict = None):
    """Bootstrap session with single concept load.

    Returns introspect summary + orientation in one call.
    """
    context_hint = ""
    agent_id = "default"
    platform_hint = "unknown"  # SESSION-012 v0.3
    surface_id = "unknown"
    if body and isinstance(body, dict):
        context_hint = body.get("context_hint", "")
        agent_id = body.get("agent_id", "default")
        platform_hint = body.get("platform_hint", "unknown")
        surface_id = body.get("surface_id", "unknown")

    result = session_manager.start_session(
        context_hint=context_hint,
        agent_id=agent_id,
        platform_hint=platform_hint,
        surface_id=surface_id,
    )
    # start_session now returns dict (with optional active_checkpoint attached)
    if hasattr(result, "model_dump"):
        return result.model_dump()
    return result


@app.post("/session_end", dependencies=[Depends(verify_api_key)])
async def session_end(request: Request):
    """End current session. Optionally accepts last-exchange data for flush.
    Flushes access tracker, triggers reflection if learning_event_count >= threshold."""
    from app.ops.metrics import metrics as _se_metrics

    with _se_metrics.timer("session_end_latency_ms"):
        start = time.perf_counter()
        body = None
        end_request = None
        request_id = None
        try:
            body = await request.json()
        except Exception:
            body = None

        recognized_fields = {
            "request_id",
            "session_id",
            "binding",
            "binding_generation",
            "origin_id",
            "previous_response",
            "previous_message",
            "extracted_concepts_json",
            "agent_id",
        }
        if body and isinstance(body, dict):
            request_id = body.get("request_id")
            if any(key in body for key in recognized_fields):
                try:
                    end_request = SessionEndRequest(**body)
                except ValidationError as exc:
                    raise HTTPException(
                        status_code=400,
                        detail=_redact_request_validation_errors(exc.errors(include_context=False)),
                    ) from exc

        request_id = _ensure_session_end_request_id(request_id)
        if end_request is not None and end_request.request_id != request_id:
            end_request = end_request.model_copy(update={"request_id": request_id})
        request_payload = dict(body) if isinstance(body, dict) else {}
        request_payload["request_id"] = request_id

        if end_request is not None and end_request.binding is not None:
            from app.core.profile import get_active_profile
            from app.session.binding import ManagedBindingError, request_managed_close

            try:
                _require_managed_session_end_runtime(end_request)
                profile = get_active_profile()

                def _begin_managed_close_replay(conn, context):
                    return begin_write_request(
                        "session_end",
                        request_id,
                        request_payload=end_request.model_dump(mode="json"),
                        authority=ManagedReplayAuthority(
                            profile=context.profile,
                            binding_hash=context.binding_hash,
                            session_id=context.session_id,
                        ),
                        conn=conn,
                    )

                close = request_managed_close(
                    end_request,
                    profile=profile,
                    reason="explicit",
                    now=datetime.now(UTC),
                    begin_replay=_begin_managed_close_replay,
                )
                replay_state = close.pop("_replay_state", None)
                if close.get("replay") is not None:
                    return close["replay"]
                if close.get("status") == "already_terminal":
                    terminal_phase = str(close.get("lifecycle_phase") or "ended")
                    terminal_payload = {
                        "status": terminal_phase,
                        "session_id": close["session_id"],
                        "binding_generation": close["binding_generation"],
                        "lifecycle_phase": terminal_phase,
                        "final_learning_state": ("committed" if terminal_phase == "ended" else "needs_attention"),
                        "_protocol": {
                            "binding_mode": "managed",
                            "binding_protocol_version": end_request.binding.protocol_version,
                            "binding_generation": close["binding_generation"],
                            "lifecycle_phase": terminal_phase,
                        },
                    }
                    return _commit_session_end_result(
                        request_id,
                        terminal_payload,
                        replay_state=replay_state,
                    )
                _submit_managed_session_end_drain()
                payload = _session_end_processing_payload(
                    request_id,
                    processing_time_ms=(time.perf_counter() - start) * 1000,
                )
                payload["_protocol"] = {
                    "binding_mode": "managed",
                    "binding_protocol_version": end_request.binding.protocol_version,
                    "binding_generation": close["binding_generation"],
                    "lifecycle_phase": "closing",
                }
                return payload
            except HTTPException as exc:
                duplicate = exc.status_code == 409 and (
                    exc.detail == "Duplicate write request is already processing"
                    or (isinstance(exc.detail, dict) and exc.detail.get("error") == "managed_replay_already_processing")
                )
                if duplicate:
                    payload = _session_end_processing_payload(
                        request_id,
                        processing_time_ms=(time.perf_counter() - start) * 1000,
                    )
                    payload["_protocol"] = {
                        "binding_mode": "managed",
                        "binding_protocol_version": end_request.binding.protocol_version,
                        "binding_generation": end_request.binding_generation,
                        "lifecycle_phase": "closing",
                    }
                    return payload
                raise
            except ManagedBindingError as exc:
                headers = {"Retry-After": "1"} if exc.status_code in {423, 503} else None
                raise HTTPException(
                    status_code=exc.status_code,
                    detail={"error": exc.code, "request_id": request_id},
                    headers=headers,
                ) from exc

        try:
            replay_state = begin_write_request("session_end", request_id, request_payload=request_payload)
        except HTTPException as exc:
            if exc.status_code == 409:
                return _session_end_processing_payload(
                    request_id,
                    processing_time_ms=(time.perf_counter() - start) * 1000,
                )
            raise
        if replay_state.replay is not None:
            return replay_state.replay

        future = _get_session_learn_executor().submit(lambda: session_manager.end_session(end_request))
        try:
            result = future.result(timeout=_remaining_session_learn_sync_wait(start))
            return _commit_session_end_result(request_id, result)
        except concurrent.futures.TimeoutError:
            future.add_done_callback(lambda done_future: _finalize_deferred_session_end(done_future, request_id))
            _record_session_learn_contract_metric("session_end_deferred")
            _schedule_write_replay_reclaimer("session_end", "deferred_session_end")
            return _session_end_processing_payload(
                request_id,
                processing_time_ms=(time.perf_counter() - start) * 1000,
            )
        except Exception as exc:
            abandon_write_request("session_end", request_id, error_class=type(exc).__name__)
            raise


def _ensure_conversation_turn_request_id(
    request: ConversationTurnRequest,
) -> tuple[ConversationTurnRequest, str]:
    request_id = request.request_id or new_conversation_turn_request_id()
    if request.request_id == request_id:
        return request, request_id
    try:
        request.request_id = request_id
        return request, request_id
    except Exception:
        return request.model_copy(update={"request_id": request_id}), request_id


def _conversation_turn_http_exception(
    exc: HTTPException,
    request_id: str,
) -> HTTPException:
    headers = dict(exc.headers or {})
    headers["X-Pith-Request-Id"] = request_id
    detail = exc.detail
    if isinstance(detail, dict):
        detail = {**detail, "request_id": request_id}
    return HTTPException(status_code=exc.status_code, detail=detail, headers=headers)


def _prepare_managed_conversation_turn_binding(request, context) -> dict[str, Any]:
    """Push the exact episode selected by the managed binding gateway."""

    if request.binding is None or request.session_id != context.session_id:
        from app.session.binding import ManagedBindingError

        raise ManagedBindingError("binding_context_mismatch")
    session = session_manager._session_info_from_row(load_session(context.session_id))
    if session is None or session.status != "active":
        from app.session.binding import ManagedBindingError

        raise ManagedBindingError("managed_episode_changed")
    session_token, active_token = session_manager._push_request_session(session)
    return {
        "session_token": session_token,
        "active_token": active_token,
        "bind_status": "bound",
        "binding_source": "managed_binding",
        "resolved_session_id": context.session_id,
    }


def _require_managed_conversation_turn_runtime(request: ConversationTurnRequest) -> None:
    """Fail closed before admission when prior-turn work cannot be durably run."""

    if not request.previous_response or len(request.previous_response) < 30:
        return
    from app.session.binding import ManagedBindingError
    from app.session.lifecycle_jobs_runtime import lifecycle_job_runner_registered

    if (
        not _cfg.LIFECYCLE_JOBS_ENABLED
        or not _cfg.get_feature_flag("BACKGROUND_AUTOLEARN_ENABLED", True)
        or not lifecycle_job_runner_registered("conversation_turn")
    ):
        raise ManagedBindingError(
            "managed_post_response_registration_unavailable",
            status_code=503,
        )


@app.post("/conversation_turn", dependencies=[Depends(verify_api_key)])
def conversation_turn_endpoint(
    request: ConversationTurnRequest,
    background_tasks: BackgroundTasks,
    x_pith_transport: str | None = Header(None),
):
    """Pre-response context activation. Given a user message, find and return
    the most relevant existing knowledge. Read-only. Target: <50ms."""
    request, request_id = _ensure_conversation_turn_request_id(request)
    is_hook_additional_context = request.context_delivery_mode == "hook_additional_context"
    acquired = False
    acquired_hook = False
    binding = None
    managed_context = None
    managed_guard = None
    managed_shadow = None
    try:
        if getattr(app.state, "startup_task", None) is not None:
            _require_retrieval_ready("conversation_turn")
        if is_hook_additional_context:
            acquired_hook = _HOOK_ADDITIONAL_CONTEXT_SEMAPHORE.acquire(timeout=HOOK_ADDITIONAL_CONTEXT_TIMEOUT_S)
            if not acquired_hook:
                raise HTTPException(
                    status_code=503,
                    detail="Pith hook context lane saturated - try again shortly",
                    headers={"Retry-After": "1"},
                )
        else:
            acquired = _HEAVY_ENDPOINT_SEMAPHORE.acquire(timeout=HEAVY_ENDPOINT_TIMEOUT_S)
            if not acquired:
                raise HTTPException(
                    status_code=503,
                    detail="Server under heavy load — try again in a few seconds",
                    headers={"Retry-After": "3"},
                )
        request.transport_mode = x_pith_transport
        if request.binding is not None:
            from app.core.profile import get_active_profile
            from app.session.binding import observe_managed_shadow_turn, resolve_managed_turn

            profile = get_active_profile()
            managed_shadow = observe_managed_shadow_turn(request, profile=profile)
            if managed_shadow is not None:
                # Capability material is needed only for the read-only shadow
                # validation above; keep it out of the legacy request pipeline.
                request.binding = None
                binding = session_manager.prepare_conversation_turn_binding(request)
            else:
                _require_managed_conversation_turn_runtime(request)
                managed_context, managed_guard = resolve_managed_turn(
                    request,
                    profile=profile,
                    now=datetime.now(UTC),
                )
                request.session_id = managed_context.session_id
                binding = _prepare_managed_conversation_turn_binding(
                    request,
                    managed_context,
                )
        else:
            binding = session_manager.prepare_conversation_turn_binding(request)
        if managed_context is not None:
            from app.session.binding import managed_episode_context

            with managed_episode_context(managed_context):
                result = session_manager.conversation_turn(request)
        else:
            result = session_manager.conversation_turn(request)
        result.request_id = request_id
        result.bind_status = binding["bind_status"]
        result.binding_source = binding["binding_source"]
        result.resolved_session_id = binding["resolved_session_id"]
        session_active = bool(binding["bind_status"] == "bound" and binding["resolved_session_id"])
        session_active_source = (
            "server_binding_bound_with_resolved_session_id"
            if session_active
            else "server_binding_unbound_or_missing_session"
        )
        result.session_active = session_active
        result.session_active_source = session_active_source
        result.auth_error = None
        if binding["bind_status"] == "unbound":
            result.working_context = None
            result.checkpoint_resume_available = False
        if managed_context is not None:
            from app.session.binding import (
                build_managed_post_response_plan,
                register_managed_post_response_plan,
            )

            managed_plan = build_managed_post_response_plan(
                result,
                context=managed_context,
            )
            managed_autolearn_registered = register_managed_post_response_plan(
                managed_plan,
                response=result,
            )
            if managed_autolearn_registered:
                background_tasks.add_task(_submit_managed_conversation_turn_drain)
            dedup_key = getattr(result, "_pending_turn_dedup_key", None)
            if dedup_key:
                object.__setattr__(
                    result,
                    "_pending_turn_dedup_key",
                    f"{managed_context.binding_hash}:{dedup_key}",
                )
        # EUNOMIA-039 Fix 3: Dispatch global post-response work after response.
        background_tasks.add_task(session_manager.dispatch_post_response_tasks, result)
        payload = result.model_dump()
        payload["_protocol"] = {
            "request_id": request_id,
            "bind_status": result.bind_status,
            "binding_source": result.binding_source,
            "resolved_session_id": result.resolved_session_id,
            "session_active": result.session_active,
            "session_active_source": result.session_active_source,
            "auth_error": result.auth_error,
        }
        if managed_context is not None:
            payload["_protocol"].update(
                {
                    "binding_mode": "managed",
                    "binding_protocol_version": managed_context.protocol_version,
                    "binding_generation": managed_context.generation,
                    "lifecycle_phase": "active",
                }
            )
        elif managed_shadow is not None:
            payload["_protocol"].update(
                {
                    "binding_mode": "shadow",
                    "binding_protocol_version": managed_shadow.protocol_version,
                    "lifecycle_phase": "active",
                }
            )
        return payload
    except HTTPException as exc:
        raise _conversation_turn_http_exception(exc, request_id) from exc
    except Exception as exc:
        from app.governance.repo_hygiene_policy import RepoHygienePolicyError
        from app.session.binding import ManagedBindingError

        if isinstance(exc, ManagedBindingError):
            headers = {"Retry-After": "1"} if exc.status_code in {423, 503} else None
            http_exc = HTTPException(
                status_code=exc.status_code,
                detail={"error": exc.code},
                headers=headers,
            )
        elif isinstance(exc, RepoHygienePolicyError):
            http_exc = HTTPException(
                status_code=400,
                detail={
                    "error": exc.error_code,
                    "message": exc.detail,
                    "workspace_context": exc.workspace_context,
                },
            )
        elif exc.__class__.__name__ == "InvalidSessionBindingError":
            http_exc = HTTPException(
                status_code=404,
                detail={
                    "error": "invalid_session_id",
                    "message": str(exc),
                    "session_id": getattr(exc, "session_id", None),
                    "reason": getattr(exc, "reason", "invalid_session_id"),
                    "session_status": getattr(exc, "session_status", None),
                },
            )
        else:
            logger.error("conversation_turn error: %s", exc)
            http_exc = HTTPException(status_code=500, detail=_safe_error(exc))
        raise _conversation_turn_http_exception(http_exc, request_id) from exc
    finally:
        if binding is not None:
            session_manager._pop_request_session(
                binding["session_token"],
                binding["active_token"],
            )
        if managed_guard is not None:
            managed_guard.release()
        if acquired_hook:
            _HOOK_ADDITIONAL_CONTEXT_SEMAPHORE.release()
        if acquired:
            _HEAVY_ENDPOINT_SEMAPHORE.release()


def _get_session_learn_executor() -> concurrent.futures.ThreadPoolExecutor:
    """Return the bounded executor used for direct session_learn writes."""
    global _SESSION_LEARN_EXECUTOR
    if _SESSION_LEARN_EXECUTOR is None:
        with _SESSION_LEARN_EXECUTOR_LOCK:
            if _SESSION_LEARN_EXECUTOR is None:
                _SESSION_LEARN_EXECUTOR = concurrent.futures.ThreadPoolExecutor(
                    max_workers=_SESSION_LEARN_EXECUTOR_WORKERS,
                    thread_name_prefix="session_learn",
                )
    return _SESSION_LEARN_EXECUTOR


def _record_session_learn_contract_metric(metric: str) -> None:
    try:
        from app.ops.metrics import metrics as _sl_contract_metrics

        _sl_contract_metrics.record(metric, 1.0)
        _sl_contract_metrics.flush()
    except Exception:
        pass


def _record_session_learn_initial_response_latency(start: float, state: str) -> None:
    try:
        from app.ops.metrics import metrics as _sl_contract_metrics

        _sl_contract_metrics.record(
            "session_learn_initial_response_latency_ms",
            (time.perf_counter() - start) * 1000,
            {"state": state},
        )
        _sl_contract_metrics.flush()
    except Exception:
        pass


def _record_session_learn_lifecycle_latency(metric: str, start: float, labels: dict | None = None) -> None:
    try:
        from app.ops.metrics import metrics as _sl_lifecycle_metrics

        _sl_lifecycle_metrics.record(
            metric,
            (time.perf_counter() - start) * 1000,
            labels or {},
        )
        _sl_lifecycle_metrics.flush()
    except Exception:
        pass


def _remaining_session_learn_sync_wait(start: float) -> float:
    return max(0.0, _SESSION_LEARN_SYNC_WAIT_SECONDS - (time.perf_counter() - start))


def _ensure_session_learn_request_id(request: SessionLearnRequest) -> tuple[SessionLearnRequest, str]:
    request_id = request.request_id or f"sl_srv_{uuid.uuid4().hex[:16]}"
    if request.request_id == request_id:
        return request, request_id
    try:
        request.request_id = request_id
        return request, request_id
    except Exception:
        return request.model_copy(update={"request_id": request_id}), request_id


def _session_learn_processing_payload(request_id: str, *, processing_time_ms: float = 0.0) -> dict:
    response = SessionLearnResponse(
        concepts_created=[],
        concepts_evolved=[],
        associations_created=0,
        duplicates_skipped=0,
        concepts_skipped=0,
        errors=0,
        processing_time_ms=round(processing_time_ms, 2),
        learning_events=0,
        extraction_source_breakdown={},
        budget_warnings=["session_learn_processing: learning is still running; retry with the same request_id"],
        persistence_state="processing",
        processing_state="processing",
        request_id=request_id,
        retry_after_seconds=_SESSION_LEARN_PROCESSING_RETRY_AFTER_SECONDS,
    )
    return response.model_dump()


def _should_commit_structured_session_learn_fast_path(request: SessionLearnRequest) -> bool:
    """Structured client concepts are authoritative enough to persist immediately."""
    return bool(getattr(request, "extracted_concepts", None))


def _prepare_structured_session_learn_fast_path(request: SessionLearnRequest) -> None:
    request.replay_fast_path = True
    if not request.trigger_path or request.trigger_path == "unknown":
        request.trigger_path = "session_learn_structured_fast_path"


def _enqueue_session_learn_lifecycle_job(
    request: SessionLearnRequest,
    request_id: str,
    *,
    managed_context=None,
    replay_state: WriteReplayState | None = None,
) -> dict:
    from app.session.lifecycle_jobs_runtime import enqueue_session_learn_job, submit_lifecycle_drain

    enqueue_start = time.perf_counter()
    job = enqueue_session_learn_job(
        learn_request=request,
        request_id=request_id,
        priority=_SESSION_LEARN_LIFECYCLE_PRIORITY,
        managed_context=managed_context,
        replay_state=replay_state,
    )
    _record_session_learn_lifecycle_latency(
        "session_learn_lifecycle_enqueue_latency_ms",
        enqueue_start,
        {"status": str(job.get("status", "unknown"))},
    )
    submitted = submit_lifecycle_drain(
        run_job=_run_session_learn_lifecycle_job,
        reason="explicit_session_learn",
        limit=1,
        source="session_learn",
    )
    if submitted:
        _record_session_learn_contract_metric("session_learn_lifecycle_drain_submitted")
    else:
        _record_session_learn_contract_metric("session_learn_lifecycle_drain_already_running")
    return job


def _require_managed_session_learn_runtime(request: SessionLearnRequest) -> None:
    """Fail closed before managed learning admission if its runner is unavailable."""

    if request.binding is None:
        return
    from app.session.binding import ManagedBindingError
    from app.session.lifecycle_jobs_runtime import lifecycle_job_runner_registered

    if not _cfg.LIFECYCLE_JOBS_ENABLED or not lifecycle_job_runner_registered("session_learn"):
        raise ManagedBindingError(
            "managed_learning_registration_unavailable",
            status_code=503,
        )


def _managed_replay_state_from_job(job: dict, *, endpoint: str) -> WriteReplayState:
    payload = job.get("payload") or {}
    replay = payload.get("managed_replay") if isinstance(payload, dict) else None
    if not isinstance(replay, dict):
        raise ValueError(f"managed {endpoint} lifecycle job missing replay authority")
    external_request_id = str(replay.get("external_request_id") or "")
    storage_request_id = str(replay.get("storage_request_id") or "")
    request_hash = str(replay.get("request_hash") or "")
    claim_token = str(replay.get("claim_token") or "")
    binding_hash = str(job.get("binding_hash") or "")
    session_id = str(job.get("session_id") or "")
    if not all((external_request_id, storage_request_id, request_hash, claim_token, binding_hash, session_id)):
        raise ValueError(f"managed {endpoint} lifecycle replay authority is incomplete")
    return WriteReplayState(
        request_id=external_request_id,
        storage_request_id=storage_request_id,
        request_hash=request_hash,
        binding_hash=binding_hash,
        session_id=session_id,
        claim_token=claim_token,
    )


def _ensure_session_end_request_id(request_id: str | None) -> str:
    return request_id or f"se_srv_{uuid.uuid4().hex[:16]}"


def _require_managed_session_end_runtime(request: SessionEndRequest) -> None:
    """Fail closed before managed close admission if its runner is unavailable."""

    if request.binding is None:
        return
    from app.session.binding import ManagedBindingError
    from app.session.lifecycle_jobs_runtime import lifecycle_job_runner_registered

    if not _cfg.LIFECYCLE_JOBS_ENABLED or not lifecycle_job_runner_registered("session_end"):
        raise ManagedBindingError(
            "managed_close_registration_unavailable",
            status_code=503,
        )


def _session_end_processing_payload(request_id: str, *, processing_time_ms: float = 0.0) -> dict:
    return {
        "status": "processing",
        "persistence_state": "processing",
        "processing_state": "processing",
        "request_id": request_id,
        "retry_after_seconds": _SESSION_LEARN_PROCESSING_RETRY_AFTER_SECONDS,
        "final_learning_state": "processing",
        "processing_time_ms": round(processing_time_ms, 2),
        "budget_warnings": ["session_end_processing: closeout is still running; retry with the same request_id"],
    }


def _session_learn_stale_cutoff_iso() -> str:
    from app.api.write_durability import STALE_PROCESSING_TIMEOUT

    return (_utc_now() - STALE_PROCESSING_TIMEOUT).isoformat()


def _iso_age_seconds(value: str | None) -> int | None:
    if not value:
        return None
    try:
        from datetime import datetime

        return max(0, int((_utc_now() - _ensure_aware(datetime.fromisoformat(value))).total_seconds()))
    except Exception:
        return None


def _build_session_learn_queue_health() -> dict:
    try:
        from app.core.profile import get_active_profile
        from app.storage import summarize_write_request_processing

        stale_cutoff = _session_learn_stale_cutoff_iso()
        summary = summarize_write_request_processing(
            "session_learn",
            get_active_profile(),
            stale_cutoff,
            max_attempts=_SESSION_LEARN_RECLAIMER_MAX_ATTEMPTS,
        )
        stale_count = int(summary["stale_processing_count"])
        status = "warning" if stale_count else "ok"
        oldest_age = _iso_age_seconds(summary.get("oldest_processing_updated_at"))
        stale_age = _iso_age_seconds(summary.get("oldest_stale_updated_at"))
        return {
            "status": status,
            "alert": stale_count > 0,
            "stale_threshold_seconds": int(_cfg.WRITE_STALE_MINUTES * 60),
            "processing_count": int(summary["processing_count"]),
            "stale_processing_count": stale_count,
            "recoverable_stale_count": int(summary["recoverable_stale_count"]),
            "unrecoverable_stale_count": int(summary["unrecoverable_stale_count"]),
            "oldest_processing_age_seconds": oldest_age,
            "oldest_stale_age_seconds": stale_age,
            "oldest_stale_request_id": summary.get("oldest_stale_request_id"),
            "max_attempts_exhausted_count": int(summary["max_attempts_exhausted_count"]),
        }
    except Exception as exc:
        return {
            "status": "unknown",
            "alert": True,
            "reason": "session_learn_queue_health_failed",
            "error": _safe_error(exc),
        }


def _build_unavailable_health_metric(reason: str) -> dict:
    return {
        "status": "unknown",
        "alert": False,
        "deferred": True,
        "reason": reason,
    }


def _build_deferred_session_learn_queue_health(reason: str) -> dict:
    try:
        payload = _build_session_learn_queue_health()
        payload.update({"deferred": True, "reason": reason})
        return payload
    except Exception:
        return {
            **_build_unavailable_health_metric(reason),
            "stale_threshold_seconds": int(_cfg.WRITE_STALE_MINUTES * 60),
            "processing_count": None,
            "stale_processing_count": None,
            "recoverable_stale_count": None,
            "unrecoverable_stale_count": None,
            "oldest_processing_age_seconds": None,
            "oldest_stale_age_seconds": None,
            "oldest_stale_request_id": None,
            "max_attempts_exhausted_count": None,
        }


def _build_deferred_lifecycle_jobs_health(reason: str, *, pressure_state: Any | None = None) -> dict:
    try:
        payload = _build_lifecycle_jobs_health()
        payload.update(
            {
                "deferred": True,
                "reason": reason,
                "pressure_level": _pressure_state_level(pressure_state),
            }
        )
        return payload
    except Exception:
        return {
            **_deferred_health_metric(reason, pressure_state=pressure_state),
            "queued_count": None,
            "oldest_queued_age_seconds": None,
            "stale_running_count": None,
            "last_committed_age_seconds": None,
        }


def _build_lifecycle_jobs_health() -> dict:
    try:
        from datetime import timedelta

        from app.core.profile import get_active_profile
        from app.storage.lifecycle_jobs import summarize_lifecycle_jobs, summarize_lifecycle_jobs_by_source

        stale_cutoff = (_utc_now() - timedelta(seconds=_cfg.LIFECYCLE_JOB_LEASE_SECONDS)).isoformat()
        summary = summarize_lifecycle_jobs(
            profile=get_active_profile(),
            stale_before_iso=stale_cutoff,
        )
        session_learn_summary = summarize_lifecycle_jobs_by_source(
            profile=get_active_profile(),
            source="session_learn",
            stale_before_iso=stale_cutoff,
        )
        reflection_summary = summarize_lifecycle_jobs_by_source(
            profile=get_active_profile(),
            source="reflection_full",
            stale_before_iso=stale_cutoff,
        )
        queued_count = int(summary["queued_count"]) + int(summary["retry_count"])
        stale_running_count = int(summary["stale_running_count"])
        oldest_queued_age = _iso_age_seconds(summary.get("oldest_queued_updated_at"))
        oldest_running_age = _iso_age_seconds(summary.get("oldest_running_updated_at"))
        last_committed_age = _iso_age_seconds(summary.get("last_committed_updated_at"))
        max_deferred_attempts = int(summary.get("max_deferred_attempts") or 0)
        oldest_deferred_age = _iso_age_seconds(summary.get("oldest_deferred_at"))
        critical_deferred_attempts = max(1, int(_cfg.LIFECYCLE_JOB_MAX_DEFERRALS or 0))
        warning_deferred_attempts = max(1, critical_deferred_attempts // 2)
        critical_deferred_age = max(1.0, float(_cfg.LIFECYCLE_JOB_DEFER_MAX_AGE_SECONDS or 0.0))
        warning_deferred_age = critical_deferred_age / 2.0
        deferred_critical = max_deferred_attempts >= critical_deferred_attempts or (
            (oldest_deferred_age or 0) >= critical_deferred_age
        )
        deferred_warning = max_deferred_attempts >= warning_deferred_attempts or (
            (oldest_deferred_age or 0) >= warning_deferred_age
        )

        def source_payload(source_summary: dict, *, enabled: bool) -> dict:
            return {
                "enabled": enabled,
                "queued_count": int(source_summary["queued_count"]),
                "running_count": int(source_summary["running_count"]),
                "retry_count": int(source_summary["retry_count"]),
                "failed_count": int(source_summary["failed_count"]),
                "committed_count": int(source_summary["committed_count"]),
                "skipped_count": int(source_summary["skipped_count"]),
                "stale_running_count": int(source_summary["stale_running_count"]),
                "max_deferred_attempts": int(source_summary.get("max_deferred_attempts") or 0),
                "oldest_deferred_age_seconds": _iso_age_seconds(source_summary.get("oldest_deferred_at")),
                "oldest_queued_age_seconds": _iso_age_seconds(source_summary.get("oldest_queued_updated_at")),
                "oldest_running_age_seconds": _iso_age_seconds(source_summary.get("oldest_running_updated_at")),
                "last_committed_age_seconds": _iso_age_seconds(source_summary.get("last_committed_updated_at")),
            }

        if queued_count > 50 or (oldest_queued_age or 0) > 600 or stale_running_count > 0 or deferred_critical:
            status = "critical"
        elif queued_count > 10 or (oldest_queued_age or 0) > 120 or deferred_warning:
            status = "warning"
        else:
            status = "ok"
        return {
            "status": status,
            "alert": status in {"warning", "critical"},
            "enabled": bool(_cfg.LIFECYCLE_JOBS_ENABLED),
            "queued_count": queued_count,
            "running_count": int(summary["running_count"]),
            "retry_count": int(summary["retry_count"]),
            "failed_count": int(summary["failed_count"]),
            "committed_count": int(summary["committed_count"]),
            "skipped_count": int(summary["skipped_count"]),
            "stale_running_count": stale_running_count,
            "max_deferred_attempts": max_deferred_attempts,
            "oldest_deferred_age_seconds": oldest_deferred_age,
            "oldest_queued_age_seconds": oldest_queued_age,
            "oldest_running_age_seconds": oldest_running_age,
            "last_committed_age_seconds": last_committed_age,
            "supervisor_enabled": bool(_cfg.LIFECYCLE_SUPERVISOR_ENABLED),
            "supervisor_state": getattr(app.state, "lifecycle_supervisor_state", "unknown"),
            "supervisor_interval_seconds": float(_cfg.LIFECYCLE_SUPERVISOR_INTERVAL_SECONDS),
            "supervisor_batch_size": int(_cfg.LIFECYCLE_SUPERVISOR_BATCH_SIZE),
            "supervisor_starvation_seconds": float(_cfg.LIFECYCLE_SUPERVISOR_STARVATION_SECONDS),
            "warning_queued_count": 10,
            "critical_queued_count": 50,
            "warning_oldest_queued_age_seconds": 120,
            "critical_oldest_queued_age_seconds": 600,
            "warning_max_deferred_attempts": warning_deferred_attempts,
            "critical_max_deferred_attempts": critical_deferred_attempts,
            "warning_deferred_age_seconds": warning_deferred_age,
            "critical_deferred_age_seconds": critical_deferred_age,
            "by_source": {
                "session_learn": source_payload(
                    session_learn_summary,
                    enabled=bool(_SESSION_LEARN_LIFECYCLE_JOBS_ENABLED),
                ),
                "reflection_full": source_payload(
                    reflection_summary,
                    enabled=bool(_cfg.REFLECTION_DURABLE_JOBS_ENABLED),
                ),
            },
        }
    except Exception as exc:
        return {
            "status": "unknown",
            "alert": True,
            "reason": "lifecycle_jobs_health_failed",
            "error": _safe_error(exc),
        }


def _build_observability_background_tasks() -> dict[str, int]:
    """Project durable lifecycle queue state into the legacy API shape."""
    lifecycle_health = _build_lifecycle_jobs_health()
    if lifecycle_health.get("status") == "unknown":
        raise RuntimeError("lifecycle job health unavailable")
    return {
        "running": int(lifecycle_health.get("running_count") or 0),
        "queued": int(lifecycle_health.get("queued_count") or 0),
    }


def _build_autolearn_maintenance_health(defer_reason: str | None = None) -> dict[str, Any]:
    """Summarize autonomous autolearn enrichment liveness."""
    try:
        from app.session.autolearn_maintenance import get_autolearn_maintenance_supervisor_status

        supervisor = get_autolearn_maintenance_supervisor_status()
        supervisor_state = getattr(app.state, "autolearn_maintenance_supervisor_state", "unknown")
        enabled = bool(
            _cfg.get_autolearn_maintenance_enabled()
            and _cfg.get_autolearn_maintenance_supervisor_enabled()
            and os.environ.get("PITH_BENCHMARK_READONLY", "").lower() not in ("1", "true")
        )
        last_status = str(supervisor.get("last_status") or "unknown")
        if last_status == "error" or (enabled and not bool(supervisor.get("thread_alive"))):
            status = "degraded"
            alert = True
        elif last_status == "skipped_required_context_cache":
            status = "warning"
            alert = False
        else:
            status = "ok"
            alert = False
        payload: dict[str, Any] = {
            "status": status,
            "alert": alert,
            "enabled": enabled,
            "supervisor_state": supervisor_state,
            "thread_alive": bool(supervisor.get("thread_alive")),
            "stop_requested": bool(supervisor.get("stop_requested")),
            "last_status": last_status,
            "last_started_at": supervisor.get("last_started_at"),
            "last_completed_at": supervisor.get("last_completed_at"),
            "last_processed": int(supervisor.get("last_processed") or 0),
            "last_error": supervisor.get("last_error"),
            "last_reason": supervisor.get("last_reason"),
            "interval_seconds": _cfg.get_autolearn_maintenance_supervisor_interval_seconds(),
            "batch_size": _cfg.get_autolearn_maintenance_supervisor_batch_size(),
            "max_wall_seconds": _cfg.get_autolearn_maintenance_supervisor_max_wall_seconds(),
        }
        payload.update(
            {
                "deferred": True,
                "defer_reason": defer_reason or "queue_metrics_monitor_owned",
                "ready_total": None,
                "oldest_ready_age_seconds": None,
            }
        )
        return payload
    except Exception as exc:
        return {
            "status": "unknown",
            "alert": True,
            "reason": "autolearn_maintenance_health_failed",
            "error": _safe_error(exc),
        }


def _build_required_context_cache_health() -> dict[str, Any]:
    """Summarize required-context cache readiness for bounded turn latency."""
    try:
        from app.session.required_context_cache import required_context_cache_status

        max_age_ms = float(os.environ.get("PITH_REQUIRED_CONTEXT_CACHE_HEALTH_MAX_AGE_MS", "60000"))
        status = required_context_cache_status(health_max_age_ms=max_age_ms)
        component_status = {
            "empty": "degraded",
            "fresh": "ok",
            "stale_but_servable": "warning",
            "cold_degraded": "degraded",
        }.get(status.state, "unknown")
        alert = status.state in {"empty", "cold_degraded"}
        return {
            "status": component_status,
            "alert": alert,
            "warm": status.state == "fresh",
            "state": status.state,
            "age_ms": status.age_ms,
            "servable": status.servable,
            "max_age_ms": max_age_ms,
            "health_max_age_ms": status.health_max_age_ms,
            "serving_max_stale_ms": status.serving_max_stale_ms,
            "refresh_after_ms": status.refresh_after_ms,
            "refresh_in_flight": status.refresh_in_flight,
            "stale_first_enabled": os.environ.get("PITH_STAGE3B_REQUIRED_CONTEXT_STALE_FIRST", "true").lower()
            in ("true", "1"),
        }
    except Exception as exc:
        return {
            "status": "unknown",
            "alert": True,
            "reason": "required_context_cache_health_failed",
            "error": _safe_error(exc),
        }


def _build_conversation_turn_latency_health(pressure_state: Any | None = None) -> dict[str, Any]:
    """Summarize recent conversation_turn latency from metrics."""
    try:
        from app.ops.metrics import metrics

        if os.environ.get("PITH_CONVERSATION_LATENCY_HEALTH_V2", "1").lower() in ("0", "false", "off"):
            aggregate = metrics.query_aggregate("conversation_turn_latency_ms")
        else:
            aggregate = metrics.query_aggregate_with_recency("conversation_turn_latency_ms")
        p95_ms = float(aggregate.get("p95", 0.0) or 0.0)
        max_ms = float(aggregate.get("max", 0.0) or 0.0)
        count = int(aggregate.get("count", 0) or 0)
        if max_ms > 15000.0:
            raw_status = "critical"
        elif p95_ms > 3500.0:
            raw_status = "degraded"
        else:
            raw_status = "ok"

        if os.environ.get("PITH_CONVERSATION_LATENCY_HEALTH_V2", "1").lower() in ("0", "false", "off"):
            status = raw_status
            return {
                "status": status,
                "alert": status in {"critical", "degraded"},
                "p95_ms": p95_ms,
                "max_ms": max_ms,
                "count": count,
                "threshold_p95_ms": 3500.0,
                "threshold_critical_max_ms": 15000.0,
            }

        pressure_payload = (
            pressure_state.to_dict()
            if hasattr(pressure_state, "to_dict")
            else (pressure_state if isinstance(pressure_state, dict) else {})
        )
        active_contention = bool(pressure_payload.get("active_contention"))
        reason_codes = list(pressure_payload.get("reason_codes") or [])
        if active_contention:
            reason_codes.append("active_contention")
        if pressure_payload.get("in_process_reflection"):
            reason_codes.append("in_process_reflection_active")
        if pressure_payload.get("external_maintenance"):
            reason_codes.append("external_maintenance_active")
        if pressure_payload.get("stale_external_maintenance"):
            reason_codes.append("external_maintenance_stale")
        if count < 20:
            reason_codes.append("low_sample_confidence")
        if p95_ms > 3500.0:
            reason_codes.append("p95_above_degraded_threshold")
        if max_ms > 15000.0:
            reason_codes.append("max_above_critical_threshold")

        max_age_seconds = aggregate.get("max_age_seconds")
        fresh_window_seconds = _env_float("PITH_CONVERSATION_LATENCY_HEALTH_FRESH_WINDOW_SECONDS", 600.0)
        recent_outlier_status = "none"
        if max_ms > 15000.0:
            if max_age_seconds is None or float(max_age_seconds) <= fresh_window_seconds:
                recent_outlier_status = "critical"
                reason_codes.append("fresh_critical_outlier")
            else:
                recent_outlier_status = "aged_critical_outlier"
                reason_codes.append("aged_critical_outlier")

        steady_state_status = "degraded" if p95_ms > 3500.0 else "ok"
        if recent_outlier_status == "critical" or raw_status == "critical" and active_contention:
            status = "critical"
        elif steady_state_status == "degraded":
            status = "degraded"
        else:
            status = "ok"
        aged_outlier_diagnostic_only = recent_outlier_status == "aged_critical_outlier" and status == "ok"
        recovery_state = (
            "recovered" if aged_outlier_diagnostic_only else ("active" if status in {"critical", "degraded"} else "ok")
        )

        deduped_reasons = list(dict.fromkeys(str(code) for code in reason_codes))
        return {
            "status": status,
            "alert": status in {"critical", "degraded"},
            "p95_ms": p95_ms,
            "max_ms": max_ms,
            "count": count,
            "threshold_p95_ms": 3500.0,
            "threshold_critical_max_ms": 15000.0,
            "raw_status": raw_status,
            "steady_state_status": steady_state_status,
            "recent_outlier_status": recent_outlier_status,
            "fresh_window_seconds": fresh_window_seconds,
            "aged_outlier_diagnostic_only": aged_outlier_diagnostic_only,
            "recovery_state": recovery_state,
            "active_contention": active_contention,
            "sample_confidence": "low" if count < 20 else "normal",
            "max_age_seconds": max_age_seconds,
            "reason_codes": deduped_reasons,
            "pressure_state": pressure_payload,
            "window_seconds": int(aggregate.get("window_seconds", 3600) or 3600),
        }
    except Exception as exc:
        return {
            "status": "unknown",
            "alert": True,
            "reason": "conversation_turn_latency_health_failed",
            "error": _safe_error(exc),
        }


def _should_defer_health_db_metrics(ready: dict) -> bool:
    return ready.get("process_state", "running") != "running" or ready.get("retrieval_state") != "ready"


def _health_metrics_defer_reason(ready: dict) -> str:
    if ready.get("process_state", "running") != "running":
        return "process_not_running"
    if ready.get("retrieval_state") == "recovering":
        return "startup_recovering"
    return "retrieval_not_ready"


@dataclass(frozen=True)
class WriteReplayRecoverySpec:
    endpoint: str
    run: Callable[[dict], object]
    commit: Callable[[str, object], dict]


def _record_write_replay_metric(metric: str, endpoint: str, labels: dict | None = None) -> None:
    try:
        from app.ops.metrics import metrics as _wr_metrics

        metric_labels = {"endpoint": endpoint}
        if labels:
            metric_labels.update(labels)
        _wr_metrics.record(metric, 1.0, metric_labels)
        _wr_metrics.flush()
    except Exception:
        pass


def _run_session_learn_replay_payload(payload: dict) -> object:
    replay_payload = dict(payload)
    if replay_payload.get("extracted_concepts") or replay_payload.get("extracted_concepts_json"):
        replay_payload["replay_fast_path"] = True
        replay_payload["trigger_path"] = replay_payload.get("trigger_path") or "session_learn_replay"
    request = SessionLearnRequest(**replay_payload)
    return session_manager.session_learn(request)


def _load_committed_session_learn_replay(request_id: str) -> dict | None:
    from app.core.profile import get_active_profile

    row = load_write_request_replay("session_learn", get_active_profile(), request_id)
    if not row or row.get("status") != "committed" or not row.get("response"):
        return None
    payload = dict(row["response"])
    payload.setdefault("request_id", request_id)
    payload.setdefault("persistence_state", "committed")
    return payload


def _lifecycle_job_blocks_session_learn_replay(lifecycle_job: dict | None, now_dt) -> tuple[bool, str]:
    if not lifecycle_job:
        return False, "absent"
    status = lifecycle_job.get("status")
    if status not in {"queued", "running", "retry"}:
        return False, str(status or "inactive")
    if status != "running":
        return True, str(status)

    try:
        lease_expires_at = lifecycle_job.get("lease_expires_at")
        if lease_expires_at and _ensure_aware(datetime.fromisoformat(str(lease_expires_at))) <= now_dt:
            return False, "expired_running_lease"
        updated_at = lifecycle_job.get("updated_at")
        if not lease_expires_at and updated_at:
            updated = _ensure_aware(datetime.fromisoformat(str(updated_at)))
            if (now_dt - updated).total_seconds() >= _cfg.LIFECYCLE_JOB_LEASE_SECONDS:
                return False, "stale_running_without_lease"
    except Exception:
        return True, "running_unparseable_lease"
    return True, "running_active_lease"


def _run_session_learn_lifecycle_job(job: dict) -> dict:
    managed = job.get("binding_hash") is not None
    replay_state = _managed_replay_state_from_job(job, endpoint="session_learn") if managed else None
    request_id = (
        replay_state.request_id if replay_state is not None else (job.get("idempotency_key") or job.get("request_id"))
    )
    if not request_id:
        raise ValueError("session_learn lifecycle job missing idempotency_key")
    if replay_state is not None:
        replay_row = load_write_request_replay(
            "session_learn",
            str(job.get("profile") or ""),
            str(replay_state.storage_request_id),
        )
        committed = (
            dict(replay_row["response"])
            if replay_row and replay_row.get("status") == "committed" and replay_row.get("response")
            else None
        )
    else:
        committed = _load_committed_session_learn_replay(str(request_id))
    if committed is not None:
        _record_session_learn_contract_metric("session_learn_lifecycle_replay_already_committed")
        return {"status": "replay_already_committed", "request_id": request_id}

    payload = job.get("payload") or {}
    request_payload = payload.get("learn_request") if isinstance(payload, dict) else None
    if not isinstance(request_payload, dict):
        raise ValueError("session_learn lifecycle job missing learn_request payload")
    request_payload.setdefault("request_id", request_id)
    request = SessionLearnRequest(**request_payload)

    def _run_effect():
        binding = None
        prepare_binding = getattr(session_manager, "prepare_session_learn_binding", None)
        if callable(prepare_binding):
            binding = prepare_binding(request)
        try:
            return _run_session_learn_replay_payload(request.model_dump(mode="json"))
        finally:
            if binding is not None:
                session_manager._pop_request_session(
                    binding["session_token"],
                    binding["active_token"],
                )

    if managed:
        from app.session.binding import BindingBusyError, run_managed_session_learn_effect
        from app.session.lifecycle_jobs_runtime import LifecycleJobDeferred

        try:
            result = run_managed_session_learn_effect(job, run_effect=_run_effect)
        except BindingBusyError as exc:
            raise LifecycleJobDeferred("managed_episode_guard_busy", retry_after_seconds=1) from exc
    else:
        result = _run_effect()
    if replay_state is not None:
        _commit_session_learn_result(str(request_id), result, replay_state=replay_state)
    else:
        _commit_session_learn_result(str(request_id), result)
    _record_session_learn_contract_metric("session_learn_lifecycle_committed")
    return {"status": "committed", "request_id": request_id}


def _run_session_end_replay_payload(payload: dict) -> object:
    request_id = _ensure_session_end_request_id(payload.get("request_id"))
    request_payload = dict(payload)
    request_payload["request_id"] = request_id
    request = SessionEndRequest(**request_payload)
    return _with_db_retry(lambda: session_manager.end_session(request))


def _run_checkpoint_replay_payload(payload: dict) -> dict:
    return _with_db_retry(lambda: _execute_checkpoint_action(dict(payload)))


def _commit_checkpoint_result(request_id: str, result) -> dict:
    payload = dict(result) if isinstance(result, dict) else {"status": str(result)}
    payload = commit_write_request("checkpoint", request_id, payload)
    _record_successful_write()
    return payload


def _write_replay_recovery_specs() -> dict[str, WriteReplayRecoverySpec]:
    return {
        "session_learn": WriteReplayRecoverySpec(
            "session_learn", _run_session_learn_replay_payload, _commit_session_learn_result
        ),
        "session_end": WriteReplayRecoverySpec(
            "session_end", _run_session_end_replay_payload, _commit_session_end_result
        ),
        "checkpoint": WriteReplayRecoverySpec("checkpoint", _run_checkpoint_replay_payload, _commit_checkpoint_result),
    }


def _clear_write_replay_reclaimer_future(endpoint: str, done_future: concurrent.futures.Future) -> None:
    with _WRITE_REPLAY_RECLAIMER_LOCK:
        if _WRITE_REPLAY_RECLAIMER_FUTURES.get(endpoint) is done_future:
            _WRITE_REPLAY_RECLAIMER_FUTURES.pop(endpoint, None)


def _schedule_write_replay_reclaimer(endpoint: str, reason: str) -> bool:
    if endpoint not in _write_replay_recovery_specs():
        return False
    with _WRITE_REPLAY_RECLAIMER_LOCK:
        existing = _WRITE_REPLAY_RECLAIMER_FUTURES.get(endpoint)
        if existing is not None and not existing.done():
            return False
        future = _get_session_learn_executor().submit(_run_write_replay_reclaimer, endpoint, reason)
        _WRITE_REPLAY_RECLAIMER_FUTURES[endpoint] = future
    future.add_done_callback(
        lambda done_future, endpoint=endpoint: _clear_write_replay_reclaimer_future(endpoint, done_future)
    )
    return True


def _schedule_all_write_replay_reclaimers(reason: str) -> dict[str, bool]:
    return {endpoint: _schedule_write_replay_reclaimer(endpoint, reason) for endpoint in _write_replay_recovery_specs()}


def _schedule_session_learn_reclaimer(reason: str) -> bool:
    return _schedule_write_replay_reclaimer("session_learn", reason)


def _run_session_learn_reclaimer(reason: str, batch_size: int | None = None) -> dict:
    return _run_write_replay_reclaimer("session_learn", reason, batch_size=batch_size)


def _run_write_replay_reclaimer(endpoint: str, reason: str, batch_size: int | None = None) -> dict:
    from datetime import timedelta

    from app.core.profile import get_active_profile
    from app.storage import (
        claim_stale_write_requests,
        fail_unrecoverable_stale_write_requests,
        mark_write_request_reclaim_failed,
    )

    specs = _write_replay_recovery_specs()
    if endpoint not in specs:
        return {
            "endpoint": endpoint,
            "reason": reason,
            "claimed": 0,
            "committed": 0,
            "failed": 0,
            "retry_scheduled": 0,
            "unrecoverable_failed": 0,
        }
    spec = specs[endpoint]
    profile = get_active_profile()
    now_dt = _utc_now()
    now = now_dt.isoformat()
    stale_cutoff = _session_learn_stale_cutoff_iso()
    lease_expires_at = (now_dt + timedelta(seconds=_SESSION_LEARN_RECLAIMER_LEASE_SECONDS)).isoformat()
    batch_limit = batch_size or _SESSION_LEARN_RECLAIMER_BATCH_SIZE
    rows = claim_stale_write_requests(
        endpoint,
        profile,
        stale_cutoff,
        f"{os.getpid()}:{id(app)}:{reason}:{endpoint}",
        lease_expires_at,
        batch_limit,
        now,
        _SESSION_LEARN_RECLAIMER_MAX_ATTEMPTS,
    )
    result = {
        "endpoint": endpoint,
        "reason": reason,
        "claimed": len(rows),
        "committed": 0,
        "failed": 0,
        "retry_scheduled": 0,
        "unrecoverable_failed": 0,
        "skipped_active_lifecycle": 0,
    }
    if rows:
        _record_write_replay_metric("write_request_reclaimer_claimed", endpoint)
        if endpoint == "session_learn":
            _record_session_learn_contract_metric("session_learn_reclaimer_claimed")
    for row in rows:
        request_id = row["request_id"]
        if endpoint == "session_learn" and _SESSION_LEARN_LIFECYCLE_JOBS_ENABLED:
            from app.storage.lifecycle_jobs import load_lifecycle_job_by_identity

            lifecycle_job = load_lifecycle_job_by_identity(
                profile=profile,
                source="session_learn",
                idempotency_key=request_id,
            )
            blocks_replay, block_reason = _lifecycle_job_blocks_session_learn_replay(lifecycle_job, now_dt)
            if blocks_replay:
                _record_session_learn_contract_metric("session_learn_reclaimer_skipped_active_lifecycle")
                _record_write_replay_metric(
                    "write_request_reclaimer_skipped_active_lifecycle",
                    endpoint,
                    {
                        "lifecycle_status": str(lifecycle_job.get("status") if lifecycle_job else "absent"),
                        "reason": block_reason,
                    },
                )
                result["skipped_active_lifecycle"] += 1
                continue
            if lifecycle_job and lifecycle_job.get("status") == "running":
                _record_session_learn_contract_metric("session_learn_reclaimer_unpinned_expired_lifecycle")
                _record_write_replay_metric(
                    "write_request_reclaimer_unpinned_expired_lifecycle",
                    endpoint,
                    {"reason": block_reason},
                )
        try:
            request_payload = dict(row["request"])
            request_payload.setdefault("request_id", request_id)
            replay_result = spec.run(request_payload)
            spec.commit(request_id, replay_result)
            _record_write_replay_metric("write_request_reclaimer_committed", endpoint)
            if endpoint == "session_learn":
                _record_session_learn_contract_metric("session_learn_reclaimer_committed")
            result["committed"] += 1
        except (ValidationError, ValueError) as exc:
            fail_write_request(
                endpoint,
                request_id,
                {
                    "status": "failed",
                    "persistence_state": "failed",
                    "request_id": request_id,
                    "error_class": type(exc).__name__,
                    "error": _safe_error(exc),
                },
                error_class=type(exc).__name__,
            )
            _record_write_replay_metric("write_request_reclaimer_failed", endpoint, {"error_class": type(exc).__name__})
            result["failed"] += 1
        except Exception as exc:
            retry_at = (_utc_now() + timedelta(seconds=_SESSION_LEARN_RECLAIMER_RETRY_SECONDS)).isoformat()
            mark_write_request_reclaim_failed(
                endpoint,
                profile,
                request_id,
                f"{type(exc).__name__}: {_safe_error(exc)}",
                retry_at,
                _utc_now_iso(),
            )
            _record_write_replay_metric(
                "write_request_reclaimer_retry_scheduled", endpoint, {"error_class": type(exc).__name__}
            )
            if endpoint == "session_learn":
                _record_session_learn_contract_metric("session_learn_reclaimer_failed")
            logger.warning("%s reclaimer failed for request_id=%s: %s", endpoint, request_id, exc, exc_info=True)
            result["retry_scheduled"] += 1
    unrecoverable_failed = fail_unrecoverable_stale_write_requests(
        endpoint,
        profile,
        stale_cutoff,
        _utc_now_iso(),
        "UnrecoverableReplayMissingPayload",
        batch_limit,
    )
    if unrecoverable_failed:
        _record_write_replay_metric("write_request_unrecoverable_failed", endpoint)
        result["failed"] += unrecoverable_failed
        result["unrecoverable_failed"] = unrecoverable_failed
    return result


def _commit_session_learn_result(
    request_id: str,
    result,
    *,
    replay_state: WriteReplayState | None = None,
) -> dict:
    payload = result.model_dump()
    if not payload.get("request_id"):
        payload["request_id"] = request_id
    if not payload.get("processing_state"):
        payload["processing_state"] = "committed"
    if replay_state is not None:
        payload = commit_write_request(
            "session_learn",
            request_id,
            payload,
            replay_state=replay_state,
        )
    else:
        payload = commit_write_request("session_learn", request_id, payload)
    _record_successful_write()
    return payload


def _coerce_session_end_payload(request_id: str, result) -> dict:
    if hasattr(result, "model_dump"):
        payload = result.model_dump()
    elif isinstance(result, dict):
        payload = dict(result)
    else:
        payload = {"status": str(result)}
    payload.setdefault("request_id", request_id)
    payload.setdefault("processing_state", "committed")
    payload.setdefault("final_learning_state", "committed")
    return payload


def _commit_session_end_result(
    request_id: str,
    result,
    *,
    replay_state: WriteReplayState | None = None,
) -> dict:
    payload = _coerce_session_end_payload(request_id, result)
    if replay_state is not None:
        payload = commit_write_request(
            "session_end",
            request_id,
            payload,
            replay_state=replay_state,
        )
    else:
        payload = commit_write_request("session_end", request_id, payload)
    _record_successful_write()
    return payload


def _finalize_deferred_session_learn(future: concurrent.futures.Future, request_id: str) -> None:
    try:
        result = future.result()
        _commit_session_learn_result(request_id, result)
        _record_session_learn_contract_metric("session_learn_background_committed")
    except Exception as exc:
        abandon_write_request("session_learn", request_id, error_class=type(exc).__name__)
        _record_session_learn_contract_metric("session_learn_background_failed")
        logger.error("session_learn background error for request_id=%s: %s", request_id, exc, exc_info=True)


def _finalize_deferred_session_end(future: concurrent.futures.Future, request_id: str) -> None:
    try:
        result = future.result()
        _commit_session_end_result(request_id, result)
        _record_session_learn_contract_metric("session_end_background_committed")
    except Exception as exc:
        abandon_write_request("session_end", request_id, error_class=type(exc).__name__)
        _record_session_learn_contract_metric("session_end_background_failed")
        logger.error("session_end background error for request_id=%s: %s", request_id, exc, exc_info=True)


@app.post("/session_learn", dependencies=[Depends(verify_api_key)])
def session_learn_endpoint(request: SessionLearnRequest):
    """Post-response concept extraction. Given a completed exchange, extract
    new knowledge, evolve existing concepts, build associations.
    Fast requests return synchronously; slow requests return replayable processing state."""
    start = time.perf_counter()
    request, request_id = _ensure_session_learn_request_id(request)
    managed_context = None
    managed_guard = None
    replay_state = None
    try:
        if request.binding is not None:
            _require_managed_session_learn_runtime(request)
            from app.core.profile import get_active_profile
            from app.session.binding import resolve_managed_learning

            managed_context, managed_guard = resolve_managed_learning(
                request,
                profile=get_active_profile(),
            )
            authority = ManagedReplayAuthority(
                profile=managed_context.profile,
                binding_hash=managed_context.binding_hash,
                session_id=managed_context.session_id,
            )
        else:
            authority = None

        try:
            replay_state = begin_write_request(
                "session_learn",
                request_id,
                request_payload=request.model_dump(mode="json"),
                authority=authority,
            )
        except HTTPException as exc:
            if exc.status_code == 409:
                _record_session_learn_initial_response_latency(start, "processing_duplicate")
                return _session_learn_processing_payload(
                    request_id,
                    processing_time_ms=(time.perf_counter() - start) * 1000,
                )
            _record_session_learn_initial_response_latency(start, "error")
            raise
        if replay_state.replay is not None:
            _record_session_learn_initial_response_latency(start, "replay")
            return replay_state.replay

        structured_fast_path = managed_context is None and _should_commit_structured_session_learn_fast_path(request)
        if structured_fast_path:
            _prepare_structured_session_learn_fast_path(request)

        def _do_session_learn():
            binding = None
            prepare_binding = getattr(session_manager, "prepare_session_learn_binding", None)
            if callable(prepare_binding):
                binding = prepare_binding(request)
            try:
                return session_manager.session_learn(request)
            finally:
                if binding is not None:
                    session_manager._pop_request_session(
                        binding["session_token"],
                        binding["active_token"],
                    )

        if managed_context is not None or (_SESSION_LEARN_LIFECYCLE_JOBS_ENABLED and not structured_fast_path):
            try:
                if managed_context is not None:
                    _enqueue_session_learn_lifecycle_job(
                        request,
                        request_id,
                        managed_context=managed_context,
                        replay_state=replay_state,
                    )
                else:
                    _enqueue_session_learn_lifecycle_job(request, request_id)
            except Exception as exc:
                abandon_write_request(
                    "session_learn",
                    request_id,
                    error_class=type(exc).__name__,
                    replay_state=replay_state if managed_context is not None else None,
                )
                _record_session_learn_initial_response_latency(start, "error")
                logger.error("session_learn lifecycle enqueue error: %s", exc, exc_info=True)
                if managed_context is not None:
                    from app.session.binding import ManagedBindingError

                    raise ManagedBindingError(
                        "managed_learning_registration_unavailable",
                        status_code=503,
                    ) from exc
                raise HTTPException(status_code=500, detail=_safe_error(exc)) from exc
            _record_session_learn_contract_metric("session_learn_lifecycle_deferred")
            _record_session_learn_lifecycle_latency("session_learn_lifecycle_ack_latency_ms", start)
            _record_session_learn_initial_response_latency(start, "lifecycle_processing")
            payload = _session_learn_processing_payload(
                request_id,
                processing_time_ms=(time.perf_counter() - start) * 1000,
            )
            if managed_context is not None:
                payload["_protocol"] = {
                    "binding_mode": "managed",
                    "binding_protocol_version": managed_context.protocol_version,
                    "binding_generation": managed_context.generation,
                    "lifecycle_phase": "active",
                }
            return payload

        future = _get_session_learn_executor().submit(_do_session_learn)
        try:
            result = future.result(timeout=_remaining_session_learn_sync_wait(start))
            _record_session_learn_initial_response_latency(start, "committed")
            return _commit_session_learn_result(request_id, result)
        except concurrent.futures.TimeoutError:
            future.add_done_callback(lambda done_future: _finalize_deferred_session_learn(done_future, request_id))
            _record_session_learn_contract_metric("session_learn_deferred")
            _schedule_session_learn_reclaimer("deferred_session_learn")
            _record_session_learn_initial_response_latency(start, "processing_deferred")
            return _session_learn_processing_payload(
                request_id,
                processing_time_ms=(time.perf_counter() - start) * 1000,
            )
        except Exception as exc:
            abandon_write_request("session_learn", request_id, error_class=type(exc).__name__)
            _record_session_learn_initial_response_latency(start, "error")
            logger.error("session_learn error: %s", exc)
            raise HTTPException(status_code=500, detail=_safe_error(exc)) from exc
    except Exception as exc:
        from app.session.binding import ManagedBindingError

        if isinstance(exc, ManagedBindingError):
            _record_session_learn_initial_response_latency(start, "error")
            headers = {"Retry-After": "1"} if exc.status_code in {423, 503} else None
            raise HTTPException(
                status_code=exc.status_code,
                detail={"error": exc.code, "request_id": request_id},
                headers=headers,
            ) from exc
        raise
    finally:
        if managed_guard is not None:
            managed_guard.release()


@app.get("/sessions_list")
def sessions_list_endpoint(status: str = None, limit: int = 20, since: str = None):
    """Query session history. Optional filters: status, limit, since (ISO datetime)."""
    return list_sessions(status=status, limit=limit, since=since)


@app.post("/write_request_status", dependencies=[Depends(verify_api_key)])
def write_request_status_endpoint(body: dict):
    """Redacted idempotent write-request status for lifecycle conformance."""
    managed_guard = None
    try:
        endpoint = str(body.get("endpoint") or "")
        request_id = body.get("request_id")
        if "binding" not in body:
            return get_write_request_status(endpoint, request_id)
        binding_payload = body.get("binding")

        try:
            envelope = SessionBindingEnvelope.model_validate(binding_payload)
        except ValidationError as exc:
            binding_errors = []
            for error in exc.errors(include_context=False):
                item = dict(error)
                item["loc"] = ("binding", *(item.get("loc") or ()))
                binding_errors.append(item)
            raise HTTPException(
                status_code=400,
                detail=_redact_request_validation_errors(binding_errors),
            ) from exc

        from app.core.profile import get_active_profile
        from app.session.binding import (
            ManagedBindingError,
            authorize_managed_write_request_status,
        )

        context, lifecycle_phase, managed_guard = authorize_managed_write_request_status(
            envelope,
            session_id=body.get("session_id"),
            binding_generation=body.get("binding_generation"),
            profile=get_active_profile(),
        )
        result = get_write_request_status(
            endpoint,
            request_id,
            authority=ManagedReplayAuthority(
                profile=context.profile,
                binding_hash=context.binding_hash,
                session_id=context.session_id,
            ),
        )
        result["_protocol"] = {
            "binding_mode": "managed",
            "binding_protocol_version": context.protocol_version,
            "binding_generation": context.generation,
            "lifecycle_phase": lifecycle_phase,
        }
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        from app.session.binding import ManagedBindingError

        if isinstance(exc, ManagedBindingError):
            headers = {"Retry-After": "1"} if exc.status_code in {423, 503} else None
            raise HTTPException(
                status_code=exc.status_code,
                detail={"error": exc.code, "request_id": body.get("request_id")},
                headers=headers,
            ) from exc
        raise
    finally:
        if managed_guard is not None:
            managed_guard.release()


def _record_checkpoint_save_telemetry(body: dict) -> None:
    try:
        from app.storage import record_checkpoint_save_event

        record_checkpoint_save_event(body.get("session_id"), body["task_id"])
    except Exception as _ckpt_metric_err:
        logger.warning(
            "CKPT-008: checkpoint_save telemetry skipped under DB contention: %s",
            _safe_error(_ckpt_metric_err),
        )


def _execute_checkpoint_action(body: dict) -> dict:
    from app.storage import complete_checkpoint, save_checkpoint, touch_checkpoint

    action = body.get("action", "save")
    if action == "save":
        if not body.get("task_id") or not body.get("description"):
            raise ValueError("task_id and description required for save")

        def _do_save_checkpoint():
            return save_checkpoint(
                task_id=body["task_id"],
                description=body["description"],
                status=body.get("status", "active"),
                done=body.get("done", []),
                active=body.get("active", ""),
                next_items=body.get("next", []),
                blockers=body.get("blockers", []),
                context=body.get("context", {}),
                concept_refs=body.get("concept_refs", []),
                session_id=body.get("session_id"),
                ttl_days=body.get("ttl_days"),
                origin_id=body.get("origin_id"),
                op_id=body.get("op_id"),
                payload_hash=body.get("payload_hash"),
            )

        result = _do_save_checkpoint()
        _record_checkpoint_save_telemetry(body)
        return result
    if action == "complete":
        if not body.get("task_id"):
            raise ValueError("task_id required for complete")
        return complete_checkpoint(body["task_id"]) or {"status": "not_found"}
    if action == "touch":
        if not body.get("task_id"):
            raise ValueError("task_id required for touch")
        return touch_checkpoint(body["task_id"], ttl_days=body.get("ttl_days", 7)) or {"status": "not_found"}
    raise ValueError(f"Unsupported checkpoint replay action: {action}")


@app.post("/checkpoint", dependencies=[Depends(verify_api_key)])
def checkpoint_endpoint(body: dict):
    """Execution checkpoint CRUD — ephemeral resumption state, NOT concepts."""
    from app.storage import (
        list_checkpoints,
        load_checkpoint,
    )

    action = body.get("action", "save")
    request_id = body.get("request_id")
    mutating_actions = {"save", "touch", "complete"}
    replay_state = (
        begin_write_request("checkpoint", request_id, request_payload=dict(body))
        if action in mutating_actions
        else None
    )
    if replay_state and replay_state.replay is not None:
        return replay_state.replay

    if action in mutating_actions:
        try:
            result = _with_db_retry(lambda: _execute_checkpoint_action(body))
        except ValueError as exc:
            abandon_write_request("checkpoint", request_id, error_class="ValueError")
            raise HTTPException(400, str(exc)) from exc
        except Exception as exc:
            abandon_write_request("checkpoint", request_id, error_class=type(exc).__name__)
            logger.error("checkpoint %s error: %s", action, exc)
            raise HTTPException(503, f"Transient error during checkpoint {action}: {_safe_error(exc)}") from exc
        result = _commit_checkpoint_result(request_id, result)
        return result
    if action == "load":
        result = load_checkpoint(
            task_id=body.get("task_id"),
            max_age_hours=body.get("max_age_hours") or 24,
            session_id=body.get("session_id"),
            origin_id=body.get("origin_id"),
        )
        return result or {"status": "no_checkpoint_found"}
    elif action == "list":
        return {"checkpoints": list_checkpoints()}
    elif action == "dashboard":
        from app.storage import get_checkpoint_dashboard

        return get_checkpoint_dashboard()
    elif action == "threshold_analysis":
        from app.storage import analyze_coverage_threshold

        thresholds = body.get("thresholds")
        return analyze_coverage_threshold(thresholds)
    elif action == "session_drops":
        from app.storage import analyze_session_drops

        return analyze_session_drops()
    else:
        raise HTTPException(400, f"Unknown action: {action}")


# =============================================================================
# Wave 5: pith_threads MCP tool (§5.7)
# =============================================================================


def _parse_workstream_bool(value: object, default: bool = False) -> bool:
    """Parse Workstreams booleans without Python's bool('false') trap."""
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in ("true", "1", "yes", "on"):
            return True
        if normalized in ("false", "0", "no", "off"):
            return False
        raise HTTPException(400, f"Invalid boolean value: {value}")
    if isinstance(value, int) and value in (0, 1):
        return bool(value)
    raise HTTPException(400, f"Invalid boolean value: {value}")


_WORKSTREAM_ACTIVATION_CREATE_METADATA_FIELDS = (
    "title",
    "description",
    "urgency",
    "goal_ids",
    "knowledge_areas",
    "agent_id",
    "lane_id",
    "external_refs",
    "current_objective",
    "current_summary",
    "next_action",
    "blockers",
    "quality_state",
    "created_by",
)


def _workstream_activation_metadata_from_body(body: dict) -> object:
    metadata = body.get("metadata")
    if metadata is not None:
        return metadata
    return {key: body[key] for key in _WORKSTREAM_ACTIVATION_CREATE_METADATA_FIELDS if key in body}


_WORKSTREAM_LIFECYCLE_TOP_LEVEL_METADATA_FIELDS = (
    "title",
    "description",
    "urgency",
    "goal_ids",
    "knowledge_areas",
    "agent_id",
    "lane_id",
    "external_refs",
    "current_objective",
    "current_summary",
    "next_action",
    "blockers",
    "quality_state",
    "created_by",
    "parent_workstream_id",
    "parent_title",
    "relationship",
)


def _workstream_lifecycle_metadata_from_body(body: dict) -> object:
    top_level = {key: body[key] for key in _WORKSTREAM_LIFECYCLE_TOP_LEVEL_METADATA_FIELDS if key in body}
    metadata = body.get("metadata")
    if metadata is None:
        return top_level or None
    if not isinstance(metadata, dict):
        return metadata
    return {**top_level, **metadata}


_WORKSTREAM_RAW_ADMIN_ACTIONS = {
    "create_workstream",
    "promote_workstream",
    "update_workstream",
    "bind_workstream",
    "clear_workstream_binding",
    "workstream_promote_discovery_candidate",
    "workstream_demote_discovery_candidate",
}
_WORKSTREAM_HYGIENE_WRITE_ACTIONS = {
    "workstream_hygiene_apply",
    "workstream_hygiene_rollback",
}
_WORKSTREAM_RAW_LIFECYCLE_VERBS = {
    "create_workstream": "start",
    "bind_workstream": "adopt",
    "update_workstream": "progress",
}


def _workstreams_capability_contract() -> dict:
    from app.core.config import get_feature_flag

    return {
        "consumer_write_mode": "lifecycle",
        "lifecycle_writes_enabled": bool(get_feature_flag("WORKSTREAMS_LIFECYCLE_WRITE_ENABLED", False)),
        "activation_writes_enabled": bool(get_feature_flag("WORKSTREAMS_ACTIVATION_WRITE_ENABLED", False)),
        "hygiene_writes_enabled": bool(get_feature_flag("WORKSTREAMS_HYGIENE_WRITE_ENABLED", True)),
        "admin_raw_writes_enabled": bool(get_feature_flag("WORKSTREAMS_WRITE_ENABLED", False)),
        "default_write_action": "workstream_lifecycle",
        "default_lifecycle_verbs": ["start", "adopt", "progress", "complete", "reopen", "archive"],
        "admin_raw_write_flag": "WORKSTREAMS_WRITE_ENABLED",
    }


def _raw_workstream_admin_write_disabled(action: str, body: dict) -> dict:
    response = {
        "status": "disabled",
        "reason": "raw_workstream_admin_write_disabled",
        "action": action,
        "required_action": "use_workstream_lifecycle",
        "recommended_action": "workstream_lifecycle",
        "write_mode": "lifecycle_enabled_admin_raw_disabled",
        "admin_raw_writes_enabled": False,
    }
    recommended_verb = _WORKSTREAM_RAW_LIFECYCLE_VERBS.get(action)
    if action == "clear_workstream_binding":
        metadata = body.get("metadata") if isinstance(body.get("metadata"), dict) else {}
        raw_status = str(body.get("status") or metadata.get("status") or "").strip().lower()
        if raw_status in {"complete", "completed"}:
            recommended_verb = "complete"
        else:
            response["needs_operator_decision"] = True
            response["decision_reason"] = "clear_workstream_binding is ambiguous without completion intent"
    if recommended_verb:
        response["recommended_verb"] = recommended_verb
    elif action not in {"clear_workstream_binding"}:
        response["required_action"] = "admin_raw_write_or_lifecycle_design"
        response["recommended_action"] = None
        response["write_mode"] = "admin_raw_write_only"
    return response


def _record_raw_workstream_admin_rejection(action: str, response: dict) -> None:
    try:
        from app.features.threads import _record_workstream_metric

        _record_workstream_metric(
            "workstream_raw_admin_write_rejected",
            {
                "action": action,
                "reason": response.get("reason", ""),
                "required_action": response.get("required_action", ""),
                "recommended_action": response.get("recommended_action", ""),
                "recommended_verb": response.get("recommended_verb", ""),
            },
        )
    except Exception:
        pass


def _build_workstreams_metrics_health(defer_reason: str | None = None) -> dict:
    if defer_reason:
        return _build_unavailable_health_metric(defer_reason)
    try:
        from datetime import timedelta

        from app.core.datetime_utils import _utc_now
        from app.ops.metrics import metrics

        since = (_utc_now() - timedelta(hours=1)).isoformat()
        metric_names = [
            "workstream_lifecycle_request",
            "workstream_lifecycle_transition",
            "workstream_lifecycle_idempotency",
            "workstream_raw_admin_write_rejected",
        ]
        totals: dict[str, int] = {}
        recent: list[dict] = []
        rejected_total = 0
        accepted_total = 0
        for metric_name in metric_names:
            rows = metrics.query(metric_name, since=since, limit=100)
            totals[metric_name] = len(rows)
            for row in rows[:5]:
                labels = row.get("labels") if isinstance(row.get("labels"), dict) else {}
                if labels.get("status") == "rejected" or metric_name == "workstream_raw_admin_write_rejected":
                    rejected_total += 1
                if labels.get("status") == "accepted":
                    accepted_total += 1
                recent.append(
                    {
                        "timestamp": row.get("timestamp"),
                        "metric": metric_name,
                        "labels": labels,
                    }
                )
        recent.sort(key=lambda item: str(item.get("timestamp") or ""), reverse=True)
        return {
            "status": "ok",
            "window_seconds": 3600,
            "totals": totals,
            "accepted_lifecycle_requests": accepted_total,
            "rejected_events": rejected_total,
            "recent": recent[:10],
        }
    except Exception as exc:
        return {"status": "degraded", "reason": _safe_error(exc), "alert": False}


@app.post("/pith_threads", dependencies=[Depends(verify_api_key)])
def pith_threads_endpoint(body: dict):
    """Manage narrative threads — ongoing work streams and topics."""
    from app.features.threads import (
        apply_workstream_hygiene,
        bind_workstream_checkpoint,
        build_workstream_context_block,
        classify_workstream_threads,
        clear_workstream_binding,
        create_thread,
        create_workstream,
        demote_workstream_discovery_candidate,
        dry_run_workstream_hygiene,
        ensure_workstream_activation,
        get_concepts_for_thread,
        get_thread_stats,
        link_concept_to_thread,
        load_thread,
        load_threads,
        promote_thread_to_workstream,
        promote_workstream_discovery_candidate,
        resolve_active_workstream,
        retrieve_similar_traces,
        rollback_workstream_hygiene,
        save_thread,
        summarize_thread_for_list,
        unlink_concept_from_thread,
        update_thread_status,
        update_workstream_metadata,
        workstream_lifecycle,
    )

    action = body.get("action", "list")

    from app.core.config import get_feature_flag

    if action in (
        "classify_workstreams",
        "workstream_context",
        "active_workstream",
        "workstream_hygiene_dry_run",
    ) and not get_feature_flag("WORKSTREAMS_READ_ENABLED", True):
        return {"status": "disabled", "reason": "WORKSTREAMS_READ_ENABLED is false"}
    if action == "ensure_workstream_activation":
        activation_mode = str(body.get("mode", "candidate") or "candidate").strip().lower()
        if activation_mode == "candidate" and not get_feature_flag("WORKSTREAMS_READ_ENABLED", True):
            return {"status": "disabled", "reason": "WORKSTREAMS_READ_ENABLED is false"}
        if activation_mode != "candidate":
            broad_write_enabled = get_feature_flag("WORKSTREAMS_WRITE_ENABLED", False)
            activation_write_enabled = get_feature_flag("WORKSTREAMS_ACTIVATION_WRITE_ENABLED", False)
            if not (broad_write_enabled or activation_write_enabled):
                return {"status": "disabled", "reason": "WORKSTREAMS_ACTIVATION_WRITE_ENABLED is false"}
    if action == "workstream_lifecycle":
        broad_write_enabled = get_feature_flag("WORKSTREAMS_WRITE_ENABLED", False)
        lifecycle_write_enabled = get_feature_flag("WORKSTREAMS_LIFECYCLE_WRITE_ENABLED", False)
        if not (broad_write_enabled or lifecycle_write_enabled):
            return {"status": "disabled", "reason": "WORKSTREAMS_LIFECYCLE_WRITE_ENABLED is false"}
    if action in _WORKSTREAM_HYGIENE_WRITE_ACTIONS:
        broad_write_enabled = get_feature_flag("WORKSTREAMS_WRITE_ENABLED", False)
        hygiene_write_enabled = get_feature_flag("WORKSTREAMS_HYGIENE_WRITE_ENABLED", True)
        if not (broad_write_enabled or hygiene_write_enabled):
            return {
                "status": "disabled",
                "reason": "WORKSTREAMS_HYGIENE_WRITE_ENABLED is false",
                "required_action": "rerun_hygiene_dry_run_and_operator_confirm",
            }
    if action in _WORKSTREAM_RAW_ADMIN_ACTIONS and not get_feature_flag("WORKSTREAMS_WRITE_ENABLED", False):
        disabled = _raw_workstream_admin_write_disabled(action, body)
        _record_raw_workstream_admin_rejection(action, disabled)
        return disabled

    if action == "create":
        if not body.get("title"):
            raise HTTPException(400, "title required for create")
        thread = create_thread(
            title=body["title"],
            description=body.get("description", ""),
            urgency=body.get("urgency", "normal"),
            goal_ids=body.get("goal_ids"),
            knowledge_areas=body.get("knowledge_areas"),
        )
        return {"status": "ok", "thread": thread.model_dump()}

    elif action == "get":
        if not body.get("thread_id"):
            raise HTTPException(400, "thread_id required for get")
        thread = load_thread(body["thread_id"])
        if not thread:
            return {"status": "not_found"}
        links = get_concepts_for_thread(body["thread_id"])
        return {
            "status": "ok",
            "thread": thread.model_dump(),
            "concept_links": [l.model_dump() for l in links],
        }

    elif action == "list":
        from app.core.config import THREAD_LIST_LIMIT_DEFAULT, THREAD_LIST_LIMIT_MAX

        status_filter = body.get("status")
        try:
            requested_limit = int(body.get("limit", THREAD_LIST_LIMIT_DEFAULT))
        except (TypeError, ValueError):
            requested_limit = THREAD_LIST_LIMIT_DEFAULT
        effective_limit = max(1, min(requested_limit, THREAD_LIST_LIMIT_MAX))
        threads = load_threads(status=status_filter, limit=effective_limit + 1)
        truncated = len(threads) > effective_limit
        visible_threads = threads[:effective_limit]
        return {
            "status": "ok",
            "threads": [summarize_thread_for_list(t) for t in visible_threads],
            "count": len(visible_threads),
            "limit": effective_limit,
            "truncated": truncated,
        }

    elif action == "update":
        if not body.get("thread_id"):
            raise HTTPException(400, "thread_id required for update")
        thread = load_thread(body["thread_id"])
        if not thread:
            return {"status": "not_found"}
        if body.get("title"):
            thread.title = body["title"][:500]
        if body.get("description") is not None:
            thread.description = body["description"][:500]
        if body.get("urgency"):
            thread.urgency = body["urgency"]
        if body.get("goal_ids") is not None:
            thread.goal_ids = body["goal_ids"]
        if body.get("knowledge_areas") is not None:
            thread.knowledge_areas = body["knowledge_areas"]
        thread.updated_at = _utc_now_iso()
        save_thread(thread)
        return {"status": "ok", "thread": thread.model_dump()}

    elif action == "close":
        if not body.get("thread_id"):
            raise HTTPException(400, "thread_id required for close")
        new_status = body.get("status", "completed")
        if new_status not in ("completed", "abandoned"):
            new_status = "completed"
        thread = update_thread_status(body["thread_id"], new_status, reason="user")
        return {"status": "ok", "thread": thread.model_dump()}

    elif action == "reactivate":
        if not body.get("thread_id"):
            raise HTTPException(400, "thread_id required for reactivate")
        thread = update_thread_status(body["thread_id"], "active", reason="user_reactivated")
        return {"status": "ok", "thread": thread.model_dump()}

    elif action == "link":
        if not body.get("thread_id") or not body.get("concept_id"):
            raise HTTPException(400, "thread_id and concept_id required for link")
        link = link_concept_to_thread(
            body["thread_id"],
            body["concept_id"],
            role=body.get("role", "member"),
            added_by=body.get("added_by", "user"),
        )
        return {"status": "ok", "link": link.model_dump() if link else None}

    elif action == "unlink":
        if not body.get("thread_id") or not body.get("concept_id"):
            raise HTTPException(400, "thread_id and concept_id required for unlink")
        unlink_concept_from_thread(body["thread_id"], body["concept_id"])
        return {"status": "ok"}

    elif action == "similar":
        if not body.get("situation"):
            raise HTTPException(400, "situation required for similar")
        results = retrieve_similar_traces(
            situation=body["situation"],
            intent=body.get("intent"),
            limit=body.get("limit", 5),
        )
        return {"status": "ok", "traces": results, "count": len(results)}

    elif action == "stats":
        return {"status": "ok", **get_thread_stats()}

    elif action == "classify_workstreams":
        return classify_workstream_threads(
            agent_id=body.get("agent_id", "default"),
            include_maintenance=_parse_workstream_bool(body.get("include_maintenance", True), default=True),
            limit=body.get("limit", 100),
            include_non_workstreams=_parse_workstream_bool(body.get("include_non_workstreams", False), default=False),
        )

    elif action == "workstream_hygiene_dry_run":
        return dry_run_workstream_hygiene(
            agent_id=body.get("agent_id", "default"),
            limit=body.get("limit", 100),
        )

    elif action == "workstream_hygiene_apply":
        return apply_workstream_hygiene(
            run_id=body.get("run_id"),
            evaluated_at=body.get("evaluated_at"),
            fingerprints=body.get("fingerprints") or {},
            proposed_states=body.get("proposed_states") or {},
            operator_confirmed=body.get("operator_confirmed", False),
            agent_id=body.get("agent_id", "default"),
        )

    elif action == "workstream_hygiene_rollback":
        return rollback_workstream_hygiene(
            run_id=body.get("run_id"),
            operator_confirmed=body.get("operator_confirmed", False),
        )

    elif action == "workstream_promote_discovery_candidate":
        return promote_workstream_discovery_candidate(
            thread_id=body.get("thread_id"),
            promotion_reason=body.get("promotion_reason", ""),
            promoted_by=body.get("promoted_by", "operator"),
            operator_confirmed=body.get("operator_confirmed", False),
        )

    elif action == "workstream_demote_discovery_candidate":
        return demote_workstream_discovery_candidate(
            thread_id=body.get("thread_id"),
            reason=body.get("reason", ""),
            demoted_by=body.get("demoted_by", "operator"),
            operator_confirmed=body.get("operator_confirmed", False),
        )

    elif action == "workstream_context":
        return build_workstream_context_block(
            thread_id=body.get("thread_id"),
            operator_mode=_parse_workstream_bool(body.get("operator_mode", False), default=False),
            max_refs=body.get("max_refs", 10),
            include_concept_summaries=_parse_workstream_bool(
                body.get("include_concept_summaries", True),
                default=True,
            ),
        )

    elif action == "create_workstream":
        if not body.get("title"):
            raise HTTPException(400, "title required for create_workstream")
        try:
            thread = create_workstream(
                title=body["title"],
                description=body.get("description", ""),
                urgency=body.get("urgency", "normal"),
                goal_ids=body.get("goal_ids"),
                knowledge_areas=body.get("knowledge_areas"),
                agent_id=body.get("agent_id", "default"),
                current_objective=body.get("current_objective", ""),
                current_summary=body.get("current_summary", ""),
                next_action=body.get("next_action", ""),
                blockers=body.get("blockers"),
                quality_state=body.get("quality_state", "ok"),
                created_by=body.get("created_by", "user"),
            )
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        return {"status": "ok", "thread": thread.model_dump()}

    elif action == "promote_workstream":
        if not body.get("thread_id"):
            raise HTTPException(400, "thread_id required for promote_workstream")
        metadata = {
            key: body[key]
            for key in (
                "current_objective",
                "current_summary",
                "next_action",
                "blockers",
                "quality_state",
                "created_by",
                "updated_by",
            )
            if key in body
        }
        try:
            thread = promote_thread_to_workstream(
                body["thread_id"],
                metadata=metadata,
                operator_mode=_parse_workstream_bool(body.get("operator_mode", False), default=False),
            )
        except ValueError as exc:
            if str(exc) == "thread_not_found":
                return {"status": "not_found"}
            if str(exc) == "maintenance_cluster_not_promotable":
                raise HTTPException(409, str(exc)) from exc
            raise HTTPException(400, str(exc)) from exc
        return {"status": "ok", "thread": thread.model_dump()}

    elif action == "update_workstream":
        if not body.get("thread_id"):
            raise HTTPException(400, "thread_id required for update_workstream")
        try:
            thread = update_workstream_metadata(body["thread_id"], body)
        except ValueError as exc:
            if str(exc) == "thread_not_found":
                return {"status": "not_found"}
            if str(exc) == "not_workstream":
                raise HTTPException(409, str(exc)) from exc
            raise HTTPException(400, str(exc)) from exc
        return {"status": "ok", "thread": thread.model_dump()}

    elif action == "bind_workstream":
        if not body.get("thread_id"):
            raise HTTPException(400, "thread_id required for bind_workstream")
        try:
            return bind_workstream_checkpoint(
                thread_id=body["thread_id"],
                origin_id=body.get("origin_id"),
                session_id=body.get("session_id"),
                current_task_id=body.get("current_task_id"),
                op_id=body.get("op_id"),
                payload_hash=body.get("payload_hash"),
            )
        except ValueError as exc:
            if str(exc) == "thread_not_found":
                return {"status": "not_found"}
            if str(exc) == "not_workstream":
                raise HTTPException(409, str(exc)) from exc
            raise HTTPException(400, str(exc)) from exc

    elif action == "clear_workstream_binding":
        try:
            return clear_workstream_binding(
                thread_id=body.get("thread_id"),
                origin_id=body.get("origin_id"),
                session_id=body.get("session_id"),
                current_task_id=body.get("current_task_id"),
            )
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    elif action == "workstream_lifecycle":
        return workstream_lifecycle(
            verb=body.get("verb", ""),
            origin_id=body.get("origin_id"),
            session_id=body.get("session_id"),
            current_task_id=body.get("current_task_id"),
            thread_id=body.get("thread_id"),
            metadata=_workstream_lifecycle_metadata_from_body(body),
            operator_confirmed=body.get("operator_confirmed", False),
            request_id=body.get("request_id"),
            op_id=body.get("op_id"),
            payload_hash=body.get("payload_hash"),
        )

    elif action == "active_workstream":
        try:
            return resolve_active_workstream(
                thread_id=body.get("thread_id"),
                origin_id=body.get("origin_id"),
                session_id=body.get("session_id"),
                current_task_id=body.get("current_task_id"),
                operator_mode=_parse_workstream_bool(body.get("operator_mode", False), default=False),
                max_refs=body.get("max_refs", 10),
                include_concept_summaries=_parse_workstream_bool(
                    body.get("include_concept_summaries", True),
                    default=True,
                ),
            )
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc

    elif action == "ensure_workstream_activation":
        result = ensure_workstream_activation(
            mode=body.get("mode", "candidate"),
            origin_id=body.get("origin_id"),
            session_id=body.get("session_id"),
            current_task_id=body.get("current_task_id"),
            situation=body.get("situation"),
            thread_id=body.get("thread_id"),
            metadata=_workstream_activation_metadata_from_body(body),
            skip_reason=body.get("skip_reason"),
            skip_exception_kind=body.get("skip_exception_kind"),
            operator_confirmed=body.get("operator_confirmed", False),
            include_proof_candidates=_parse_workstream_bool(
                body.get("include_proof_candidates", False),
                default=False,
            ),
            op_id=body.get("op_id"),
            payload_hash=body.get("payload_hash"),
        )
        if result.get("status") == "rejected":
            return result
        return result

    else:
        raise HTTPException(400, f"Unknown action: {action}")


# =============================================================================
# A.10: pith_traces MCP tool (cross-session search)
# =============================================================================


@app.post("/pith_traces", dependencies=[Depends(verify_api_key)])
def pith_traces_endpoint(body: dict):
    """Search and retrieve cognitive traces across sessions."""
    from app.core.config import TRACES_SEARCH_LIMIT_DEFAULT, TRACES_SEARCH_LIMIT_MAX
    from app.features.threads import _extract_terms_simple
    from app.ops.traces import load_trace

    action = body.get("action", "list")
    limit = min(body.get("limit", TRACES_SEARCH_LIMIT_DEFAULT), TRACES_SEARCH_LIMIT_MAX)
    offset = body.get("offset", 0)
    include_data = body.get("include_data", True)

    if action == "get":
        if not body.get("trace_id"):
            raise HTTPException(400, "trace_id required for get")
        trace = load_trace(body["trace_id"])
        if not trace:
            return {"status": "not_found", "message": f"Trace {body['trace_id']} not found"}
        # Enrich with linked concept summaries
        linked_concepts = []
        for cid in trace.concept_refs:
            concept = load_concept(cid, track_access=False)
            if concept:
                linked_concepts.append(
                    {
                        "id": concept.id,
                        "summary": concept.summary[:100],
                        "confidence": concept.confidence,
                        "concept_type": concept.concept_type,
                    }
                )
        return {
            "status": "ok",
            "trace": _format_trace(trace, 0.0, True),
            "linked_concepts": linked_concepts,
        }

    elif action == "list":
        traces = _load_filtered_traces(body, limit, offset)
        total = len(traces)  # Approximate; exact count would need separate query
        return {
            "status": "ok",
            "total": total,
            "returned": len(traces[:limit]),
            "offset": offset,
            "traces": [_format_trace(t, 0.0, include_data) for t in traces[:limit]],
        }

    elif action == "search":
        if not body.get("query"):
            raise HTTPException(400, "query required for search")
        query_terms = _extract_terms_simple(body["query"])
        if not query_terms:
            return {"status": "error", "message": "Query produced no searchable terms"}

        all_traces = _load_filtered_traces(body, limit=500, offset=0)
        if not all_traces:
            return {
                "status": "insufficient_data",
                "feature": "pith_traces search",
                "requirement": "at least 1 trace matching filters",
                "current": "0 traces found",
            }

        scored = []
        for trace in all_traces:
            primary_text = f"{trace.situation} {trace.assessment} {trace.justification}"
            secondary_text = f"{trace.intent} {trace.reflection}"
            primary_terms = set(_extract_terms_simple(primary_text))
            secondary_terms = set(_extract_terms_simple(secondary_text))
            primary_hits = sum(1 for t in query_terms if t in primary_terms)
            secondary_hits = sum(1 for t in query_terms if t in secondary_terms)
            score = (primary_hits + secondary_hits * 0.5) / len(query_terms)
            if score > 0:
                scored.append((trace, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        results = scored[offset : offset + limit]
        return {
            "status": "ok",
            "total_matches": len(scored),
            "returned": len(results),
            "offset": offset,
            "traces": [_format_trace(t, s, include_data) for t, s in results],
        }

    else:
        raise HTTPException(400, f"Unknown action: {action}")


def _format_trace(trace, score: float, include_data: bool) -> dict:
    """Format a TraceRecord for API response."""
    result = {
        "id": trace.id,
        "session_id": trace.session_id,
        "created_at": trace.created_at,
        "trigger_type": trace.trigger_type,
        "relevance_score": round(score, 3),
        "concept_count": len(trace.concept_refs),
    }
    if include_data:
        result.update(
            {
                "situation": trace.situation,
                "intent": trace.intent,
                "assessment": trace.assessment,
                "justification": trace.justification,
                "reflection": trace.reflection,
                "concept_refs": trace.concept_refs,
            }
        )
    return result


def _load_filtered_traces(body: dict, limit: int, offset: int) -> list:
    """Load traces with optional filters from request body."""

    from app.storage import _db

    clauses = []
    params = []
    if body.get("session_id"):
        clauses.append("session_id = ?")
        params.append(body["session_id"])
    if body.get("trigger_type"):
        clauses.append("trigger_type = ?")
        params.append(body["trigger_type"])
    if body.get("concept_id"):
        clauses.append("concept_refs LIKE ?")
        params.append(f"%{body['concept_id']}%")

    where = " AND ".join(clauses) if clauses else "1=1"
    sql = f"SELECT id, session_id, created_at, trigger_type, concept_refs, agent_id, data FROM traces WHERE {where} ORDER BY created_at DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])

    with _db() as conn:
        rows = conn.execute(sql, params).fetchall()

    from app.ops.traces import row_to_trace

    results = []
    for r in rows:
        trace = row_to_trace(r)
        if trace is not None:
            results.append(trace)
    return results


# =============================================================================
# Wave 6: pith_experiment — Cognitive experiment engine
# =============================================================================


@app.post("/pith_experiment")
async def handle_pith_experiment(request: Request):
    """Generate, process, list, get, or archive cognitive experiments."""
    body = await request.json()
    action = body.get("action", "")

    if action == "generate":
        from app.features.experiments import (
            EXPERIMENT_VALID_TYPES,
            TFIDFCache,
            generate_experiment,
        )
        from app.storage import list_concepts, load_associations

        experiment_type = body.get("experiment_type", "")
        if experiment_type not in EXPERIMENT_VALID_TYPES:
            raise HTTPException(
                400, f"Invalid experiment_type '{experiment_type}'. Valid: {sorted(EXPERIMENT_VALID_TYPES)}"
            )

        # Load concepts (optionally scoped to thread)
        thread_id = body.get("thread_id")
        if thread_id:
            from app.features.threads import get_concepts_for_thread

            concept_ids = get_concepts_for_thread(thread_id)
        else:
            concept_ids = list_concepts()
        concepts = [load_concept(cid, track_access=False) for cid in concept_ids]
        concepts = [c for c in concepts if c is not None]

        # Load associations for counterfactual
        associations = []
        if experiment_type == "counterfactual":
            raw_assocs = load_associations()
            assoc_list = raw_assocs.get("associations", [])
            associations = [
                {"source": a["source"], "target": a["target"], "relation": a["relation"]} for a in assoc_list
            ]

        # Build assoc_counts and salience_ranks for analogy
        assoc_counts = {}
        salience_ranks = {}
        if experiment_type == "analogy_detection":
            # count_associations() returns global count — compute per-concept from loaded associations
            if not associations:
                raw_assocs = load_associations()
                assoc_list = raw_assocs.get("associations", [])
            else:
                assoc_list = associations  # Already loaded above (unlikely path: counterfactual + analogy)
            # Build per-concept association counts from the association list
            from collections import Counter

            source_counts = Counter(a["source"] if isinstance(a, dict) else a.get("source", "") for a in assoc_list)
            target_counts = Counter(a["target"] if isinstance(a, dict) else a.get("target", "") for a in assoc_list)
            for c in concepts:
                assoc_counts[c.id] = source_counts.get(c.id, 0) + target_counts.get(c.id, 0)
                salience_ranks[c.id] = getattr(c, "salience", 0.5)

        tfidf_cache = TFIDFCache()
        experiment = generate_experiment(
            experiment_type=experiment_type,
            concepts=concepts,
            associations=associations,
            assoc_counts=assoc_counts,
            salience_ranks=salience_ranks,
            direction=body.get("direction"),
            max_concept_age_days=body.get("max_concept_age_days"),
            thread_id=thread_id,
            tfidf_cache=tfidf_cache,
        )

        return {
            "status": experiment.status,
            "experiment_id": experiment.id,
            "experiment_type": experiment.experiment_type,
            "candidates_count": len(experiment.candidates),
            "generation_time_ms": experiment.generation_time_ms,
            "metadata": experiment.metadata,
        }

    elif action == "process_results":
        import json as _json

        from app.core.models import ExperimentResult
        from app.features.experiments import process_experiment_results

        experiment_id = body.get("experiment_id")
        if not experiment_id:
            raise HTTPException(400, "experiment_id required")

        result_json = body.get("result_json", "{}")
        if isinstance(result_json, str):
            result_data = _json.loads(result_json)
        else:
            result_data = result_json

        result = ExperimentResult(**result_data)
        outcome = process_experiment_results(experiment_id, result)
        return {"status": "ok", **outcome}

    elif action == "list":
        from app.features.experiments import load_experiments

        include_archived = body.get("include_archived", False)
        experiments = load_experiments(include_archived=include_archived, limit=50)
        return {
            "status": "ok",
            "count": len(experiments),
            "experiments": [
                {
                    "id": e.id,
                    "experiment_type": e.experiment_type,
                    "status": e.status,
                    "created_at": e.created_at,
                    "updated_at": e.updated_at,
                    "candidates_count": len(e.candidates),
                    "concepts_produced": len(e.concept_ids_produced),
                    "thread_id": e.thread_id,
                }
                for e in experiments
            ],
        }

    elif action == "get":
        from app.features.experiments import load_experiment

        experiment_id = body.get("experiment_id")
        if not experiment_id:
            raise HTTPException(400, "experiment_id required")

        experiment = load_experiment(experiment_id)
        if not experiment:
            raise HTTPException(404, f"Experiment {experiment_id} not found")

        return {
            "status": "ok",
            "experiment": experiment.model_dump(),
        }

    elif action == "archive":
        from app.features.experiments import archive_experiment

        experiment_id = body.get("experiment_id")
        if not experiment_id:
            raise HTTPException(400, "experiment_id required")

        experiment = archive_experiment(experiment_id)
        if not experiment:
            raise HTTPException(404, f"Experiment {experiment_id} not found")

        return {
            "status": "ok",
            "experiment_id": experiment.id,
            "new_status": "archived",
        }

    elif action == "results":
        # [EXP-020] Return completed experiment insights with full synthesis content
        from app.features.experiments import SOURCE_IDS_MAX, load_experiments

        try:
            min_confidence = max(0.0, min(1.0, float(body.get("min_confidence", 0.0))))
        except (ValueError, TypeError):
            raise HTTPException(400, "min_confidence must be a number between 0.0 and 1.0")
        experiment_type = body.get("experiment_type")  # optional filter
        include_not_meaningful = body.get("include_not_meaningful", False)
        try:
            limit = max(1, min(200, int(body.get("limit", 50))))
        except (ValueError, TypeError):
            raise HTTPException(400, "limit must be an integer between 1 and 200")

        experiments = load_experiments(
            status=["completed"],
            experiment_type=experiment_type,
            limit=limit,
        )

        results_list = []
        for e in experiments:
            if not e.result:
                continue
            conf = e.result.confidence
            is_not_meaningful = conf == 0.0
            if is_not_meaningful and not include_not_meaningful:
                continue
            if conf < min_confidence:
                continue

            # Extract top source concept IDs from top candidate
            source_concept_ids: list[str] = []
            if e.candidates:
                top_cand = max(e.candidates, key=lambda c: c.score)
                source_concept_ids = top_cand.concept_ids[:SOURCE_IDS_MAX]

            results_list.append(
                {
                    "id": e.id,
                    "experiment_type": e.experiment_type,
                    "synthesis": e.result.synthesis,
                    "confidence": conf,
                    "reasoning_trace": e.result.reasoning_trace,
                    "concept_ids_produced": e.concept_ids_produced,
                    "source_concept_ids": source_concept_ids,
                    "created_at": e.created_at,
                    "updated_at": e.updated_at,
                }
            )

        # Sort by confidence descending
        results_list.sort(key=lambda r: r["confidence"], reverse=True)

        return {
            "status": "ok",
            "count": len(results_list),
            "min_confidence": min_confidence,
            "experiment_type": experiment_type,
            "results": results_list,
        }

    else:
        raise HTTPException(400, f"Unknown action: {action}")


# --- Temporal & Causal Endpoints ---


@app.post("/pith_timeline")
async def pith_timeline_endpoint(request: Request, body: dict = {}):
    """Returns concepts and activity within a time window."""
    try:
        result = temporal.pith_timeline(
            since=body.get("since"),
            until=body.get("until"),
            event_types=body.get("event_types"),
            knowledge_area=body.get("knowledge_area"),
            concept_type=body.get("concept_type"),
            limit=body.get("limit", 100),
            group_by=body.get("group_by"),
        )
        return result
    except Exception as e:
        logger.error(f"pith_timeline error: {e}")
        raise HTTPException(500, _safe_error(e))


@app.post("/pith_knowledge_at")
async def pith_knowledge_at_endpoint(request: Request, body: dict = {}):
    """Returns concepts valid at a specific point in time."""
    point_in_time = body.get("point_in_time")
    if not point_in_time:
        raise HTTPException(400, "point_in_time is required (ISO 8601 datetime)")
    try:
        result = temporal.pith_knowledge_at(
            point_in_time=point_in_time,
            knowledge_area=body.get("knowledge_area"),
            concept_type=body.get("concept_type"),
            limit=body.get("limit", 100),
        )
        return result
    except Exception as e:
        logger.error(f"pith_knowledge_at error: {e}")
        raise HTTPException(500, _safe_error(e))


@app.post("/pith_evolution_of")
async def pith_evolution_of_endpoint(request: Request, body: dict = {}):
    """Walks the supersession chain bidirectionally for a concept."""
    concept_id = body.get("concept_id")
    if not concept_id:
        raise HTTPException(400, "concept_id is required")
    try:
        result = temporal.pith_evolution_of(concept_id=concept_id)
        return result
    except Exception as e:
        logger.error(f"pith_evolution_of error: {e}")
        raise HTTPException(500, _safe_error(e))


@app.post("/pith_trace_cause")
async def pith_trace_cause_endpoint(request: Request, body: dict = {}):
    """Traverse causal DAG to find root causes or consequences."""
    concept_id = body.get("concept_id")
    if not concept_id:
        raise HTTPException(400, "concept_id is required")
    try:
        result = causal.pith_trace_cause(
            concept_id=concept_id,
            direction=body.get("direction", "root_cause"),
            max_depth=body.get("max_depth", 5),
            chain_id=body.get("chain_id"),
        )
        return result
    except Exception as e:
        logger.error(f"pith_trace_cause error: {e}")
        raise HTTPException(500, _safe_error(e))


@app.post("/pith_find_path")
async def pith_find_path_endpoint(request: Request, body: dict = {}):
    """Find typed shortest path between two concepts."""
    from_concept = body.get("from_concept")
    to_concept = body.get("to_concept")
    if not from_concept or not to_concept:
        raise HTTPException(400, "from_concept and to_concept are required")
    try:
        result = causal.pith_find_path(
            from_concept=from_concept,
            to_concept=to_concept,
            max_depth=body.get("max_depth", 5),
            relation_types=body.get("relation_types"),
        )
        return result
    except Exception as e:
        logger.error(f"pith_find_path error: {e}")
        raise HTTPException(500, _safe_error(e))


# --- DATA-057: Targeted stale technology sweep ---


@app.post("/pith_sweep_stale_tech", dependencies=[Depends(verify_api_key)])
async def pith_sweep_stale_tech(dry_run: bool = True):
    """Sweep and supersede concepts referencing eliminated technologies."""
    from app.cognitive.staleness import sweep_stale_technology_refs

    return sweep_stale_technology_refs(dry_run=dry_run)


# =============================================================================
# WS2: Metrics Dashboard
# =============================================================================


@app.get("/metrics/dashboard")
async def metrics_dashboard(since: str | None = None):
    """Return aggregated metrics for the Critical 8 + summary stats.

    Query param:
        since: ISO timestamp lower bound (default: last hour).

    Returns JSON matching Phase 4 WS2 §3.6 response shape.
    """
    try:
        from app.ops.metrics import metrics

        window_since = since or (_utc_now() - timedelta(hours=1)).isoformat()
        turn_latency = metrics.query_aggregate("conversation_turn_latency_ms", since=window_since)
        tier2_calls = metrics.query_count("tier2_llm_cost_calls", since=window_since)
        tier2_latency = metrics.query_aggregate("tier2_llm_latency_ms", since=window_since)
        contradiction_rate = metrics.query_aggregate("contradiction_detection_rate", since=window_since)
        cascade_count = metrics.query_count("cascade_propagation_count", since=window_since)
        cb_trips = metrics.query_count("circuit_breaker_trip_count", since=window_since)
        retrieval_latency = metrics.query_aggregate("retrieval_search_latency_ms", since=window_since)
        foreground_opens = metrics.query_counter_summary(
            FOREGROUND_CONTRACT_CIRCUIT_OPEN_METRIC,
            since=window_since,
            strict=True,
        )
        foreground_enforce_opens = metrics.query_counter_summary(
            FOREGROUND_CONTRACT_CIRCUIT_OPEN_METRIC,
            since=window_since,
            labels_filter={"mode": "enforce"},
            strict=True,
        )
        foreground_decisions = metrics.query_counter_summary(
            FOREGROUND_CONTRACT_DECISION_METRIC,
            since=window_since,
            strict=True,
        )
        foreground_decision_count = int(foreground_decisions["count"])
        foreground_open_count = int(foreground_opens["count"])
        foreground_enforce_open_count = int(foreground_enforce_opens["count"])
        foreground_open_rate = (
            round(foreground_open_count / foreground_decision_count * 100, 2) if foreground_decision_count else None
        )

        # Budget overruns — return recent individual events
        budget_overruns_raw = metrics.query("budget_overrun_ms", since=window_since, limit=50)
        budget_overruns = [
            {"overrun_ms": round(e["value"], 2), "timestamp": e["timestamp"]} for e in budget_overruns_raw
        ]

        return {
            "period": "last_hour" if since is None else f"since_{since}",
            "conversation_turn_latency_ms": {
                "p50": turn_latency["p50"],
                "p95": turn_latency["p95"],
                "p99": turn_latency["p99"],
                "count": turn_latency["count"],
                "avg": turn_latency["avg"],
            },
            "tier2_calls_total": tier2_calls,
            "tier2_latency_ms": {
                "p50": tier2_latency["p50"],
                "p95": tier2_latency["p95"],
                "avg": tier2_latency["avg"],
            },
            "contradiction_detection_rate": {
                "avg": contradiction_rate["avg"],
                "count": contradiction_rate["count"],
            },
            "cascade_propagations": cascade_count,
            "cascade_alert": cascade_count > _cascade_alert_threshold(),  # NITS-001: configurable
            "circuit_breaker_trips": cb_trips,
            "circuit_breaker_alert": cb_trips > _circuit_breaker_alert_threshold(),  # MONITOR-072
            "foreground_contract_circuit_opens": foreground_open_count,
            "foreground_contract_decisions": foreground_decision_count,
            "foreground_contract_enforce_circuit_opens": foreground_enforce_open_count,
            "foreground_contract_open_rate_pct": foreground_open_rate,
            "foreground_contract_alert": foreground_enforce_open_count > 0,
            "retrieval_search_latency_ms": {
                "p50": retrieval_latency["p50"],
                "p95": retrieval_latency["p95"],
                "avg": retrieval_latency["avg"],
                "count": retrieval_latency["count"],
            },
            "budget_overruns": budget_overruns,
        }
    except Exception as e:
        logger.error(f"Metrics dashboard error: {e}")
        raise HTTPException(500, _safe_error(e))


@app.get("/metrics/bg_tasks")
async def metrics_bg_tasks(since: str | None = None):
    """STATS-004: Background task success/failure/cancelled rates by task name."""
    try:
        from datetime import timedelta

        from app.ops.metrics import metrics

        if since is None:
            since = (_utc_now() - timedelta(hours=24)).isoformat()
        metrics.flush()
        from app.ops.async_tasks import TASK_CONFIGS
        from app.storage import _db

        with _db() as conn:
            try:
                ledger_rows = conn.execute(
                    """SELECT task_type, status, COUNT(*) as total
                       FROM async_task_runs
                       WHERE started_at >= ?
                       GROUP BY task_type, status
                       ORDER BY task_type, status""",
                    (since,),
                ).fetchall()
            except Exception:
                ledger_rows = []
            metric_rows = conn.execute(
                """SELECT metric, json_extract(labels, '$.task') as task_name,
                          SUM(value) as total
                   FROM metrics
                   WHERE metric IN ('bg_task_success', 'bg_task_failure', 'bg_task_cancelled')
                     AND timestamp >= ?
                   GROUP BY metric, task_name
                   ORDER BY task_name, metric""",
                (since,),
            ).fetchall()

        expected_task_names = sorted(
            task_type for task_type, config in TASK_CONFIGS.items() if config.interval_hours > 0
        )
        tasks = {
            task_name: {
                "success": 0,
                "failure": 0,
                "cancelled": 0,
                "total": 0,
                "failure_rate": 0,
                "status": "never_observed",
            }
            for task_name in expected_task_names
        }
        ledger_observed_tasks = set()
        for task_name, status, total in ledger_rows:
            task_name = task_name or "unknown"
            if status == "success":
                kind = "success"
            elif status in ("failed", "timeout"):
                kind = "failure"
            elif status == "cancelled":
                kind = "cancelled"
            else:
                continue
            if task_name not in tasks:
                tasks[task_name] = {
                    "success": 0,
                    "failure": 0,
                    "cancelled": 0,
                    "total": 0,
                    "failure_rate": 0,
                    "status": "observed_unregistered",
                }
            tasks[task_name][kind] += int(total or 0)
            ledger_observed_tasks.add(task_name)
        for metric, task_name, total in metric_rows:
            task_name = task_name or "unknown"
            if task_name in ledger_observed_tasks:
                continue
            if task_name not in tasks:
                tasks[task_name] = {
                    "success": 0,
                    "failure": 0,
                    "cancelled": 0,
                    "total": 0,
                    "failure_rate": 0,
                    "status": "observed_unregistered",
                }
            kind = metric.replace("bg_task_", "")
            tasks[task_name][kind] = int(total)
        for counts in tasks.values():
            total = counts["success"] + counts["failure"] + counts["cancelled"]
            counts["total"] = total
            counts["failure_rate"] = round(counts["failure"] / max(total, 1), 3)
            if total > 0:
                counts["status"] = "degraded" if counts["failure"] > 0 else "ok"
        observed_task_count = sum(1 for counts in tasks.values() if counts["total"] > 0)
        return {
            "since": since,
            "expected_task_count": len(expected_task_names),
            "observed_task_count": observed_task_count,
            "tasks": tasks,
        }
    except Exception as e:
        raise HTTPException(500, _safe_error(e))


@app.get("/dashboard", response_class=HTMLResponse)
async def metrics_dashboard_html():
    """OBS-01: Human-readable HTML metrics dashboard with Chart.js visualizations."""
    html = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pith — Metrics Dashboard</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>
  body { font-family: system-ui, sans-serif; background: #0f1117; color: #e2e8f0; margin: 0; padding: 20px; }
  h1 { color: #a78bfa; margin-bottom: 4px; }
  .subtitle { color: #64748b; font-size: 0.875rem; margin-bottom: 24px; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 20px; }
  .card { background: #1e2130; border-radius: 12px; padding: 20px; border: 1px solid #2d3148; }
  .card h3 { margin: 0 0 12px; color: #94a3b8; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.05em; }
  .stat-row { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #2d3148; font-size: 0.875rem; }
  .stat-row:last-child { border-bottom: none; }
  .stat-val { color: #a78bfa; font-weight: 600; }
  .chart-wrap { height: 200px; }
  .refresh { color: #64748b; font-size: 0.75rem; margin-top: 8px; }
  .status-ok { color: #34d399; }
  .status-warn { color: #fbbf24; }
  .error { color: #f87171; font-size: 0.875rem; padding: 8px; }
</style>
</head>
<body>
<h1>🧠 Pith — Metrics Dashboard</h1>
<div class="subtitle" id="refresh-ts">Loading...</div>
<div class="grid" id="dashboard-grid"><div class="card"><p>Loading metrics...</p></div></div>
<script>
const BASE = window.location.origin;

async function fetchJSON(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(r.statusText);
  return r.json();
}

function fmtMs(v) { return v == null ? '—' : (v >= 1000 ? (v/1000).toFixed(1)+'s' : v.toFixed(1)+'ms'); }
function fmtNum(v) { return v == null ? '—' : Number(v).toLocaleString(); }

function makeCard(title, rows) {
  const card = document.createElement('div');
  card.className = 'card';
  card.innerHTML = '<h3>' + title + '</h3>' +
    rows.map(([k, v]) => '<div class="stat-row"><span>' + k + '</span><span class="stat-val">' + v + '</span></div>').join('');
  return card;
}

function makeChartCard(title, labels, data, color) {
  const card = document.createElement('div');
  card.className = 'card';
  const cid = 'c' + Math.random().toString(36).slice(2);
  card.innerHTML = '<h3>' + title + '</h3><div class="chart-wrap"><canvas id="' + cid + '"></canvas></div>';
  setTimeout(() => {
    const ctx = document.getElementById(cid);
    if (!ctx) return;
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{ data: data, borderColor: color || '#a78bfa', backgroundColor: (color || '#a78bfa') + '22',
          tension: 0.3, fill: true, pointRadius: 2 }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } },
        scales: { x: { ticks: { color: '#64748b', maxTicksLimit: 6 } }, y: { ticks: { color: '#64748b' } } } }
    });
  }, 0);
  return card;
}

async function render() {
  const grid = document.getElementById('dashboard-grid');
  grid.innerHTML = '';
  try {
    const [dash, summary] = await Promise.all([
      fetchJSON(BASE + '/metrics/dashboard'),
      fetchJSON(BASE + '/metrics/summary')
    ]);

    // Summary stats card
    const metrics = summary.metrics || {};
    const metricNames = Object.keys(metrics);
    const summaryRows = metricNames.slice(0, 8).map(name => {
      const m = metrics[name];
      const isLatency = name.includes('latency') || name.includes('ms');
      return [name.replace(/_/g,' '), isLatency ? fmtMs(m.mean) : fmtNum(m.count)];
    });
    grid.appendChild(makeCard('Metric Summary (' + metricNames.length + ' metrics)', summaryRows));

    // Latency cards
    const latencyMetrics = ['conversation_turn_latency_ms', 'session_learn_latency_ms',
      'reflect_latency_ms', 'auto_associate_batch_latency_ms'];
    const latencyRows = latencyMetrics.map(name => {
      const m = metrics[name];
      return [name.replace(/_latency_ms/,'').replace(/_/g,' '),
        m ? fmtMs(m.mean) + ' avg / ' + fmtNum(m.count) + ' calls' : '—'];
    });
    grid.appendChild(makeCard('Hot-Path Latencies', latencyRows));

    // Time-series chart for conversation_turn if available
    const ctData = dash.recent_metrics || dash.metrics || [];
    const ctRows = ctData.filter(r => r.metric === 'conversation_turn_latency_ms').slice(-20);
    if (ctRows.length > 0) {
      const labels = ctRows.map(r => r.timestamp ? r.timestamp.slice(11,16) : '');
      const vals = ctRows.map(r => r.value);
      grid.appendChild(makeChartCard('conversation_turn latency (last 20)', labels, vals, '#a78bfa'));
    }

    // session_learn chart
    const slRows = ctData.filter(r => r.metric === 'session_learn_latency_ms').slice(-20);
    if (slRows.length > 0) {
      const labels = slRows.map(r => r.timestamp ? r.timestamp.slice(11,16) : '');
      const vals = slRows.map(r => r.value);
      grid.appendChild(makeChartCard('session_learn latency (last 20)', labels, vals, '#34d399'));
    }

    document.getElementById('refresh-ts').textContent =
      'Last updated: ' + new Date().toLocaleTimeString() + ' — auto-refreshes every 30s';
  } catch(e) {
    grid.innerHTML = '<div class="card"><p class="error">Error loading metrics: ' + e.message + '</p></div>';
  }
}

render();
setInterval(render, 30000);
</script>
</body>
</html>"""
    return HTMLResponse(content=html)


@app.get("/metrics/summary")
async def metrics_summary_endpoint(days: int = 7):
    """OBS-003: Aggregated metrics summary with per-metric stats and trends."""
    try:
        from app.ops.metrics import metrics

        metrics.flush()
        result = metrics.metrics_summary(days=days)
        return result
    except Exception as e:
        logger.error(f"metrics_summary error: {e}")
        return {"status": "error", "error": _safe_error(e)}


@app.get("/metrics/health_trend")
async def metrics_health_trend(days: int = 7):
    """STATS-005: Pith health score time series over N days."""
    try:
        from datetime import timedelta

        from app.ops.metrics import metrics

        since = (_utc_now() - timedelta(days=days)).isoformat()
        metrics.flush()
        from app.storage import _db

        with _db() as conn:
            rows = conn.execute(
                """SELECT date(timestamp) as day, metric, AVG(value) as avg_val
                   FROM metrics
                   WHERE metric IN ('pith_health_score', 'pith_maturity_score',
                                    'pith_connectivity_score', 'pith_confidence_avg',
                                    'pith_freshness_ratio')
                     AND timestamp >= ?
                   GROUP BY day, metric
                   ORDER BY day""",
                (since,),
            ).fetchall()
        days_data = {}
        for day, metric, avg_val in rows:
            if day not in days_data:
                days_data[day] = {"date": day}
            days_data[day][metric] = round(avg_val, 4)
        series = sorted(days_data.values(), key=lambda d: d["date"])
        degradation_alert = False
        if len(series) >= 2:
            latest = series[-1].get("pith_health_score", 0)
            prev = series[-2].get("pith_health_score", 0)
            if prev > 0 and (prev - latest) > 0.05:
                degradation_alert = True
        return {"days": days, "series": series, "degradation_alert": degradation_alert}
    except Exception as e:
        raise HTTPException(500, _safe_error(e))


# ---------------------------------------------------------------------------
# Unified Observability (TIER2 Developer Surface)
# ---------------------------------------------------------------------------


@app.get("/pith/observability")
async def pith_observability():
    """Single-call system health snapshot.

    Aggregates cognitive health, stats, learning metrics, performance,
    and background task status into one response. Each section is
    independently try/excepted so partial failures don't block the rest.
    """
    from datetime import datetime

    result: dict = {
        "timestamp": datetime.now(UTC).isoformat(),
        "status": "healthy",
    }

    # --- Cognitive health (from /pith_health internals) ---
    try:
        health = reflection_engine.analyze_stability()
        result["cognitive"] = {
            "stability_score": health.get("stability_score", health.get("score")),
            "total_concepts": health.get("total_concepts"),
            "knowledge_areas": health.get("knowledge_areas", {}),
        }
    except Exception as e:
        result["cognitive"] = {"error": _safe_error(e)}

    # --- Stats (from /pith_stats internals) ---
    try:
        from app.storage import get_pith_stats_aggregates

        agg = get_pith_stats_aggregates()
        agg["associations"] = count_associations()
        agg["pending_questions"] = len(question_queue.get_questions(limit=1000))
        result["stats"] = {
            "total_concepts": agg.get("total_concepts", 0),
            "associations": agg.get("associations", 0),
            "avg_confidence": agg.get("avg_confidence", 0),
            "pending_questions": agg.get("pending_questions", 0),
        }
    except Exception as e:
        result["stats"] = {"error": _safe_error(e)}

    # --- Learning metrics (subset of /learning_metrics) ---
    try:
        from app.storage import get_db_connection

        conn = get_db_connection()
        today_count = conn.execute("SELECT COUNT(*) FROM concepts WHERE created_at >= date('now')").fetchone()[0]
        result["learning"] = {
            "concepts_today": today_count,
            "total_concepts": result.get("stats", {}).get("total_concepts", 0),
        }
    except Exception as e:
        result["learning"] = {"error": _safe_error(e)}

    # --- Performance (subset of /metrics/dashboard) ---
    try:
        from app.ops.metrics import metrics

        window_since = (_utc_now() - timedelta(hours=1)).isoformat()
        turn_latency = metrics.query_aggregate("conversation_turn_latency_ms", since=window_since)
        retrieval_latency = metrics.query_aggregate("retrieval_search_latency_ms", since=window_since)
        cb_trips = metrics.query_count("circuit_breaker_trip_count", since=window_since)
        budget_overruns = metrics.query_count("budget_overrun_ms", since=window_since)
        foreground_opens = metrics.query_counter_summary(
            FOREGROUND_CONTRACT_CIRCUIT_OPEN_METRIC,
            since=window_since,
            strict=True,
        )
        foreground_enforce_opens = metrics.query_counter_summary(
            FOREGROUND_CONTRACT_CIRCUIT_OPEN_METRIC,
            since=window_since,
            labels_filter={"mode": "enforce"},
            strict=True,
        )
        foreground_decisions = metrics.query_counter_summary(
            FOREGROUND_CONTRACT_DECISION_METRIC,
            since=window_since,
            strict=True,
        )
        foreground_decision_count = int(foreground_decisions["count"])
        foreground_open_count = int(foreground_opens["count"])
        foreground_enforce_open_count = int(foreground_enforce_opens["count"])
        result["performance"] = {
            "conversation_turn_latency_p95_ms": turn_latency.get("p95"),
            "retrieval_latency_p95_ms": retrieval_latency.get("p95"),
            "circuit_breaker_trips": cb_trips,
            "budget_overruns": budget_overruns,
            "foreground_contract_circuit_opens": foreground_open_count,
            "foreground_contract_decisions": foreground_decision_count,
            "foreground_contract_enforce_circuit_opens": foreground_enforce_open_count,
            "foreground_contract_open_rate_pct": (
                round(foreground_open_count / foreground_decision_count * 100, 2) if foreground_decision_count else None
            ),
            "foreground_contract_alert": foreground_enforce_open_count > 0,
        }
    except Exception as e:
        result["performance"] = {"error": _safe_error(e)}

    # --- Background tasks ---
    try:
        result["background_tasks"] = _build_observability_background_tasks()
    except Exception as e:
        result["background_tasks"] = {"error": _safe_error(e)}

    # --- Derive overall status ---
    try:
        stability = result.get("cognitive", {}).get("stability_score") or 0
        cb = result.get("performance", {}).get("circuit_breaker_trips") or 0
        foreground_enforce_opens = result.get("performance", {}).get("foreground_contract_enforce_circuit_opens") or 0
        p95 = result.get("performance", {}).get("conversation_turn_latency_p95_ms") or 0
        if stability < 0.4 or cb >= 5:
            result["status"] = "unhealthy"
        elif stability < 0.7 or cb > 0 or foreground_enforce_opens > 0 or (p95 and p95 > 5000):
            result["status"] = "degraded"
        else:
            result["status"] = "healthy"
    except Exception:
        result["status"] = "unknown"

    return result


@app.get("/metrics/compaction_summary")
def metrics_compaction_summary():
    """CTX-006: Compaction reinjection event analytics.

    Returns aggregate stats across all recorded compaction_reinjection
    governance events, including resume rate and average recovery quality.
    """
    from app.storage import _db

    with _db() as conn:
        row = conn.execute(
            """SELECT
                COUNT(*) as total_events,
                SUM(CASE WHEN json_extract(details, '$.has_resume') = 1 THEN 1 ELSE 0 END) as has_resume_count,
                AVG(json_extract(details, '$.turn_count')) as avg_turn_count,
                MAX(json_extract(details, '$.turn_count')) as max_turn_count,
                AVG(json_extract(details, '$.recovery_quality')) as avg_recovery_quality,
                MIN(created_at) as first_event_at,
                MAX(created_at) as most_recent_at
               FROM governance_events
               WHERE event_type = 'compaction_reinjection'"""
        ).fetchone()
        sessions_row = conn.execute(
            """SELECT COUNT(DISTINCT session_id) as sessions_affected
               FROM governance_events
               WHERE event_type = 'compaction_reinjection'"""
        ).fetchone()
    total = row["total_events"] or 0
    has_resume = row["has_resume_count"] or 0
    return {
        "total_events": total,
        "sessions_affected": sessions_row["sessions_affected"] or 0,
        "has_resume_rate": round(has_resume / total, 4) if total else 0.0,
        "avg_turn_count": round(row["avg_turn_count"] or 0, 1),
        "max_turn_count": row["max_turn_count"] or 0,
        "avg_recovery_quality": (
            round(row["avg_recovery_quality"], 4) if row["avg_recovery_quality"] is not None else None
        ),
        "first_event_at": row["first_event_at"],
        "most_recent_at": row["most_recent_at"],
    }


# =============================================================================
# OBS-009/010, MEASURE-002/015: Observability Endpoints — Sub-Sprint O-C
# =============================================================================

# MEASURE-015: Health threshold config — direction-aware evaluation
_HEALTH_THRESHOLDS = {
    "concept_count": {"green": 100, "amber": 50, "direction": "higher_better"},
    "session_count_7d": {"green": 5, "amber": 2, "direction": "higher_better"},
    "avg_confidence": {"green": 0.3, "amber": 0.2, "direction": "higher_better"},
    "quarantined_pct": {"green": 0.03, "amber": 0.05, "red": 0.10, "direction": "lower_better"},
    "superseded_pct": {"green": 0.10, "amber": 0.15, "red": 0.30, "direction": "lower_better"},
    "promotion_rate_7d": {"green": 1, "amber": 0, "direction": "higher_better"},
}


def _evaluate_metric(value, thresholds):
    """Evaluate a metric against green/amber/red thresholds."""
    direction = thresholds.get("direction", "higher_better")
    if direction == "lower_better":
        if "red" in thresholds and value >= thresholds["red"]:
            return "red"
        if "green" in thresholds and value <= thresholds["green"]:
            return "green"
        return "amber"
    else:
        if "green" in thresholds and value >= thresholds["green"]:
            return "green"
        if "amber" in thresholds and value >= thresholds["amber"]:
            return "amber"
        return "red"


@app.get("/metrics/governance_summary", dependencies=[Depends(verify_api_key)])
async def metrics_governance_summary(days: int = 7):
    """OBS-009: Governance event type distribution with trend."""
    try:
        from datetime import timedelta

        from app.storage import _db

        with _db() as conn:
            cutoff = (_utc_now() - timedelta(days=days)).isoformat()
            prior_cutoff = (_utc_now() - timedelta(days=days * 2)).isoformat()

            current = conn.execute(
                """SELECT event_type, COUNT(*) as cnt
                   FROM governance_events WHERE created_at >= ?
                   GROUP BY event_type ORDER BY cnt DESC LIMIT 25""",
                (cutoff,),
            ).fetchall()

            prior = conn.execute(
                """SELECT event_type, COUNT(*) as cnt
                   FROM governance_events WHERE created_at >= ? AND created_at < ?
                   GROUP BY event_type ORDER BY cnt DESC LIMIT 25""",
                (prior_cutoff, cutoff),
            ).fetchall()

            total_current = sum(r[1] for r in current)
            prior_map = {r[0]: r[1] for r in prior}
            total_prior = sum(r[1] for r in prior)

            event_types = []
            for event_type, cnt in current:
                prior_cnt = prior_map.get(event_type, 0)
                trend = ((cnt - prior_cnt) / prior_cnt * 100) if prior_cnt > 0 else None
                event_types.append(
                    {
                        "event_type": event_type,
                        "count": cnt,
                        "prior_count": prior_cnt,
                        "trend_pct": round(trend, 1) if trend is not None else None,
                    }
                )

            return {
                "period_days": days,
                "total_events": total_current,
                "prior_total": total_prior,
                "event_types": event_types,
            }
    except Exception as e:
        logger.error(f"governance_summary error: {e}")
        return {"status": "error", "error": _safe_error(e)}


@app.get("/metrics/session_activity", dependencies=[Depends(verify_api_key)])
async def metrics_session_activity(days: int = 7):
    """OBS-010: Session activity aggregates."""
    try:
        from datetime import timedelta

        from app.storage import _db

        with _db() as conn:
            cutoff = (_utc_now() - timedelta(days=days)).isoformat()

            stats = conn.execute(
                """SELECT
                     COUNT(*) as total_sessions,
                     AVG(learning_event_count) as avg_learning_events,
                     AVG(concepts_created) as avg_concepts_created,
                     AVG(concepts_evolved) as avg_concepts_evolved,
                     SUM(learning_event_count) as total_learning_events
                   FROM sessions WHERE started_at >= ?""",
                (cutoff,),
            ).fetchone()

            daily = conn.execute(
                """SELECT date(started_at) as day, COUNT(*) as cnt
                   FROM sessions WHERE started_at >= ?
                   GROUP BY day ORDER BY day""",
                (cutoff,),
            ).fetchall()

            models = conn.execute(
                """SELECT COALESCE(model_id, 'unknown') as model, COUNT(*) as cnt
                   FROM sessions WHERE started_at >= ?
                   GROUP BY model ORDER BY cnt DESC""",
                (cutoff,),
            ).fetchall()

            return {
                "period_days": days,
                "total_sessions": stats[0] or 0,
                "avg_learning_events": round(stats[1] or 0, 1),
                "avg_concepts_created": round(stats[2] or 0, 1),
                "avg_concepts_evolved": round(stats[3] or 0, 1),
                "total_learning_events": stats[4] or 0,
                "sessions_per_day": [{"date": r[0], "count": r[1]} for r in daily],
                "model_distribution": [{"model": r[0], "count": r[1]} for r in models],
            }
    except Exception as e:
        logger.error(f"session_activity error: {e}")
        return {"status": "error", "error": _safe_error(e)}


@app.get("/diagnostics/surface_activity", dependencies=[Depends(verify_api_key)])
async def diagnostics_surface_activity(
    since: str | None = None,
    until: str | None = None,
    include_codex_local: bool = False,
    requested_surfaces: str | None = None,
    include_concept_samples: bool = False,
    min_confidence: float | None = None,
    max_samples_per_surface: int | None = None,
):
    """Source-labeled lifecycle and optional surface memory coverage diagnostic."""
    from app.diagnostics.surface_activity import build_surface_activity_diagnostic

    return build_surface_activity_diagnostic(
        since=since,
        until=until,
        include_codex_local=include_codex_local,
        requested_surfaces=requested_surfaces,
        include_concept_samples=include_concept_samples,
        min_confidence=min_confidence,
        max_samples_per_surface=max_samples_per_surface,
    )


@app.get("/metrics/graduation_stats", dependencies=[Depends(verify_api_key)])
async def metrics_graduation_stats(days: int = 7):
    """MEASURE-002: Graduation pipeline metrics."""
    try:
        from datetime import timedelta

        from app.storage import _db

        with _db() as conn:
            cutoff = (_utc_now() - timedelta(days=days)).isoformat()

            maturity_dist = conn.execute(
                """SELECT maturity, COUNT(*) as cnt FROM concepts
                   WHERE is_current = 1
                   GROUP BY maturity ORDER BY cnt DESC"""
            ).fetchall()

            promotions = conn.execute(
                """SELECT COUNT(*) FROM governance_events
                   WHERE event_type = 'MATURITY_PROMOTED' AND created_at >= ?""",
                (cutoff,),
            ).fetchone()[0]

            daily_promo = conn.execute(
                """SELECT date(created_at) as day, COUNT(*) as cnt
                   FROM governance_events
                   WHERE event_type = 'MATURITY_PROMOTED' AND created_at >= ?
                   GROUP BY day ORDER BY day""",
                (cutoff,),
            ).fetchall()

            contradictions = conn.execute(
                """SELECT COUNT(*) FROM governance_events
                   WHERE event_type = 'CONTRADICTION_DETECTED' AND created_at >= ?""",
                (cutoff,),
            ).fetchone()[0]

            return {
                "period_days": days,
                "maturity_distribution": {r[0] or "NULL": r[1] for r in maturity_dist},
                "promotions_in_period": promotions,
                "contradictions_in_period": contradictions,
                "contradiction_to_promotion_ratio": (round(contradictions / promotions, 2) if promotions > 0 else None),
                "promotions_per_day": [{"date": r[0], "count": r[1]} for r in daily_promo],
            }
    except Exception as e:
        logger.error(f"graduation_stats error: {e}")
        return {"status": "error", "error": _safe_error(e)}


@app.get("/health/summary", dependencies=[Depends(verify_api_key)])
async def health_summary():
    """MEASURE-015: Structured health summary with per-metric status."""
    try:
        from datetime import timedelta

        from app.storage import _db

        with _db() as conn:
            cutoff_7d = (_utc_now() - timedelta(days=7)).isoformat()

            active = conn.execute(
                "SELECT COUNT(*) FROM concepts WHERE is_current = 1 AND status = 'active'"
            ).fetchone()[0]

            avg_conf = (
                conn.execute(
                    "SELECT AVG(confidence) FROM concepts WHERE is_current = 1 AND status = 'active'"
                ).fetchone()[0]
                or 0.0
            )

            quarantined = conn.execute("SELECT COUNT(*) FROM concepts WHERE maturity = 'QUARANTINED'").fetchone()[0]

            superseded = conn.execute("SELECT COUNT(*) FROM concepts WHERE is_current = 0").fetchone()[0]

            total = conn.execute("SELECT COUNT(*) FROM concepts").fetchone()[0]

            sessions_7d = conn.execute("SELECT COUNT(*) FROM sessions WHERE started_at >= ?", (cutoff_7d,)).fetchone()[
                0
            ]

            promotions_7d = conn.execute(
                """SELECT COUNT(*) FROM governance_events
                   WHERE event_type = 'MATURITY_PROMOTED' AND created_at >= ?""",
                (cutoff_7d,),
            ).fetchone()[0]

            quar_pct = quarantined / active if active > 0 else 0
            super_pct = superseded / total if total > 0 else 0

            metrics_result = {
                "concept_count": {
                    "value": active,
                    "status": _evaluate_metric(active, _HEALTH_THRESHOLDS["concept_count"]),
                },
                "session_count_7d": {
                    "value": sessions_7d,
                    "status": _evaluate_metric(sessions_7d, _HEALTH_THRESHOLDS["session_count_7d"]),
                },
                "avg_confidence": {
                    "value": round(avg_conf, 3),
                    "status": _evaluate_metric(avg_conf, _HEALTH_THRESHOLDS["avg_confidence"]),
                },
                "quarantined_pct": {
                    "value": round(quar_pct, 3),
                    "status": _evaluate_metric(quar_pct, _HEALTH_THRESHOLDS["quarantined_pct"]),
                },
                "superseded_pct": {
                    "value": round(super_pct, 3),
                    "status": _evaluate_metric(super_pct, _HEALTH_THRESHOLDS["superseded_pct"]),
                },
                "promotion_rate_7d": {
                    "value": promotions_7d,
                    "status": _evaluate_metric(promotions_7d, _HEALTH_THRESHOLDS["promotion_rate_7d"]),
                },
            }

            statuses = [m["status"] for m in metrics_result.values()]
            if "red" in statuses:
                overall = "red"
            elif "amber" in statuses:
                overall = "amber"
            else:
                overall = "green"

            return {
                "overall": overall,
                "metrics": metrics_result,
                "thresholds": _HEALTH_THRESHOLDS,
            }
    except Exception as e:
        logger.error(f"health_summary error: {e}")
        return {"status": "error", "error": _safe_error(e)}


# =============================================================================


# =============================================================================
# EPISODE-001: Episode Query Endpoint
# =============================================================================


@app.get("/pith_episodes", dependencies=[Depends(verify_api_key)])
async def pith_episodes(
    session_id: str | None = None,
    query: str | None = None,
    limit: int = 50,
    offset: int = 0,
):
    """EPISODE-001: Query episodes with optional session filter and text search."""
    try:
        from app.storage import _db

        with _db() as conn:
            conditions = []
            params = []

            if session_id:
                conditions.append("session_id = ?")
                params.append(session_id)

            if query:
                conditions.append("(intent_summary LIKE ? OR classification LIKE ?)")
                params.extend([f"%{query}%", f"%{query}%"])

            where = f"WHERE {' AND '.join(conditions)}" if conditions else ""

            # Count total
            total = conn.execute(f"SELECT COUNT(*) FROM episodes {where}", params).fetchone()[0]

            # Fetch page
            rows = conn.execute(
                f"""SELECT id, session_id, turn_number, extracted_concept_ids,
                       intent_summary, classification, world_timestamp, created_at
                   FROM episodes {where}
                   ORDER BY created_at DESC
                   LIMIT ? OFFSET ?""",
                params + [limit, offset],
            ).fetchall()

            episodes = []
            for r in rows:
                import json as _json

                concept_ids = []
                try:
                    concept_ids = _json.loads(r[3]) if r[3] else []
                except (ValueError, TypeError):
                    pass

                episodes.append(
                    {
                        "id": r[0],
                        "session_id": r[1],
                        "turn_number": r[2],
                        "concept_ids": concept_ids,
                        "intent_summary": r[4],
                        "classification": r[5],
                        "timestamp": r[6],
                        "created_at": r[7],
                    }
                )

            return {
                "total": total,
                "limit": limit,
                "offset": offset,
                "episodes": episodes,
            }
    except Exception as e:
        logger.error(f"pith_episodes error: {e}")
        return {"status": "error", "error": _safe_error(e)}


# CKO (Compound Knowledge Objects) Endpoints — Layer 4
# =============================================================================


class CKOCreateRequest(PydanticBaseModel):
    """Request body for creating a CKO."""

    title: str
    concept_ids: list[str]
    synthesis: str
    knowledge_area: str = "general"
    cko_type: str = "analysis"


class CKOUpdateRequest(PydanticBaseModel):
    """Request body for updating a CKO."""

    concept_ids: list[str] | None = None
    synthesis: str | None = None


@app.post("/pith/cko", dependencies=[Depends(verify_api_key)])
def cko_create(request: CKOCreateRequest):
    """Create a new Compound Knowledge Object."""
    from app.features.cko import create_cko
    from app.storage import managed_write_db

    try:
        with managed_write_db(operation="cko_create") as conn:
            cko = create_cko(
                conn=conn,
                title=request.title,
                concept_ids=request.concept_ids,
                synthesis=request.synthesis,
                knowledge_area=request.knowledge_area,
                cko_type=request.cko_type,
            )
        return cko.to_dict()
    except Exception as e:
        logger.error(f"CKO create failed: {e}")
        raise HTTPException(500, _safe_error(e))


@app.get("/pith/cko/{cko_id}")
def cko_get(cko_id: str):
    """Load a single CKO by ID."""
    from app.features.cko import load_cko
    from app.storage import read_snapshot_db

    with read_snapshot_db("cko_get") as conn:
        cko = load_cko(conn, cko_id, ensure_table=False)
    if not cko:
        raise HTTPException(404, f"CKO {cko_id} not found")
    return cko.to_dict()


@app.get("/pith/cko")
def cko_list(
    status: str | None = None,
    knowledge_area: str | None = None,
    limit: int = 50,
):
    """List CKOs with optional filters."""
    from app.features.cko import list_ckos
    from app.storage import read_snapshot_db

    with read_snapshot_db("cko_list") as conn:
        ckos = list_ckos(conn, status=status, knowledge_area=knowledge_area, limit=limit, ensure_table=False)
    return {"count": len(ckos), "ckos": [c.to_dict() for c in ckos]}


@app.post("/pith/cko/search")
def cko_search(query_area: str | None = None, max_results: int = 3):
    """Search CKOs for context assembly."""
    from app.features.cko import search_ckos
    from app.storage import managed_write_db

    with managed_write_db(operation="cko_search") as conn:
        ckos = search_ckos(conn, query_area=query_area, max_results=max_results)
    return {"count": len(ckos), "ckos": [c.to_dict() for c in ckos]}


@app.put("/pith/cko/{cko_id}", dependencies=[Depends(verify_api_key)])
def cko_update(cko_id: str, request: CKOUpdateRequest):
    """Update a CKO's synthesis and/or constituents."""
    from app.features.cko import load_cko, update_cko_synthesis
    from app.storage import managed_write_db

    try:
        with managed_write_db(operation="cko_update") as conn:
            existing = load_cko(conn, cko_id)
            if not existing:
                raise HTTPException(404, f"CKO {cko_id} not found")
            cko = update_cko_synthesis(
                conn=conn,
                cko_id=cko_id,
                new_synthesis=request.synthesis,
                new_concept_ids=request.concept_ids,
            )
        return cko.to_dict()
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"CKO update failed: {e}")
        raise HTTPException(500, _safe_error(e))


@app.delete("/pith/cko/{cko_id}", dependencies=[Depends(verify_api_key)])
def cko_delete(cko_id: str):
    """Delete a CKO."""
    from app.features.cko import delete_cko
    from app.storage import managed_write_db

    with managed_write_db(operation="cko_delete") as conn:
        success = delete_cko(conn, cko_id)
    if not success:
        raise HTTPException(404, f"CKO {cko_id} not found")
    return {"deleted": cko_id}


@app.post("/pith/cko/lifecycle", dependencies=[Depends(verify_api_key)])
def cko_lifecycle():
    """Run CKO lifecycle management: refresh scores, archive stale, find merge candidates."""
    from app.features.cko import run_cko_lifecycle
    from app.storage import managed_write_db

    try:
        with managed_write_db(operation="cko_lifecycle") as conn:
            result = run_cko_lifecycle(conn)
        return result
    except Exception as e:
        logger.error(f"CKO lifecycle failed: {e}")
        raise HTTPException(500, _safe_error(e))


@app.post("/pith/cko/{cko_id}/refresh", dependencies=[Depends(verify_api_key)])
def cko_refresh(cko_id: str):
    """Refresh a single CKO's scores from current constituent state."""
    from app.features.cko import refresh_cko
    from app.storage import managed_write_db

    with managed_write_db(operation="cko_refresh") as conn:
        cko = refresh_cko(conn, cko_id)
    if not cko:
        raise HTTPException(404, f"CKO {cko_id} not found")
    return cko.to_dict()


# =============================================================================
# User Policies (Phase 3)
# =============================================================================


@app.post("/pith/policies", dependencies=[Depends(verify_api_key)])
def create_policy_endpoint(body: dict):
    """Create a new user policy."""
    from app.governance.user_policies import create_policy

    required = {"policy_type", "rule", "action"}
    missing = required - set(body.keys())
    if missing:
        raise HTTPException(400, f"Missing required fields: {missing}")
    try:
        policy = create_policy(
            policy_type=body["policy_type"],
            rule=body["rule"],
            action=body["action"],
            condition=body.get("condition"),
            priority=body.get("priority", 50),
        )
        return {"status": "created", "policy": asdict(policy)}
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.get("/pith/policies")
def list_policies_endpoint(policy_type: str = None, include_disabled: bool = False):
    """List user policies, optionally filtered by type."""
    from app.governance.user_policies import list_policies

    try:
        policies = list_policies(policy_type=policy_type, include_disabled=include_disabled)
        return {"policies": [asdict(p) for p in policies]}
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.get("/pith/policies/{policy_id}")
def get_policy_endpoint(policy_id: str):
    """Get a single policy by ID."""
    from app.governance.user_policies import get_policy

    policy = get_policy(policy_id)
    if not policy:
        raise HTTPException(404, f"Policy {policy_id} not found")
    return {"policy": asdict(policy)}


@app.put("/pith/policies/{policy_id}", dependencies=[Depends(verify_api_key)])
def update_policy_endpoint(policy_id: str, body: dict):
    """Update an existing policy."""
    from app.governance.user_policies import update_policy

    policy = update_policy(
        policy_id=policy_id,
        rule=body.get("rule"),
        action=body.get("action"),
        condition=body.get("condition"),
        priority=body.get("priority"),
        enabled=body.get("enabled"),
    )
    if not policy:
        raise HTTPException(404, f"Policy {policy_id} not found")
    return {"status": "updated", "policy": asdict(policy)}


@app.delete("/pith/policies/{policy_id}", dependencies=[Depends(verify_api_key)])
def delete_policy_endpoint(policy_id: str):
    """Soft-delete a policy (disable it)."""
    from app.governance.user_policies import delete_policy

    success = delete_policy(policy_id)
    if not success:
        raise HTTPException(404, f"Policy {policy_id} not found")
    return {"status": "deleted", "policy_id": policy_id}


# =============================================================================
# P4a: Post-Response Validation Endpoint
# =============================================================================


@app.post("/validate_response", dependencies=[Depends(verify_api_key)])
async def validate_response_endpoint(request: Request, body: dict = {}):
    """Validate a draft response against active constraints.

    P4a: Three-tier validation (negation + entity overlap + embedding escalation).
    Feature-flagged via POST_RESPONSE_VALIDATION_ENABLED.

    Body:
        response_text (str): The draft response to validate
        constraint_set (dict): The constraint_set from conversation_turn
        skip_validation (bool, optional): Skip all validation (opt-out)
    """
    from app.cognitive.prediction_error import validate_response

    response_text = body.get("response_text", "")
    constraint_set = body.get("constraint_set", {})
    skip_validation = body.get("skip_validation", False)

    if not response_text:
        return {"error": "response_text is required"}
    if not constraint_set:
        return {"error": "constraint_set is required"}

    result = validate_response(
        response_text=response_text,
        constraint_set=constraint_set,
        skip_validation=skip_validation,
    )
    return result


# ---------------------------------------------------------------------------
# P4b: Belief Diff
# ---------------------------------------------------------------------------


@app.post("/belief_diff", dependencies=[Depends(verify_api_key)])
async def belief_diff_endpoint(request: Request, body: dict = {}):
    """Compare pith belief state between two timestamps.

    Body params:
        t1 (str): ISO datetime for earlier state
        t2 (str): ISO datetime for later state
        knowledge_area (str, optional): Filter to specific domain
    """
    from app.cognitive.belief_diff import belief_diff

    t1 = body.get("t1", "")
    t2 = body.get("t2", "")
    knowledge_area = body.get("knowledge_area")

    if not t1 or not t2:
        return {"error": "Both t1 and t2 timestamps are required"}

    return belief_diff(t1=t1, t2=t2, knowledge_area=knowledge_area)


# ---------------------------------------------------------------------------
# P4c: Epistemic Network Migration
# ---------------------------------------------------------------------------


@app.post("/migrate_epistemic_networks", dependencies=[Depends(verify_api_key)])
async def migrate_epistemic_networks_endpoint(request: Request, body: dict = {}):
    """Migrate concepts to extended epistemic networks.

    Body params:
        dry_run (bool): If True (default), report changes without applying them
    """
    from app.governance.epistemic import migrate_epistemic_networks

    dry_run = body.get("dry_run", True)
    return migrate_epistemic_networks(dry_run=dry_run)


# =============================================================================
# AGENT-002: Agent Token Management
# =============================================================================


@app.post("/agent_tokens", dependencies=[Depends(verify_api_key)])
def create_token_endpoint(body: dict):
    """Create a new agent bearer token."""
    from app.storage import create_agent_token

    agent_id = body.get("agent_id")
    if not agent_id:
        raise HTTPException(400, "agent_id is required")
    label = body.get("label", "")
    result = create_agent_token(agent_id=agent_id, label=label)
    return result


@app.delete("/agent_tokens/{token}", dependencies=[Depends(verify_api_key)])
def revoke_token_endpoint(token: str):
    """Revoke an agent token."""
    from app.storage import revoke_agent_token

    success = revoke_agent_token(token)
    if not success:
        raise HTTPException(404, "Token not found or already revoked")
    return {"status": "revoked", "token_prefix": token[:9] + "..."}


@app.get("/agent_tokens", dependencies=[Depends(verify_api_key)])
def list_tokens_endpoint(agent_id: str = None):
    """List agent tokens (masked). Optionally filter by agent_id."""
    from app.storage import list_agent_tokens

    return {"tokens": list_agent_tokens(agent_id=agent_id)}


@app.get("/agent_tokens/resolve")
def resolve_token_endpoint(token: str):
    """Resolve a bearer token to agent_id. Used by MCP HTTP server.
    No API key required — the token itself IS the credential."""
    from app.storage import resolve_agent_token

    agent_id = resolve_agent_token(token)
    if not agent_id:
        raise HTTPException(401, "Invalid or revoked token")
    return {"agent_id": agent_id}


# --- INGEST-037: Verbatim fragment endpoints ---


@app.post("/verbatim/store", dependencies=[Depends(verify_api_key)])
def store_verbatim(
    concept_id: str,
    fragment_type: str = "text",
    content: str | None = None,
    pointer_uri: str | None = None,
    pointer_meta: dict | None = None,
    evidence_id: str | None = None,
):
    """Store a verbatim fragment for a concept."""
    from app.storage import load_concept, save_verbatim_fragment

    concept = load_concept(concept_id)
    if not concept:
        raise HTTPException(404, f"Concept {concept_id} not found")
    if not content and not pointer_uri:
        raise HTTPException(400, "Either content or pointer_uri is required")

    version = concept.get("version") if isinstance(concept, dict) else getattr(concept, "version", None)
    frag_id = save_verbatim_fragment(
        concept_id=concept_id,
        fragment_type=fragment_type,
        content=content,
        pointer_uri=pointer_uri,
        pointer_meta=pointer_meta,
        evidence_id=evidence_id,
        concept_version=version,
    )
    if frag_id is None:
        raise HTTPException(413, "Verbatim budget exceeded for this concept")
    return {"fragment_id": frag_id, "concept_id": concept_id}


@app.get("/verbatim/{concept_id}", dependencies=[Depends(verify_api_key)])
def get_verbatim(concept_id: str, limit: int = 10):
    """Get all verbatim fragments for a concept."""
    from app.storage import get_verbatim_fragments

    fragments = get_verbatim_fragments(concept_id, limit=limit)
    return {"concept_id": concept_id, "fragments": fragments, "count": len(fragments)}


@app.delete("/verbatim/{fragment_id}", dependencies=[Depends(verify_api_key)])
def delete_verbatim(fragment_id: str):
    """Delete a specific verbatim fragment."""
    from app.storage import delete_verbatim_fragment

    deleted = delete_verbatim_fragment(fragment_id)
    if not deleted:
        raise HTTPException(404, f"Fragment {fragment_id} not found")
    return {"deleted": fragment_id}


@app.get("/verbatim_stats", dependencies=[Depends(verify_api_key)])
def verbatim_stats():
    """Get aggregate verbatim fragment statistics."""
    from app.storage import get_verbatim_stats

    return get_verbatim_stats()


if __name__ == "__main__":
    import uvicorn

    if sys.platform.startswith("win"):
        policy_factory = getattr(asyncio, "WindowsSelectorEventLoopPolicy", None)
        if policy_factory is not None:
            asyncio.set_event_loop_policy(policy_factory())
    uvicorn.run(app, host=PITH_HOST, port=PITH_PORT)
