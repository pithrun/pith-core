"""Read-only diagnostic helpers."""
